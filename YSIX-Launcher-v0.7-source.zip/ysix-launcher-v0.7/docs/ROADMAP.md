# Development roadmap

## v0.1 — Launcher foundation
Completed: Java-only UI, document pickers and saved preferences.

## v0.2 — Visual identity
Completed: gothic adaptive launcher icon patch.

## v0.3 — Launcher frontend
Completed: navigation, library selection, graphics/control preferences and device diagnostics.

## v0.4 — Native bring-up probe
Device-tested on Galaxy A22 5G (Mali-G57 MC2) and Redmi Turbo 4 (Mali-G720 MC7): local Ys IX image open/decryption, ExeFS `main`/`sdk` NSO hash checks, Vulkan instance/device/graphics queue initialization all reported PASS on both devices.

## v0.5 — Native loader staging + content tools
Device-tested on both target phones: MOD0/dynamic/symbol/relocation metadata inspection and temporary `MAP_FIXED_NOREPLACE` staging maps for `main` and `sdk` passed Gate B1. ZIP save archive import/export and a DLC package reference queue were added. Live in-game save-data and DLC mounting remain unimplemented.

## v0.6 — Temporary relocation and symbol-resolution test
Adds simultaneous RW/non-executable mappings for both modules, a defined-symbol export index, application of supported relocations when resolvable inside the `main`/`sdk` scope, and read-back verification. Unresolved strong imports and unsupported relocation types are reported; unresolved addresses are never faked. Mappings are discarded. Both phones later passed Gate B2a: supported relative/module/export relocations were applied only to temporary mappings, verified and discarded. The remaining 22 strong imports motivated the v0.7 runtime integration.

## v0.7 — Horizon import resolver and NCE bootstrap
The v0.6 device reports passed Gate B2a on both Mali devices. v0.7 now attempts the actual generic NCE runtime startup path, with four Ys IX ExeFS modules loaded and the reference Horizon/HLE + NVN runtime integrated. This is explicitly experimental: unresolved imports and service gaps can still terminate startup. The first boot log must confirm import resolution, module initialization and the first failing runtime stage. The next work must be driven by that `nx.log`, not by another standalone metadata test.

## v0.8+ — Switch services and graphics
Implement services requested by Ys IX based on logs, then NVN resource/command behavior and Maxwell shader translation. Verify Mali-specific texture format fallbacks, memory usage, synchronization and presentation. Integrate live save services and verified DLC/update content mounting.

## Gameplay acceptance
First frame, interactive menu, input/audio, stable playable scene, save/load and a clean 10-minute run are separate gates. Do not claim playability until the stable-scene gate passes on at least one named device.


## v0.7 — Experimental native runtime boot attempt

- Integrates the pinned generic MIT native execution runtime in `NX_NCE=ON` mode.
- Adds NativeActivity and SAF file-descriptor handoff for the selected game image and keys.
- Loads Ys IX `main`, `sdk`, `subsdk0`, and `subsdk1` into the runtime module linker.
- Attempts `nn::init::Start` and native game startup; this may fail before gameplay.
- Adds native `nx.log` viewing.
- Does not yet implement Ys IX-specific movie/video shims, verify all services, validate the renderer on Mali, or connect saves/DLC to game services.
