YS IX: MONSTRUM NOX — v0.7 NATIVE RUNTIME BOOT ATTEMPT

FILES TO UPLOAD
1) YSIX-Launcher-v0.7-source.zip -> repository root
2) ysix-v0.7-native-runtime.yml -> .github/workflows/ysix-v0.7-native-runtime.yml

BUILD
1) Open the repository on GitHub.
2) Open Actions.
3) Select "Build YS IX v0.7 Native Runtime Boot Attempt".
4) Press "Run workflow" on the main branch.
5) When it succeeds, download the artifact named:
   ysix-v0.7-native-runtime-debug-apk

INSTALL / TEST
1) Install app-debug.apk on the Redmi Turbo 4 first.
2) Open YS IX and make sure the saved game image and prod.keys can still be read.
3) Run "RUN LOADER + GPU TEST" once, then return Home.
4) Press "TRY NATIVE BOOT" and confirm the experimental warning.
5) If the app returns or closes, reopen YS IX and open "VIEW LAST NATIVE BOOT LOG".
6) Send the complete nx.log and identify which phone produced it.
7) Repeat separately on the Galaxy A22 5G after the Redmi test.

IMPORTANT
- This is the first integrated native runtime boot attempt, not a playable release.
- It executes the generic ARM64 NCE runtime and attempts the Ys IX startup path. Missing game-specific Switch services,
  unresolved imports, module init ordering, rtld assumptions, video/movie APIs or NVN/shader compatibility can stop it.
- The v0.7 code loads main, sdk, subsdk0 and subsdk1. The extra-module constructor order is provisional.
- Keep v0.6 and v0.7 source archives as backups until the Actions build and phone tests complete.
- Save ZIP workspace and DLC queue are not connected to live in-game save/DLC services.
- Never upload your NSP/XCI, keys, decrypted modules, saves or DLC packages to GitHub.

BUILD LIMITATION
The project source and workflow have been checked locally, but a complete Android NDK build was not run in this
container because the Android SDK/NDK are not installed here. GitHub Actions is the APK build verification step.
