#!/usr/bin/env python3
"""Patch the pinned, MIT-licensed P5R generic runtime for a first Ys IX NCE boot attempt.

This does not copy or enable Persona 5 Royal game-specific hooks. It adapts the generic runtime's
input handoff, game identity, module list and Android module reservation for Ys IX.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import shutil


def replace_once(path: Path, old: str, new: str) -> None:
    text = path.read_text(encoding="utf-8")
    count = text.count(old)
    if count != 1:
        raise SystemExit(f"patch precondition failed in {path}: expected exactly one occurrence, found {count}: {old[:100]!r}")
    path.write_text(text.replace(old, new), encoding="utf-8")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, type=Path)
    ap.add_argument("--game-source", required=True, type=Path)
    args = ap.parse_args()
    root = args.root.resolve()
    game_dir = root / "games" / "ysix"
    game_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(args.game_source, game_dir / "game.cpp")

    # Reserve room for main + sdk + subsdk0 + subsdk1, each at a 256 MiB guest stride.
    replace_once(root / "runtime/src/memory.cpp",
                 'reserve(kModuleBase, 0x20000000, "modules");',
                 'reserve(kModuleBase, 0x40000000, "main, sdk, subsdk0 and subsdk1 modules");')

    # Track the extra NSO modules so their init arrays can run after the SDK and before main.
    replace_once(root / "runtime/src/main.cpp",
                 'static const ModuleInfo* g_sdk = nullptr;\n',
                 'static const ModuleInfo* g_sdk = nullptr;\nstatic const ModuleInfo* g_subsdk0 = nullptr;\nstatic const ModuleInfo* g_subsdk1 = nullptr;\n')
    replace_once(root / "runtime/src/main.cpp",
                 '    init_module(c, *g_sdk);\n    init_module(c, *g_main);\n    game::after_init();',
                 '    init_module(c, *g_sdk);\n    if (g_subsdk0) init_module(c, *g_subsdk0);\n    if (g_subsdk1) init_module(c, *g_subsdk1);\n    init_module(c, *g_main);\n    game::after_init();')

    # Main/SDK code, NCE bridge and HLE loader already live in this runtime. Extend its NCE input
    # set to the two title-specific dynamic modules present in the Ys IX ExeFS.
    old_boot = '''    // The player's own ExeFS (main and sdk as they are on the cartridge or in the eShop download): from the game file
    // read in place (game_image.h), else from the data folder's exefs/.
    nce::init();
    static std::unique_ptr<nce::NsoModule> nso[2];
    const std::string exefs = plat::data_root() + "/exefs";
    const char* names[2] = {"main", "sdk"};
    const nxi::GameImage* image = game_image();
    for (int i = 0; i < 2; i++) {
        std::string error;
        const uint64_t base = kModuleBase + uint64_t(i) * 0x10000000;
        if (image) {
            auto it = image->exefs().find(names[i]);
            if (it == image->exefs().end()) fatal("the game file's ExeFS has no %s", names[i]);
            nso[i] = nce::load_nso_bytes(it->second, std::string("ExeFS/") + names[i], names[i], base, error);
        } else {
            nso[i] = nce::load_nso(exefs + "/" + names[i], names[i], base, error);
        }
        if (!nso[i]) fatal("%s (copy the exefs folder of your own dump of the game there)", error.c_str());
    }
    if (const char* want = game::kInfo.main_build_id) {
        std::string have;
        for (uint8_t b : nso[0]->build_id) {
            char hex[3];
            std::snprintf(hex, sizeof hex, "%02X", b);
            have += hex;
        }
        if (have.compare(0, std::strlen(want), want) != 0)
            fatal("exefs/main is build %s, not %s: this port is made for one version of the game (%s)", have.c_str(), want,
                  "copy the exefs of the base game, without the update");
    }
    g_main = &nso[0]->info, g_sdk = &nso[1]->info;
    const ModuleInfo* mods[] = {g_main, g_sdk};
    const uint8_t* images[] = {nso[0]->image.data(), nso[1]->image.data()};
    load_modules(mods, 2, "", images);'''
    new_boot = '''    // Ys IX's own ExeFS: main + sdk + subsdk0 + subsdk1. rtld is replaced by the runtime's
    // nn::init::Start/rtld callbacks; all four actual program modules are loaded and indexed together.
    nce::init();
    static std::unique_ptr<nce::NsoModule> nso[4];
    const std::string exefs = plat::data_root() + "/exefs";
    const char* names[4] = {"main", "sdk", "subsdk0", "subsdk1"};
    const nxi::GameImage* image = game_image();
    if (!image) fatal("Ys IX boot requires the selected NSP/XCI handoff (NX_GAME_FD is missing)");
    if (image->title_id() != game::kInfo.program_id)
        fatal("wrong title ID %016llx (expected %016llx)",
              (unsigned long long)image->title_id(), (unsigned long long)game::kInfo.program_id);
    for (int i = 0; i < 4; i++) {
        std::string error;
        const uint64_t base = kModuleBase + uint64_t(i) * 0x10000000;
        auto it = image->exefs().find(names[i]);
        if (it == image->exefs().end()) fatal("Ys IX ExeFS is missing required module %s", names[i]);
        nso[i] = nce::load_nso_bytes(it->second, std::string("ExeFS/") + names[i], names[i], base, error);
        if (!nso[i]) fatal("cannot parse Ys IX module %s: %s", names[i], error.c_str());
        log("Ys IX module %s parsed: %zu bytes, base %llx", names[i], nso[i]->image.size(),
            (unsigned long long)base);
    }
    if (const char* want = game::kInfo.main_build_id) {
        std::string have;
        for (uint8_t b : nso[0]->build_id) {
            char hex[3];
            std::snprintf(hex, sizeof hex, "%02X", b);
            have += hex;
        }
        if (have.compare(0, std::strlen(want), want) != 0)
            fatal("Ys IX main build ID %s does not match supported base build %s", have.c_str(), want);
    }
    g_main = &nso[0]->info, g_sdk = &nso[1]->info;
    g_subsdk0 = &nso[2]->info, g_subsdk1 = &nso[3]->info;
    const ModuleInfo* mods[4] = {&nso[0]->info, &nso[1]->info, &nso[2]->info, &nso[3]->info};
    const uint8_t* images[4] = {nso[0]->image.data(), nso[1]->image.data(), nso[2]->image.data(), nso[3]->image.data()};
    load_modules(mods, 4, "", images);'''
    replace_once(root / "runtime/src/main.cpp", old_boot, new_boot)
    replace_once(root / "runtime/src/main.cpp",
                 '#include <string>\n',
                 '#include <string>\n#include <vector>\n')

    # Android NativeActivity opens the SAF URIs handed off by the Java launcher, duplicates their
    # file descriptors and passes only descriptor numbers to the generic game-image reader.
    platform = root / "runtime/src/platform_android.cpp"
    replace_once(platform,
                 'static bool has_data(const std::string& root) { return access((root + kDataProbe).c_str(), R_OK) == 0; }',
                 '''static bool has_data(const std::string& root) {
    const char* game_fd = std::getenv("NX_GAME_FD");
    if (game_fd && *game_fd) return true;  // SAF-backed NSP/XCI is read by descriptor, no all-files permission needed.
    if (std::getenv("NX_BOOT_ERROR")) return true;  // surface a handoff error instead of opening the storage settings page.
    return access((root + kDataProbe).c_str(), R_OK) == 0;
}''')
    activity_old = '''extern "C" JNIEXPORT void ANativeActivity_onCreate(ANativeActivity* activity, void* saved, size_t size) {
    g_activity = activity;
    if (g_ui_pipe[0] < 0 && pipe2(g_ui_pipe, O_NONBLOCK | O_CLOEXEC) == 0)
        ALooper_addFd(ALooper_forThread(), g_ui_pipe[0], ALOOPER_POLL_CALLBACK, ALOOPER_EVENT_INPUT, on_ui_request, nullptr);
    glue_ANativeActivity_onCreate(activity, saved, size);
}'''
    activity_new = '''namespace {
jstring ysix_intent_string(JNIEnv* env, jobject intent, const char* key) {
    jclass cls = env->GetObjectClass(intent);
    jmethodID method = env->GetMethodID(cls, "getStringExtra", "(Ljava/lang/String;)Ljava/lang/String;");
    jstring jkey = env->NewStringUTF(key);
    auto value = method ? static_cast<jstring>(env->CallObjectMethod(intent, method, jkey)) : nullptr;
    env->DeleteLocalRef(jkey);
    if (env->ExceptionCheck()) { env->ExceptionClear(); return nullptr; }
    return value;
}

int ysix_open_uri_fd(JNIEnv* env, jobject resolver, jstring uri_text) {
    if (!uri_text) return -1;
    jclass uri_cls = env->FindClass("android/net/Uri");
    jmethodID parse = env->GetStaticMethodID(uri_cls, "parse", "(Ljava/lang/String;)Landroid/net/Uri;");
    jobject uri = parse ? env->CallStaticObjectMethod(uri_cls, parse, uri_text) : nullptr;
    if (env->ExceptionCheck() || !uri) { env->ExceptionClear(); return -1; }
    jclass resolver_cls = env->GetObjectClass(resolver);
    jmethodID open = env->GetMethodID(resolver_cls, "openFileDescriptor",
            "(Landroid/net/Uri;Ljava/lang/String;)Landroid/os/ParcelFileDescriptor;");
    jstring mode = env->NewStringUTF("r");
    jobject pfd = open ? env->CallObjectMethod(resolver, open, uri, mode) : nullptr;
    env->DeleteLocalRef(mode);
    if (env->ExceptionCheck() || !pfd) { env->ExceptionClear(); return -1; }
    jclass pfd_cls = env->GetObjectClass(pfd);
    jmethodID get_fd = env->GetMethodID(pfd_cls, "getFd", "()I");
    jint raw_fd = get_fd ? env->CallIntMethod(pfd, get_fd) : -1;
    int owned_fd = raw_fd >= 0 ? fcntl(raw_fd, F_DUPFD_CLOEXEC, 0) : -1;
    jmethodID close = env->GetMethodID(pfd_cls, "close", "()V");
    if (close) env->CallVoidMethod(pfd, close);
    if (env->ExceptionCheck()) env->ExceptionClear();
    env->DeleteLocalRef(pfd);
    env->DeleteLocalRef(uri);
    return owned_fd;
}

void ysix_read_launcher_intent(ANativeActivity* activity) {
    // A repeated NativeActivity launch in a reused process must not inherit stale descriptor numbers.
    unsetenv("NX_BOOT_ERROR");
    unsetenv("NX_GAME_FD");
    unsetenv("NX_KEYS_FD");
    unsetenv("NX_TITLE_KEYS_FD");
    unsetenv("NX_GAME_NAME");
    JNIEnv* env = activity->env;
    if (!env) return;
    jclass activity_cls = env->GetObjectClass(activity->clazz);
    jmethodID get_intent = env->GetMethodID(activity_cls, "getIntent", "()Landroid/content/Intent;");
    jobject intent = get_intent ? env->CallObjectMethod(activity->clazz, get_intent) : nullptr;
    if (env->ExceptionCheck() || !intent) { env->ExceptionClear(); setenv("NX_BOOT_ERROR", "NativeActivity has no launch intent", 1); return; }
    jmethodID get_resolver = env->GetMethodID(activity_cls, "getContentResolver", "()Landroid/content/ContentResolver;");
    jobject resolver = get_resolver ? env->CallObjectMethod(activity->clazz, get_resolver) : nullptr;
    if (env->ExceptionCheck() || !resolver) { env->ExceptionClear(); setenv("NX_BOOT_ERROR", "cannot access Android ContentResolver", 1); return; }

    jstring game_uri = ysix_intent_string(env, intent, "ysix.game_uri");
    jstring keys_uri = ysix_intent_string(env, intent, "ysix.keys_uri");
    jstring title_uri = ysix_intent_string(env, intent, "ysix.title_keys_uri");
    jstring game_name = ysix_intent_string(env, intent, "ysix.game_name");
    int game_fd = ysix_open_uri_fd(env, resolver, game_uri);
    int keys_fd = ysix_open_uri_fd(env, resolver, keys_uri);
    int title_fd = ysix_open_uri_fd(env, resolver, title_uri);
    if (game_uri) env->DeleteLocalRef(game_uri);
    if (keys_uri) env->DeleteLocalRef(keys_uri);
    if (title_uri) env->DeleteLocalRef(title_uri);
    if (game_fd < 0 || keys_fd < 0) {
        if (game_fd >= 0) close(game_fd);
        if (keys_fd >= 0) close(keys_fd);
        if (title_fd >= 0) close(title_fd);
        setenv("NX_BOOT_ERROR", "could not open the selected game NSP/XCI or prod.keys URI", 1);
    } else {
        setenv("NX_GAME_FD", std::to_string(game_fd).c_str(), 1);
        setenv("NX_KEYS_FD", std::to_string(keys_fd).c_str(), 1);
        if (title_fd >= 0) setenv("NX_TITLE_KEYS_FD", std::to_string(title_fd).c_str(), 1);
        if (game_name) {
            const char* chars = env->GetStringUTFChars(game_name, nullptr);
            if (chars) { setenv("NX_GAME_NAME", chars, 1); env->ReleaseStringUTFChars(game_name, chars); }
            env->DeleteLocalRef(game_name);
        }
        __android_log_print(ANDROID_LOG_INFO, "ysix", "launcher file descriptors opened; game/key bytes are not logged");
    }
}
}  // namespace

extern "C" JNIEXPORT void ANativeActivity_onCreate(ANativeActivity* activity, void* saved, size_t size) {
    g_activity = activity;
    ysix_read_launcher_intent(activity);
    if (g_ui_pipe[0] < 0 && pipe2(g_ui_pipe, O_NONBLOCK | O_CLOEXEC) == 0)
        ALooper_addFd(ALooper_forThread(), g_ui_pipe[0], ALOOPER_POLL_CALLBACK, ALOOPER_EVENT_INPUT, on_ui_request, nullptr);
    glue_ANativeActivity_onCreate(activity, saved, size);
}'''
    replace_once(platform, activity_old, activity_new)

    # Add a fatal, explicit launch-handoff error before the importer runs.
    game_image = root / "runtime/src/game_image.cpp"
    replace_once(game_image,
                 'void open_image() {\n    const char* fd = std::getenv("NX_GAME_FD");',
                 'void open_image() {\n    if (const char* launch_error = std::getenv("NX_BOOT_ERROR")) fatal("launcher handoff: %s", launch_error);\n    const char* fd = std::getenv("NX_GAME_FD");')
    old_keys = '''    std::vector<int> keys;  // read while opening, then closed
    const char* k = std::getenv("NX_KEYS");
    if (!k || !*k) fatal("game: NX_KEYS (the prod.keys file) is not set");
    if ((keys.emplace_back(open_read(k))) < 0) fatal("game: cannot open the keys file");
    in.push_back({"prod.keys", keys.back()});
    if (const char* t = std::getenv("NX_TITLE_KEYS"); t && *t) {
        int f = open_read(t);
        if (f >= 0) keys.push_back(f), in.push_back({"title.keys", f});
    }'''
    new_keys = '''    std::vector<int> keys;  // read while opening, then closed
    const char* keys_fd = std::getenv("NX_KEYS_FD");
    const char* k = std::getenv("NX_KEYS");
    if (keys_fd && *keys_fd) {
        int f = std::atoi(keys_fd);
        if (f < 0) fatal("game: invalid prod.keys descriptor");
        keys.push_back(f);
    } else {
        if (!k || !*k) fatal("game: NX_KEYS_FD/NX_KEYS (prod.keys) is not set");
        int f = open_read(k);
        if (f < 0) fatal("game: cannot open the keys file");
        keys.push_back(f);
    }
    in.push_back({"prod.keys", keys.back()});
    const char* title_fd = std::getenv("NX_TITLE_KEYS_FD");
    if (title_fd && *title_fd) {
        int f = std::atoi(title_fd);
        if (f >= 0) keys.push_back(f), in.push_back({"title.keys", f});
    } else if (const char* t = std::getenv("NX_TITLE_KEYS"); t && *t) {
        int f = open_read(t);
        if (f >= 0) keys.push_back(f), in.push_back({"title.keys", f});
    }'''
    replace_once(game_image, old_keys, new_keys)

    print("Patched P5R generic runtime for Ys IX native bring-up (NCE, 4 ExeFS modules, SAF FD handoff).")

if __name__ == "__main__":
    main()
