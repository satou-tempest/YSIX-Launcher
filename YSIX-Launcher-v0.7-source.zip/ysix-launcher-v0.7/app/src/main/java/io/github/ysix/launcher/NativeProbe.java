package io.github.ysix.launcher;

/** JNI bridge for v0.7 NSP/ExeFS, temporary relocation test and Vulkan diagnostics. */
public final class NativeProbe {
    static { System.loadLibrary("ysixprobe"); }
    public static native String inspect(int gameFd, String gameName, int prodKeysFd, int titleKeysFd);
    private NativeProbe() { }
}
