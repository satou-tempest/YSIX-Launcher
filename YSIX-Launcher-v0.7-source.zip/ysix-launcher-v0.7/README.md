# YS IX: Monstrum Nox — Android native runtime bring-up v0.7.0

An unofficial, game-specific Android native-port attempt for **Ys IX: Monstrum Nox**. This is not a general-purpose Switch emulator.

> **Status:** v0.7 is the first build that attempts to start the actual ARM64 game executable through a native execution runtime. It is an experimental boot attempt, not a playable release. It may terminate before the title screen.

## What changed in v0.7

- Adds a `GameActivity` NativeActivity backed by `libysix.so`.
- Builds the generic MIT-licensed SwitchGamesRecomp/P5R runtime in `NX_NCE=ON` mode. The game-specific P5R patches are not copied or enabled.
- Hands the selected NSP/XCI, `prod.keys`, and optional `title.keys` to native code using duplicated Android SAF file descriptors. Key bytes and game data are not copied into the APK, logged, or uploaded.
- Uses the reference runtime's native AArch64 execution bridge, Horizon-style kernel/HLE layer, dynamic linker, memory manager, generic NVN-to-Vulkan implementation, audio/input/window platform layer, and startup path.
- Extends the runtime loader to parse and load Ys IX's `main`, `sdk`, `subsdk0`, and `subsdk1` NSOs together. The reference runtime replaces the normal `rtld` entry path with its own `nn::init::Start` startup shim.
- Reserves a 1 GiB guest module address range for four 256 MiB-spaced modules.
- Keeps the v0.6 pre-boot diagnostic and Vulkan report, save ZIP workspace, and DLC package queue.
- Adds a **TRY NATIVE BOOT** action and a viewer for the last native runtime log (`nx.log`).

## What this build does not promise

A NativeActivity launch is not proof of gameplay. Ys IX-specific runtime support is still incomplete. The first boot attempt may expose missing imports, incomplete Switch services, incorrect assumptions about the additional NSO modules, unsupported video/movie functions, TLS or thread issues, filesystem/save limitations, or NVN/shader issues. The generic runtime may route unresolved imports to logging stubs; those are diagnostics, not real implementations.

The save ZIP workspace is not connected to Ys IX's live save service. DLC packages are queued only and are not installed, activated, or mounted. The v0.7 build does not claim that either feature works in-game.

## Build with GitHub Actions

Upload these two files to your repository:
- `YSIX-Launcher-v0.7-source.zip` at the repository root.
- `.github/workflows/ysix-v0.7-native-runtime.yml` at that exact path.

Then open **Actions → Build YS IX v0.7 Native Runtime Boot Attempt → Run workflow**. The workflow:
1. runs the host-side synthetic relocation regression test;
2. fetches the generic importer source from the pinned MIT reference commit;
3. checks out the same pinned reference runtime;
4. applies the Ys IX-specific runtime adaptations in `tools/runtime-bridge/patch_p5r_runtime.py` and checks them against a synthetic upstream-source fixture;
5. builds the ARM64 NCE runtime with the Android NDK;
6. packages `libysix.so` alongside the diagnostic JNI library and launcher UI.

The expected artifact is `ysix-v0.7-native-runtime-debug-apk`.

## Install and test

1. Install the v0.7 debug APK from the GitHub Actions artifact. Its `.debug.v07` package ID lets it coexist with earlier test builds.
2. In **Library**, select your own complete Ys IX `.nsp` or `.xci`, `prod.keys`, and optional `title.keys` again. Android does not share persisted document grants between different app IDs.
3. First run **RUN LOADER + GPU TEST** and save the report.
4. Then press **TRY NATIVE BOOT** and accept the experimental warning.
5. If the native activity returns or crashes, reopen the launcher and use **VIEW LAST NATIVE BOOT LOG**. The runtime writes `nx.log` in the app's external files directory when diagnostics are enabled.
6. Test the Redmi Turbo 4 first, then the Galaxy A22 5G, and keep both logs separate.

The v0.7 package ID creates a separate private archive workspace. Export any save-archive workspace you need from an older install before removing it, then import that ZIP into v0.7. These are archive files only, not live Ys IX saves.

A crash is useful only when we have the final `nx.log` and know which device produced it. Do not upload your game image, keys, decrypted modules, save data, or DLC files to GitHub or issue reports.

## Current known compatibility risks

- v0.6 reported 22 unresolved strong imports from the `movie::*` namespace. Loading `subsdk0` and `subsdk1` may resolve some of them; the v0.7 runtime log must confirm whether they are found. Any remaining ones need proper Ys IX-compatible implementations, not fake success stubs.
- `rtld` is not loaded as a separate NSO in this initial adaptation; the reference runtime replaces the rtld startup callbacks. This needs verification against Ys IX's actual startup requirements.
- Ys IX-specific `main.npdm` resource settings, module dependencies, services and video/movie behavior need further inspection.
- The generic NVN-to-Vulkan implementation has not been validated with Ys IX's shader containers on either Mali GPU. Passing the Vulkan device probe does not prove the game renderer works.
- Native execution requires ARM64/AArch64; the APK is built for `arm64-v8a` only.

## Third-party source

The generic runtime and importer are fetched at build time from `Brandon04Gonzalez/p5r-android`, pinned to commit `645c717afbc0610f9da38b0cc1d6834820ffa76a`, under its MIT license. Ys IX uses its own `games/ysix/game.cpp` identity file and no Persona 5 Royal game-specific patches. See `THIRD_PARTY_NOTICES.md`.
