# Third-party notices

## SwitchGamesRecomp / P5R Android native runtime and generic Switch importer

Source: https://github.com/Brandon04Gonzalez/p5r-android
Pinned commit: `645c717afbc0610f9da38b0cc1d6834820ffa76a`
License: MIT. The pinned upstream `LICENSE` file is fetched by the GitHub Actions workflow into the build workspace.

The v0.7 build uses the generic runtime, native execution bridge, kernel/HLE, loader, NVN/Vulkan implementation, Android platform layer, game-image importer and cryptographic primitives as an architectural/runtime base. It does **not** copy the Persona 5 Royal game-specific `games/p5r/game.cpp`, P5R-specific shader tools, game assets, game code, save files, or other copyrighted game data. A separate `games/ysix/game.cpp` supplies the Ys IX title identity and empty game hooks.

The MIT license notice and permission notice must accompany any redistribution of substantial portions of the upstream code. No P5R APK or game dump is included.
