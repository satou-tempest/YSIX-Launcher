# Changelog

## v1.2.0 — investigation baseline

- Bumps Android package version to 1.2.0 / versionCode 12.
- Adds a host-side `nx.log` analyzer for FPS, stall samples, draw completion, missing textures, shader-cache misses, audio renderer state and input delivery.
- Adds analyzer regression tests and a v1.2 GitHub Actions build workflow.
- Documents the Redmi Turbo 4 persistent-stall investigation and evidence-based Mali-G720 graphics gates.
- No gameplay, graphics, performance or audio fix is claimed in this first v1.2 slice.

## v1.1.0 — game shader discovery and Vulkan diagnostics

- Scans RomFS, supported VFS3 archives and the main NSO for validated Ys IX shader records.
- Adds VFS3 decompression support and batch shader translation/preparation UI.
- Expands Vulkan device and image-format capability diagnostics.
- Retains runtime shader capture, FPS overlay, input tracing and audio discovery diagnostics.
