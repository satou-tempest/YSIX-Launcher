#!/usr/bin/env python3
"""Summarize Ys IX runtime logs without treating diagnostic hints as root-cause proof."""
from __future__ import annotations
import argparse
import json
import re
from pathlib import Path

FPS_RE = re.compile(r"per frame over 60:\s*([0-9]+(?:\.[0-9]+)?)\s*fps", re.I)
STALL_RE = re.compile(r"(?:stall(?:ed)?|stalls?)\D{0,32}([0-9]+(?:\.[0-9]+)?)\s*ms", re.I)
NO_PROGRAM_RE = re.compile(r"([0-9,]+)\s+total,\s*([0-9,]+)\s+done,\s*([0-9,]+)\s+no program", re.I)


def analyze(text: str) -> dict:
    lines = text.splitlines()
    fps = [float(m.group(1)) for line in lines if (m := FPS_RE.search(line))]
    stalls = [float(m.group(1)) for line in lines if (m := STALL_RE.search(line))]
    draw_stats = []
    for line in lines:
        m = NO_PROGRAM_RE.search(line)
        if m:
            draw_stats.append({"total": int(m.group(1).replace(',', '')),
                               "done": int(m.group(2).replace(',', '')),
                               "no_program": int(m.group(3).replace(',', ''))})
    textures = []
    for line in lines:
        m = re.search(r"textures not ready:\s*([0-9,]+)\s+no image", line, re.I)
        if m:
            textures.append(int(m.group(1).replace(',', '')))
    audio_no_thread = any("no render thread started" in x.lower() for x in lines)
    audio_open = any("renderer opened (result 0)" in x.lower() for x in lines)
    touch_events = sum("input: touch kind=" in x for x in lines)
    pad_changes = sum("input: guest pad buttons=" in x for x in lines)
    missing_shaders = sum(("missing" in x.lower() and "spir" in x.lower() and "cache" in x.lower()) for x in lines)
    return {
        "line_count": len(lines),
        "fps_samples": fps,
        "fps_min": min(fps) if fps else None,
        "fps_max": max(fps) if fps else None,
        "stall_samples_ms": stalls,
        "draw_stats": draw_stats,
        "textures_not_ready_no_image": textures,
        "shader_cache_missing_messages": missing_shaders,
        "audio_renderer_open_succeeded": audio_open,
        "audio_render_thread_missing": audio_no_thread,
        "touch_event_count": touch_events,
        "guest_pad_state_change_count": pad_changes,
        "interpretation_limits": [
            "FPS samples measure reported presentation rate, not CPU or GPU utilization.",
            "Stall log matches are diagnostic samples, not proof of a deadlock.",
            "Missing textures and no-program draws are symptoms; this report does not identify their root cause.",
            "Touch events and guest pad-state changes are counted separately."
        ]
    }


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("log", type=Path)
    ap.add_argument("--json", action="store_true", help="print machine-readable JSON")
    args = ap.parse_args()
    result = analyze(args.log.read_text(encoding="utf-8", errors="replace"))
    if args.json:
        print(json.dumps(result, indent=2))
        return
    print(f"Lines: {result['line_count']}")
    print(f"FPS samples: {result['fps_samples'] or 'none'} (min={result['fps_min']}, max={result['fps_max']})")
    print(f"Stall samples: {result['stall_samples_ms'] or 'none'} ms")
    print(f"Draw stats: {result['draw_stats'] or 'none'}")
    print(f"Textures not ready/no image: {result['textures_not_ready_no_image'] or 'none'}")
    print(f"Missing shader-cache messages: {result['shader_cache_missing_messages']}")
    print(f"Audio renderer opened: {result['audio_renderer_open_succeeded']}; render thread missing: {result['audio_render_thread_missing']}")
    print(f"Touch events: {result['touch_event_count']}; guest pad changes: {result['guest_pad_state_change_count']}")
    print("Limits: " + " ".join(result["interpretation_limits"]))


if __name__ == "__main__":
    main()
