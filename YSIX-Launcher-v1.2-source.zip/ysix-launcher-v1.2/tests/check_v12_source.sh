#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
bash "$ROOT/tests/check_v11_shader_source.sh"
python3 "$ROOT/tests/test_log_analyzer.py"
python3 -m py_compile "$ROOT/tools/analyze_nx_log.py"
python3 - <<'PY' "$ROOT"
from pathlib import Path
import sys
r=Path(sys.argv[1])
assert "versionCode 12" in (r/'app/build.gradle').read_text()
assert "versionName '1.2.0'" in (r/'app/build.gradle').read_text()
w=(r/'.github/workflows/ysix-v1.2-diagnostics.yml').read_text()
assert 'ysix-v1.2-diagnostics-debug-apk' in w
assert 'check_v12_source.sh' in w
PY
echo "YS IX v1.2 source checks: PASS"
