import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("analyzer", ROOT / "tools/analyze_nx_log.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

sample = """per frame over 60: 59.8 fps
per frame over 60: 2.7 fps
stall profiler: stalled 414 ms
12657 total, 12074 done, 583 no program
textures not ready: 26 no image
audio: renderer opened (result 0), impl 0
audio: renderer lookup found no object matching the reference vtable; no render thread started
input: touch kind=0 pointer=0/1 at 10,20
input: guest pad buttons=0000000000000001 left=0,0 right=0,0
"""
r = module.analyze(sample)
assert r["fps_min"] == 2.7 and r["fps_max"] == 59.8
assert r["stall_samples_ms"] == [414.0]
assert r["draw_stats"] == [{"total": 12657, "done": 12074, "no_program": 583}]
assert r["textures_not_ready_no_image"] == [26]
assert r["audio_renderer_open_succeeded"] and r["audio_render_thread_missing"]
assert r["touch_event_count"] == 1 and r["guest_pad_state_change_count"] == 1
print("YS IX log analyzer tests: PASS")
