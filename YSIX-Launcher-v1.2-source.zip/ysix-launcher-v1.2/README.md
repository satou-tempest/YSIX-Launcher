# YS IX: Monstrum Nox — Android native runtime experiment v1.2

**Status: experimental; not yet verified as playable.** The Redmi Turbo 4 (Dimensity 8400-Ultra, Mali-G720 MC7) is the primary target. The Samsung Galaxy A22 5G is a secondary regression device.

## v1.2 starting point

v1.2 is based on the v1.1 source and preserves its native runtime integration, Ys IX game-image shader discovery, VFS3 archive scanning/decompression, shader preparation UI, Vulkan capability diagnostics, FPS counter, touch tracing and audio discovery instrumentation.

The first v1.2 implementation adds:

- A reproducible host-side `nx.log` analyzer (`tools/analyze_nx_log.py`).
- Regression tests for the analyzer and a v1.2 source-check script.
- A v1.2 GitHub Actions workflow and Android versionCode/versionName bump.
- An investigation plan prioritizing the persistent guest main-thread stall, then Mali-G720 rendering faults, shader/pipeline coverage, input delivery and audio.

## Current unresolved issues

- Gameplay frame rate collapses to approximately 2.6–2.7 FPS in the latest Redmi Turbo 4 log.
- The profiler samples the guest main thread in `nnMain`/critical-section paths while Vulkan command timings remain comparatively short. This is a lead, not proof of a deadlock.
- Texture readiness reports missing images and draw counters report draws without a usable program. Their root causes are not yet established.
- Touch controls become unresponsive during the reported gameplay stall; Android touch events and guest pad-state changes must be compared.
- Audio renderer lookup fails to find the expected object; no audio render thread starts.

**No v1.2 gameplay, graphics, performance, input or audio fix is claimed yet.** See [docs/V1.2-INVESTIGATION.md](docs/V1.2-INVESTIGATION.md).

## Build

Upload this source archive to the repository root and run **Actions → Build YS IX v1.2 Diagnostics → Run workflow**. The workflow produces `ysix-v1.2-diagnostics-debug-apk`.

A successful CI run proves build/package success only. It does not prove that the Redmi graphics, gameplay performance, controls or audio are fixed.

## Analyze a runtime log

```sh
python3 tools/analyze_nx_log.py /path/to/nx.log
python3 tools/analyze_nx_log.py /path/to/nx.log --json
```

The analyzer reports observations and explicitly avoids converting symptoms into unverified root-cause claims.
