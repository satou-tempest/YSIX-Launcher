package io.github.ysix.launcher;

/** JNI bridge for the v0.4 native package/ExeFS and Vulkan bring-up tests. */
public final class NativeProbe {
    static { System.loadLibrary("ysixprobe"); }
    public static native String inspect(int gameFd, String gameName, int prodKeysFd, int titleKeysFd);
    private NativeProbe() { }
}
