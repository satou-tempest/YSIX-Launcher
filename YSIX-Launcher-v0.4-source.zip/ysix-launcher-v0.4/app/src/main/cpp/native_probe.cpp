#include <jni.h>
#include <android/log.h>
#include <vulkan/vulkan.h>

#include <algorithm>
#include <cstdint>
#include <exception>
#include <cstring>
#include <iomanip>
#include <map>
#include <memory>
#include <sstream>
#include <string>
#include <vector>

#include "nxcrypto.h"
#include "nxgame.h"

namespace {
constexpr const char* kTag = "YSIX-NATIVE";

std::string jstr(JNIEnv* env, jstring value) {
    if (!value) return {};
    const char* p = env->GetStringUTFChars(value, nullptr);
    if (!p) return {};
    std::string result(p);
    env->ReleaseStringUTFChars(value, p);
    return result;
}

std::string api_version(uint32_t v) {
    std::ostringstream s;
    s << VK_VERSION_MAJOR(v) << '.' << VK_VERSION_MINOR(v) << '.' << VK_VERSION_PATCH(v);
    return s.str();
}

std::string build_id(const std::vector<uint8_t>& nso) {
    if (nso.size() < 0x60 || std::memcmp(nso.data(), "NSO0", 4)) return "invalid NSO";
    std::ostringstream s;
    s << std::uppercase << std::hex << std::setfill('0');
    for (size_t i=0x40; i<0x60; ++i) s << std::setw(2) << unsigned(nso[i]);
    return s.str();
}

bool validate_nso(const std::vector<uint8_t>& nso, std::string& error) {
    if (nso.size() < 0x100 || std::memcmp(nso.data(), "NSO0", 4)) {
        error = "NSO header is absent or invalid";
        return false;
    }
    std::vector<uint8_t> flat;
    return nxi::nso_to_flat_image(nso, flat, error);
}

const char* gpu_type(VkPhysicalDeviceType t) {
    switch (t) {
        case VK_PHYSICAL_DEVICE_TYPE_INTEGRATED_GPU: return "integrated GPU";
        case VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU: return "discrete GPU";
        case VK_PHYSICAL_DEVICE_TYPE_VIRTUAL_GPU: return "virtual GPU";
        case VK_PHYSICAL_DEVICE_TYPE_CPU: return "CPU Vulkan device";
        default: return "other";
    }
}

bool has_ext(const std::vector<VkExtensionProperties>& exts, const char* name) {
    return std::any_of(exts.begin(), exts.end(), [name](const VkExtensionProperties& e) {
        return std::strcmp(e.extensionName, name) == 0;
    });
}

void format_report(std::ostringstream& out, VkPhysicalDevice gpu, VkFormat format, const char* name) {
    VkFormatProperties p{};
    vkGetPhysicalDeviceFormatProperties(gpu, format, &p);
    out << "  " << name
        << ": sampled=" << ((p.optimalTilingFeatures & VK_FORMAT_FEATURE_SAMPLED_IMAGE_BIT) ? "yes" : "no")
        << ", color-target=" << ((p.optimalTilingFeatures & VK_FORMAT_FEATURE_COLOR_ATTACHMENT_BIT) ? "yes" : "no")
        << '\n';
}

void vulkan_probe(std::ostringstream& out) {
    out << "\n[VULKAN NATIVE PROBE]\n";
    uint32_t loader = VK_API_VERSION_1_0;
    auto enumVersion = reinterpret_cast<PFN_vkEnumerateInstanceVersion>(
        vkGetInstanceProcAddr(VK_NULL_HANDLE, "vkEnumerateInstanceVersion"));
    if (enumVersion) enumVersion(&loader);
    out << "Loader API: " << api_version(loader) << '\n';
    if (loader < VK_API_VERSION_1_1) {
        out << "Vulkan result: FAIL (requires Vulkan 1.1+)\n";
        return;
    }

    VkApplicationInfo app{VK_STRUCTURE_TYPE_APPLICATION_INFO};
    app.pApplicationName = "YS IX Native Probe";
    app.applicationVersion = VK_MAKE_VERSION(0,4,0);
    app.pEngineName = "YSIX bring-up";
    app.engineVersion = VK_MAKE_VERSION(0,4,0);
    app.apiVersion = std::min(loader, uint32_t(VK_API_VERSION_1_3));

    VkInstanceCreateInfo ici{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};
    ici.pApplicationInfo = &app;
    VkInstance instance = VK_NULL_HANDLE;
    VkResult vr = vkCreateInstance(&ici, nullptr, &instance);
    if (vr != VK_SUCCESS) {
        out << "vkCreateInstance: FAIL (" << int(vr) << ")\n";
        return;
    }
    out << "vkCreateInstance: PASS\n";

    uint32_t count = 0;
    vr = vkEnumeratePhysicalDevices(instance, &count, nullptr);
    if (vr != VK_SUCCESS || count == 0) {
        out << "No physical Vulkan devices (VkResult " << int(vr) << ")\n";
        vkDestroyInstance(instance, nullptr);
        return;
    }
    std::vector<VkPhysicalDevice> gpus(count);
    vr = vkEnumeratePhysicalDevices(instance, &count, gpus.data());
    if (vr != VK_SUCCESS) {
        out << "vkEnumeratePhysicalDevices: FAIL (" << int(vr) << ")\n";
        vkDestroyInstance(instance, nullptr);
        return;
    }

    bool devicePass = false;
    for (uint32_t i=0; i<count; ++i) {
        VkPhysicalDevice gpu = gpus[i];
        VkPhysicalDeviceProperties props{};
        vkGetPhysicalDeviceProperties(gpu, &props);
        out << "GPU " << (i+1) << ": " << props.deviceName << " (" << gpu_type(props.deviceType) << ")\n";
        out << "  Vendor/device: 0x" << std::hex << props.vendorID << "/0x" << props.deviceID << std::dec << '\n';
        out << "  Device API: " << api_version(props.apiVersion) << ", driver version: " << props.driverVersion << '\n';
        out << "  Max image 2D: " << props.limits.maxImageDimension2D
            << ", descriptor sets: " << props.limits.maxBoundDescriptorSets << '\n';

        uint32_t ec=0;
        vkEnumerateDeviceExtensionProperties(gpu, nullptr, &ec, nullptr);
        std::vector<VkExtensionProperties> exts(ec);
        if (ec) vkEnumerateDeviceExtensionProperties(gpu, nullptr, &ec, exts.data());
        out << "  VK_KHR_swapchain: " << (has_ext(exts, VK_KHR_SWAPCHAIN_EXTENSION_NAME) ? "yes" : "no") << '\n';
        out << "  VK_KHR_shader_float_controls: " << (has_ext(exts, "VK_KHR_shader_float_controls") ? "yes" : "no/core") << '\n';
        format_report(out, gpu, VK_FORMAT_ASTC_4x4_UNORM_BLOCK, "ASTC 4x4");
        format_report(out, gpu, VK_FORMAT_BC7_UNORM_BLOCK, "BC7");

        VkPhysicalDeviceMemoryProperties mem{};
        vkGetPhysicalDeviceMemoryProperties(gpu, &mem);
        for (uint32_t h=0; h<mem.memoryHeapCount; ++h) {
            out << "  Heap " << h << ": " << (mem.memoryHeaps[h].size / (1024*1024)) << " MiB"
                << ((mem.memoryHeaps[h].flags & VK_MEMORY_HEAP_DEVICE_LOCAL_BIT) ? " device-local" : " shared") << '\n';
        }

        uint32_t qc=0;
        vkGetPhysicalDeviceQueueFamilyProperties(gpu, &qc, nullptr);
        std::vector<VkQueueFamilyProperties> queues(qc);
        if (qc) vkGetPhysicalDeviceQueueFamilyProperties(gpu, &qc, queues.data());
        uint32_t graphics=UINT32_MAX;
        for (uint32_t q=0; q<qc; ++q) {
            out << "  Queue " << q << ": count=" << queues[q].queueCount
                << ", graphics=" << ((queues[q].queueFlags & VK_QUEUE_GRAPHICS_BIT) ? "yes" : "no")
                << ", compute=" << ((queues[q].queueFlags & VK_QUEUE_COMPUTE_BIT) ? "yes" : "no") << '\n';
            if (graphics==UINT32_MAX && queues[q].queueCount && (queues[q].queueFlags & VK_QUEUE_GRAPHICS_BIT))
                graphics=q;
        }
        if (graphics==UINT32_MAX) {
            out << "  Logical device: skipped (no graphics queue)\n";
            continue;
        }

        const float priority=1.0f;
        VkDeviceQueueCreateInfo qci{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};
        qci.queueFamilyIndex=graphics;
        qci.queueCount=1;
        qci.pQueuePriorities=&priority;
        VkDeviceCreateInfo dci{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};
        dci.queueCreateInfoCount=1;
        dci.pQueueCreateInfos=&qci;
        VkDevice logical=VK_NULL_HANDLE;
        vr=vkCreateDevice(gpu,&dci,nullptr,&logical);
        if (vr!=VK_SUCCESS) {
            out << "  vkCreateDevice: FAIL (" << int(vr) << ")\n";
            continue;
        }
        VkQueue queue=VK_NULL_HANDLE;
        vkGetDeviceQueue(logical,graphics,0,&queue);
        vr=queue ? vkDeviceWaitIdle(logical) : VK_ERROR_INITIALIZATION_FAILED;
        out << "  Graphics queue/device test: " << (vr==VK_SUCCESS ? "PASS" : "FAIL")
            << " (VkResult " << int(vr) << ")\n";
        devicePass |= (vr==VK_SUCCESS);
        vkDestroyDevice(logical,nullptr);
    }
    out << "Vulkan device initialization: " << (devicePass ? "PASS" : "FAIL") << '\n';
    out << "Note: v0.4 does not create a surface/swapchain or render an NVN frame.\n";
    vkDestroyInstance(instance,nullptr);
}

std::string inspect(int gameFd, const std::string& gameName, int keysFd, int titleKeysFd) {
    std::ostringstream out;
    out << "YS IX: MONSTRUM NOX - v0.4 NATIVE BRING-UP\n";
#if defined(__aarch64__)
    out << "Build ABI: ARM64/AArch64 native\n";
#else
    out << "Build ABI: ERROR - not AArch64\n";
#endif
    out << "Game input: " << gameName << '\n';
    out << "Key files: passed by file descriptor; key material is never written to the report.\n";
    const bool cryptoOk = nxi::crypto_self_test();
    out << "AES/SHA/CRC self-test: " << (cryptoOk ? "PASS" : "FAIL") << '\n';
    if (!cryptoOk) {
        out << "Container parsing skipped because the cryptographic self-test failed.\n";
        vulkan_probe(out);
        return out.str();
    }

    std::vector<nxi::InputFile> input;
    input.push_back({gameName, gameFd});
    input.push_back({"prod.keys", keysFd});
    if (titleKeysFd >= 0) input.push_back({"title.keys", titleKeysFd});
    std::string error;
    auto game = nxi::GameImage::open(input, 0, error);
    if (!game) {
        out << "\n[GAME IMAGE / EXEFS]\nOpen/decrypt: FAIL\nReason: "
            << (error.empty() ? "unknown importer error" : error) << '\n';
        out << "The selected game dump was not modified.\n";
        vulkan_probe(out);
        return out.str();
    }

    out << "\n[GAME IMAGE / EXEFS]\nOpen/decrypt: PASS\n";
    out << "Detected title ID: " << std::uppercase << std::hex << std::setw(16)
        << std::setfill('0') << game->title_id() << std::dec << '\n';
    const auto& exefs=game->exefs();
    out << "ExeFS entries: " << exefs.size() << '\n';
    for (const auto& e: exefs) out << "  " << e.first << " - " << e.second.size() << " bytes\n";

    bool mainOk=false, sdkOk=false;
    auto m=exefs.find("main");
    if (m!=exefs.end()) {
        out << "main build ID: " << build_id(m->second) << '\n';
        std::string why;
        mainOk=validate_nso(m->second,why);
        out << "main NSO segment/hash check: " << (mainOk ? "PASS" : "FAIL") << '\n';
        if (!mainOk) out << "  Reason: " << why << '\n';
    } else out << "main: MISSING\n";

    auto sdk=exefs.find("sdk");
    if (sdk!=exefs.end()) {
        std::string why;
        sdkOk=validate_nso(sdk->second,why);
        out << "sdk NSO segment/hash check: " << (sdkOk ? "PASS" : "FAIL") << '\n';
        if (!sdkOk) out << "  Reason: " << why << '\n';
    } else out << "sdk: MISSING\n";

    out << "Gate A (read/decrypt main + SDK): " << (mainOk && sdkOk ? "PASS" : "INCOMPLETE") << '\n';
    out << "Gate B (map modules and enter game): NOT ATTEMPTED IN v0.4\n";
    out << "Gameplay: NOT BOOTABLE YET - this is a native test harness.\n";
    out << "Game dump is read in place; no upload or extraction is performed.\n";
    vulkan_probe(out);
    return out.str();
}
} // namespace

extern "C" JNIEXPORT jstring JNICALL
Java_io_github_ysix_launcher_NativeProbe_inspect(JNIEnv* env, jclass, jint gameFd, jstring gameName, jint keysFd, jint titleKeysFd) {
    std::string report;
    try {
        report=inspect(gameFd,jstr(env,gameName),keysFd,titleKeysFd);
    } catch (const std::exception& e) {
        report=std::string("YSIX native probe exception: ")+e.what();
    } catch (...) {
        report="YSIX native probe failed with an unknown native exception.";
    }
    __android_log_print(ANDROID_LOG_INFO,kTag,"%s",report.c_str());
    return env->NewStringUTF(report.c_str());
}
