# Changelog

## v0.4.0 — Native bring-up test
- Added Android NDK/CMake build for an ARM64 JNI shared library (`libysixprobe.so`).
- Integrated the MIT-licensed generic NSP/XCI importer and AES/SHA/CRC self-tests from the pinned P5R Android source.
- Added local package open/decrypt and ExeFS `main`/`sdk` NSO integrity checks.
- Added Vulkan physical-device, feature, format, memory, queue-family, logical-device and queue-idle diagnostics.
- Added an on-device report and logcat output (`YSIX-NATIVE`).
- Explicitly does not attempt game boot, Switch service execution, NVN shader/command translation or gameplay.

## v0.3.0
- Launcher, file references, settings and Java-side diagnostics.
