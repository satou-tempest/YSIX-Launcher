# YS IX: Monstrum Nox — Android project v0.4.0

An unofficial fan-made Android native bring-up project for **Ys IX: Monstrum Nox**. v0.4 is the first build that compiles and executes native C++ on Android ARM64; it is no longer a Java-only launcher.

> **Important: v0.4 is a native diagnostic/test build, not a playable game release.** It attempts to open and decrypt the user's local NSP/XCI, validates ExeFS `main` and `sdk` NSO images, and probes real Vulkan device/queue initialization. It does not map/execute the game, implement Ys IX's Switch service layer, translate NVN/Maxwell shaders, or boot gameplay.

## v0.4 features

- Five-section UI: Home, Library, Graphics, Controls, and Diagnostics.
- Gothic adaptive/round/monochrome launcher icon.
- Android SAF selection of a complete `.nsp` / `.xci` and `prod.keys`.
- Native ARM64 JNI library (`libysixprobe.so`) built by Android NDK + CMake.
- Local AES-128 / SHA-256 / CRC self-tests.
- Native NSP/XCI opening/decryption and automatic title ID detection using the upstream generic importer.
- ExeFS `main` / `sdk` NSO segment decompression and integrity checks.
- Vulkan loader, physical-device, extension, format support, memory heap, queue-family and logical-device diagnostics.
- On-device report plus Android logcat tag `YSIX-NATIVE`.
- Selected files stay on device. Key material is never included in the report.

## Target devices

| Device | SoC | GPU | RAM |
|---|---|---|---:|
| Redmi Turbo 4 | MediaTek Dimensity 8400-Ultra | Mali-G720 MC7 | 12 GB |
| Samsung Galaxy A22 5G | MediaTek Dimensity 700 | Mali-G57 MC2 | 8 GB |

Both are ARM64 Android devices. This native probe will reveal whether the image parser and Vulkan device initialization work on each device; it does not establish that the future renderer or game will be compatible.

## Build with GitHub Actions

The provided workflow is `.github/workflows/ysix-v0.4-native.yml`. Upload these two files to the repository:
- `YSIX-Launcher-v0.4-source.zip` (source archive)
- `.github/workflows/ysix-v0.4-native.yml` (workflow)

Run **Actions → Build YS IX v0.4 Native Probe → Run workflow**. The workflow fetches the generic importer from a pinned public MIT-licensed upstream commit, installs JDK/Android SDK/NDK/CMake, and builds the debug APK. It uploads `app-debug.apk` as an artifact.

Build requirements: JDK 17, Android Platform 35, Build Tools 35.0.0, NDK `28.2.13676358`, CMake `3.22.1`, Gradle `8.9`, and Android Gradle Plugin `8.7.3`.

## Run the native test

1. Install the debug APK on your phone.
2. In Library, select a **complete** Ys IX `.nsp` or `.xci` and the file named exactly `prod.keys`. Add `title.keys` as an optional second key file when your NSP dump requires it.
3. Tap **Run Native Test** on Home or Diagnostics.
4. Save/copy the complete `YS IX · NATIVE TEST REPORT`, or capture logcat entries with tag `YSIX-NATIVE`.

The app passes open file descriptors to the native code. It does not copy or upload your game image or keys. This first UI does not support split XCI parts; use one complete XCI or NSP.

## What is not in v0.4

- Ys IX game module mapping/relocation and native code execution (NCE).
- Ys IX-specific Switch services, SDK glue or game patches.
- NVN command/resource translation to Vulkan.
- Maxwell shader translation and shader cache.
- Game surface/swapchain rendering, audio, video, save data, input bridge or gameplay.

A successful v0.4 report means the selected game container could be opened and its checked modules validated, and the phone could initialize a Vulkan logical device/graphics queue. It does **not** mean Ys IX can boot.

## Runtime direction

The target remains a **game-specific native Android port**, not a general-purpose Switch emulator. The public P5R Android source is an architectural reference. v0.4 reuses only its generic, MIT-licensed content importer/crypto code; it does not reuse P5R game-specific code as Ys IX compatibility. See `docs/V0.4-NATIVE-TEST.md`, `docs/RUNTIME-PORT-PLAN.md`, and `THIRD_PARTY_NOTICES.md`.

## Legal / content boundary

This repository contains no Ys IX game dump, firmware, encryption keys, save data or shader cache. Use only data you are legally entitled to use. Never upload your dump or keys to the repository or share them in issue reports.
