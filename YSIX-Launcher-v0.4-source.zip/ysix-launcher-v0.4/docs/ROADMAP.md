# Development roadmap

## v0.1 — Launcher foundation
Completed: initial Java-only UI, document pickers and saved preferences.

## v0.2 — Visual identity
Completed: gothic adaptive launcher icon patch.

## v0.3 — Launcher/runtime bring-up frontend
Completed: navigation, library selection, graphics/control preferences and Java-side hardware diagnostics.

## v0.4 — Native bring-up test
Current target: native ARM64 JNI library, local NSP/XCI open/decryption, title-ID detection, ExeFS `main`/`sdk` NSO integrity checks, and Vulkan device/queue initialization report. This is a real native C++ test but not a game boot.

## v0.5 — Ys IX loader reconnaissance
Next: analyze the observed Ys IX `main` build ID, module set, relocations/imports and SDK, then adapt the NCE loader entry path and produce explicit loader diagnostics.

## v0.6+ — Game compatibility
Implement the required Switch services and NVN/Vulkan + Maxwell shader path from evidence in the Ys IX binary. Add Mali compatibility work and validate audio, input, video, saves and sustained gameplay. Do not claim playability until an interactive scene has passed device testing.
