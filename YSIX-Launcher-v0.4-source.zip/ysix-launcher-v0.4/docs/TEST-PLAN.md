# v0.4 device test plan

## What v0.4 should test

- Debug APK installs and launches on Android 10+ / ARM64.
- Native library `libysixprobe.so` loads through JNI.
- Local importer AES/SHA/CRC known-answer tests pass.
- Complete Ys IX NSP/XCI and `prod.keys` open successfully.
- Application title ID is detected from the container.
- ExeFS `main` and `sdk` modules are found, decompressed and hash-validated.
- Vulkan loader, physical device, queue family and logical device are reported.
- UI report and `YSIX-NATIVE` logcat output are produced.

## Redmi Turbo 4

1. Install the v0.4 debug APK.
2. Select a complete base-game NSP or XCI, then `prod.keys`.
3. Tap **Run Native Test**.
4. Save the full report. Note detected title ID, `main` build ID, ExeFS module list, NSO integrity results, Vulkan API/device name, ASTC/BC7 format flags and queue/device result.

## Galaxy A22 5G

Repeat the same procedure. Compare results with the Redmi Turbo 4. Do not assume G720 behavior carries over to G57.

## Failure interpretation

- Importer crypto self-test fails: native importer/crypto integration problem.
- Container open/decrypt fails: input, key, unsupported container layout or importer issue.
- No `main` or `sdk`: incompatible/incomplete dump or different module layout.
- NSO hash check fails: damaged/unsupported module image or parser issue.
- Vulkan instance/device/queue fails: phone's Vulkan loader/driver path issue.
- All probes pass: the native foundation is functioning; game boot remains a separate, not-yet-implemented milestone.

## Not testable in v0.4

Game module mapping/relocation, guest entry, Switch services, NVN command execution, shader translation, rendered frames, audio, input, saves and gameplay.
