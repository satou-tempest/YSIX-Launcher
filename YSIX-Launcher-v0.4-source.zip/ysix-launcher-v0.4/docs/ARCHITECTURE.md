# Architecture notes — v0.4.0

## Current application

- **Java UI:** Home, Library, Graphics, Controls and Diagnostics.
- **Native bridge:** `NativeProbe.java` calls `libysixprobe.so` by JNI.
- **Android NDK/CMake:** builds for `arm64-v8a`, Android API 29+.
- **Game image layer:** MIT-licensed generic PFS0/HFS0/NCA/NSO importer and crypto code compiled from pinned upstream source.
- **ExeFS validation:** `main` and `sdk` are decompressed and checked by `nso_to_flat_image`.
- **GPU probe:** uses the Android Vulkan loader to enumerate physical devices, features, format properties, memory heaps and queue families, then creates a logical device and idles one graphics queue.

## Native call path

`MainActivity.runNativeProbe()` opens both persisted SAF URIs as `ParcelFileDescriptor`s. It passes the FDs and game filename to `NativeProbe.inspect()`. The C++ function:
1. runs importer crypto known-answer tests;
2. opens the game image with title ID auto-detection (`title_id = 0`);
3. reads the ExeFS `main` and `sdk` modules;
4. verifies and decompresses their NSO segments;
5. probes Vulkan and returns a report to the UI/logcat.

The JNI method runs on a worker thread so package parsing does not block the UI thread. File descriptors stay open until native inspection returns.

## Explicitly not implemented

No game loader, module relocation, TLS/thread bootstrap, AArch64 NCE entry, Switch IPC/service compatibility, game-specific SDK hooks, NVN-to-Vulkan execution, shader translation, surface/swapchain or frame rendering is integrated in v0.4. The upstream P5R runtime is substantially more than the importer and cannot be treated as a drop-in Ys IX runtime.

## Intended next integration gates

1. **Binary reconnaissance:** record Ys IX title ID, `main` build ID, modules, SDK version, relocations and imports from the user's own dump.
2. **NCE loader:** adapt the native execution and NSO-loading architecture, then map modules and prove a controlled entry path.
3. **Services:** implement only the services Ys IX actually requests, with explicit unsupported-call diagnostics.
4. **Graphics:** identify its GPU API usage and implement the required NVN/resource/shader path, including Mali compatibility.
5. **Device/game acceptance:** first frame, input/audio, interactive menu, stable scene, save/load.

No milestone is marked done until a device report or test proves it.
