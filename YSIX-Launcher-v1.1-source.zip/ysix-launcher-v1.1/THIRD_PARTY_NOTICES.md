# Third-party notices

## SwitchGamesRecomp / P5R Android generic native runtime and importer
Source: https://github.com/Brandon04Gonzalez/p5r-android
Pinned commit: `645c717afbc0610f9da38b0cc1d6834820ffa76a`
License: MIT. The pinned upstream `LICENSE` is included in the APK assets.

v0.8 uses the generic native execution bridge, kernel/HLE, loader, NVN/Vulkan implementation, Android platform layer, game-image importer and cryptographic primitives. The Persona 5 Royal game-specific hooks and static CPK/GSC shader extractor are not used.

## Ryubing / Ryujinx Maxwell shader translator
Source: https://codeberg.org/Software_arch/Ryubing
Revision: `a82350bb77` (the revision specified by the reference P5R Android build instructions).
License: MIT, with additional third-party notices as described by Ryubing. The workflow includes `LICENSE.txt` and `THIRDPARTY.md` in the APK assets.

The generic Maxwell-to-SPIR-V harness is compiled for Android ARM64 with .NET NativeAOT. Ys IX shader code is read from the user's runtime captures; no game code, keys, assets, shaders, or firmware are bundled.


YS IX-specific v1.0 changes retain the v0.9 test-only movie-source hook and input diagnostics, add safe audio-renderer discovery diagnostics, and expose the generic FPS overlay configuration. They do not copy Persona 5 Royal assets, shaders, game-specific hooks, or content.


## Zstandard decompression library
Source: https://github.com/facebook/zstd
Revision: `v1.5.7`.
License: dual BSD-3-Clause / GPLv2. The workflow builds the static ARM64 decompressor used for NIS VFS3 entries and includes the upstream `LICENSE` file in the APK assets.


## v1.1 additions

The v1.1 native shader-discovery scanner, VFS3 parser, preparation UI, and expanded Vulkan capability report are Ys IX-specific work. VFS3 Zstandard decoding links Zstandard v1.5.7 (dual BSD/GPL license); the build workflow places the upstream license text in `app/src/main/assets/THIRD_PARTY_LICENSES/Zstandard-LICENSE.txt`. The upstream P5R/Ryubing license and third-party notices are also copied into the APK assets during the workflow.
