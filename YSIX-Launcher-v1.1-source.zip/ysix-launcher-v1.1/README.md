# YS IX: Monstrum Nox — Android native runtime experiment v1.1

**Status:** experimental. The Samsung Galaxy A22 5G previously reached the real Ys IX title menu, but gameplay was reported at roughly 3 FPS after difficulty selection and audio remained silent. The Redmi Turbo 4 has graphics glitches and is now the primary development target. v1.1 expands game shader discovery, adds a P5R-style preparation screen, adds VFS3 archive decoding, and records more Vulkan capabilities. It does **not** claim to fix the Redmi's graphics, deliver playable performance, or restore audio.

## v1.1 changes

- **Game shader discovery:** the preparation screen scans the selected Ys IX image's RomFS, supported VFS3 archives, and main ExeFS NSO for validated NVN shader records.
- **VFS3 archive reader:** reads VFS3 v1 metadata and handles uncompressed, zlib, standard Zstandard, and NIS chunked-Zstandard entries with optional dictionaries, subject to explicit entry-size limits.
- **Batch shader translation:** deduplicates discovered shader code, adds prior runtime-captured misses, translates blocks using the ARM64 Ryujinx/Ryubing SPIR-V harness, and persists the cache.
- **Preparation UI:** shows scan/translation stages and reports counts for supported records found, entries decoded/skipped, and SPIR-V modules installed. It never substitutes P5R's ~29k count for a Ys IX count.
- **Vulkan diagnostics:** logs device features, image-format capabilities and additional GPU limits for investigating Mali-G720 rendering issues.
- Keeps the v1.0 FPS setting, v0.9 movie bypass, touch input tracing, four-module loader and audio discovery diagnostics.

The scan is broad but not yet proven exhaustive. It currently recognizes `HNSHV002` records in raw/decompressed assets plus the known NVN ExeFS block structure. Unsupported or oversized entries are counted, and runtime shader capture remains a fallback for shaders found only in gameplay. See [docs/V1.1-SHADER-DISCOVERY.md](docs/V1.1-SHADER-DISCOVERY.md).

## Test devices and milestones

- **Primary:** Redmi Turbo 4 (Dimensity 8400-Ultra, Mali-G720 MC7). Graphics compatibility and performance are the primary targets.
- **Secondary regression:** Samsung Galaxy A22 5G (Dimensity 700, Mali-G57 MC2). It has reached the main menu; gameplay is not yet playable.

A successful CI build is only a build milestone. Main-menu boot is not the same as playable gameplay. Audio, Redmi rendering glitches and low gameplay frame rate remain open issues pending device validation.

## GitHub build

1. Upload `YSIX-Launcher-v1.1-source.zip` to the repository root.
2. Upload `.github/workflows/ysix-v1.1-shader-discovery.yml` under `.github/workflows/`.
3. Open **Actions → Build YS IX v1.1 Shader Discovery and Vulkan Diagnostics → Run workflow**.
4. Download `ysix-v1.1-shader-discovery-debug-apk`.

The workflow runs host-side regression fixtures, fetches the pinned MIT-licensed generic Switch importer/runtime and Ryujinx-based shader translator, builds the ARM64 Zstandard dependency and assembles the debug APK. A passing workflow proves build/package success only; it does not prove complete shader coverage, graphics correctness, audio, performance or playable gameplay.

The debug application ID suffix remains `.debug.v07` intentionally, allowing installation as an update to the earlier experimental debug APK without changing its app-private storage location.

## Primary test after building

On the Redmi Turbo 4, select the game image and `prod.keys` in Library, run **PREPARE GAME SHADERS**, then share the complete shader discovery result. After booting, capture the affected graphics scenes and the fresh `nx.log` from the same run. The Galaxy A22 remains the secondary regression device. Audio must be tested separately; it is still not claimed as fixed.
