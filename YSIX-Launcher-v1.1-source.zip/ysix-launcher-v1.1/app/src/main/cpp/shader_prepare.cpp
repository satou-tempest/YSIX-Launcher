// Ys IX shader-miss preparation bridge.
//
// The runtime writes raw Maxwell code/control pairs to <data>/shader_misses when a shader
// is unavailable in <data>/spirv. This bridge builds the manifest expected by the generic
// Ryujinx SPIR-V harness, translates only uncached misses, then merges SPIR-V and resource
// metadata into the runtime cache. No game assets or shader binaries are bundled.
#include <jni.h>
#include <dlfcn.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <cerrno>
#include <cstdint>
#include <exception>
#include <atomic>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <mutex>
#include <set>
#include <sstream>
#include <string>
#include <vector>

#include "shader_game_discovery.h"

namespace {

using HarnessMain = int (*)(int, const char**);
using HarnessProgress = void (*)(int*, int*);

std::mutex g_prepare_mutex;
std::atomic<int> g_phase{0};
std::atomic<int> g_done{0};
std::atomic<int> g_total{0};
std::atomic<bool> g_running{false};
void* g_harness_handle = nullptr;
HarnessMain g_harness_main = nullptr;
HarnessProgress g_harness_progress = nullptr;

uint32_t read_le32(const unsigned char* p) {
    return uint32_t(p[0]) | (uint32_t(p[1]) << 8) |
           (uint32_t(p[2]) << 16) | (uint32_t(p[3]) << 24);
}

bool is_directory(const std::string& p) {
    struct stat st{};
    return stat(p.c_str(), &st) == 0 && S_ISDIR(st.st_mode);
}

bool ensure_directory(const std::string& p) {
    if (is_directory(p)) return true;
    if (mkdir(p.c_str(), 0700) == 0) return true;
    return errno == EEXIST && is_directory(p);
}

bool remove_tree(const std::string& path) {
    DIR* dir = opendir(path.c_str());
    if (!dir) return errno == ENOENT;
    bool ok = true;
    while (dirent* entry = readdir(dir)) {
        const std::string name(entry->d_name);
        if (name == "." || name == "..") continue;
        const std::string child = path + "/" + name;
        struct stat st{};
        if (lstat(child.c_str(), &st) != 0) { ok = false; continue; }
        if (S_ISDIR(st.st_mode)) {
            if (!remove_tree(child)) ok = false;
        } else if (unlink(child.c_str()) != 0) {
            ok = false;
        }
    }
    closedir(dir);
    if (rmdir(path.c_str()) != 0 && errno != ENOENT) ok = false;
    return ok;
}

std::string jstring_utf8(JNIEnv* env, jstring value) {
    if (!value) return {};
    const char* chars = env->GetStringUTFChars(value, nullptr);
    if (!chars) return {};
    std::string result(chars);
    env->ReleaseStringUTFChars(value, chars);
    return result;
}

bool read_bytes(const std::string& path, std::vector<unsigned char>& out) {
    std::ifstream in(path, std::ios::binary);
    if (!in) return false;
    in.seekg(0, std::ios::end);
    const std::streamoff size = in.tellg();
    if (size < 0 || uint64_t(size) > (64ull << 20)) return false;
    in.seekg(0, std::ios::beg);
    out.resize(static_cast<size_t>(size));
    if (size && !in.read(reinterpret_cast<char*>(out.data()), size)) return false;
    return true;
}

bool write_text(const std::string& path, const std::string& value) {
    const std::string tmp = path + ".tmp";
    {
        std::ofstream out(tmp, std::ios::binary | std::ios::trunc);
        if (!out || !(out.write(value.data(), static_cast<std::streamsize>(value.size())))) return false;
    }
    if (rename(tmp.c_str(), path.c_str()) == 0) return true;
    unlink(tmp.c_str());
    return false;
}

bool copy_file(const std::string& from, const std::string& to) {
    std::ifstream in(from, std::ios::binary);
    if (!in) return false;
    const std::string tmp = to + ".tmp";
    std::ofstream out(tmp, std::ios::binary | std::ios::trunc);
    if (!out) return false;
    out << in.rdbuf();
    out.flush();
    if (in.bad()) { out.close(); unlink(tmp.c_str()); return false; }
    out.close();
    if (!out) { unlink(tmp.c_str()); return false; }
    if (rename(tmp.c_str(), to.c_str()) == 0) return true;
    // rename replaces an existing file on Android/Linux; this is a defensive fallback.
    unlink(to.c_str());
    const bool ok = rename(tmp.c_str(), to.c_str()) == 0;
    if (!ok) unlink(tmp.c_str());
    return ok;
}

bool valid_hash(const std::string& h) {
    if (h.size() != 16) return false;
    for (unsigned char c : h)
        if (!std::isxdigit(c)) return false;
    return true;
}

bool shader_is_cached(const std::string& cache, const std::string& hash) {
    struct stat st{};
    const std::string p = cache + "/" + hash + ".spv";
    if (stat(p.c_str(), &st) != 0 || !S_ISREG(st.st_mode) || st.st_size < 20 || (st.st_size % 4) != 0) return false;
    FILE* f = std::fopen(p.c_str(), "rb");
    if (!f) return false;
    unsigned char magic[4]{};
    const bool read = std::fread(magic, 1, sizeof(magic), f) == sizeof(magic);
    std::fclose(f);
    return read && read_le32(magic) == 0x07230203u;
}

std::string stage_for(const std::vector<unsigned char>& code, const std::vector<unsigned char>& ctrl) {
    if (code.size() >= 4 && read_le32(code.data()) == 0x12345679u) return "compute";
    const uint32_t start = read_le32(ctrl.data() + 0x708);
    if (start == 0 && read_le32(ctrl.data() + 0x748) != 0) return "compute";
    if (uint64_t(start) + 4 <= code.size()) {
        const uint32_t type = (read_le32(code.data() + start) >> 10) & 0xf;
        if (type == 1) return "vertex";
        if (type == 5) return "pixel";
    }
    return "unknown";
}

struct Miss {
    std::string hash;
    std::string code_name;
    std::string ctrl_name;
    std::string stage;
    size_t code_size = 0;
};

bool build_manifest(const std::string& misses_dir, const std::string& cache_dir,
                    std::vector<Miss>& pending, std::string& error) {
    DIR* dir = opendir(misses_dir.c_str());
    if (!dir) {
        error = "No shader_misses folder yet. Run TRY NATIVE BOOT once, then return here.";
        return false;
    }
    while (dirent* entry = readdir(dir)) {
        const std::string name(entry->d_name);
        if (name.size() != 25 || name.compare(0, 5, "code_") != 0 ||
            name.compare(name.size() - 4, 4, ".bin") != 0) continue;
        const std::string hash = name.substr(5, 16);
        if (!valid_hash(hash)) continue;
        const std::string code_path = misses_dir + "/" + name;
        const std::string ctrl_name = "ctrl_" + hash + ".bin";
        const std::string ctrl_path = misses_dir + "/" + ctrl_name;
        struct stat cs{}, ts{};
        if (stat(code_path.c_str(), &cs) != 0 || !S_ISREG(cs.st_mode) || cs.st_size <= 0 ||
            stat(ctrl_path.c_str(), &ts) != 0 || !S_ISREG(ts.st_mode) || ts.st_size < 0x880) continue;
        if (shader_is_cached(cache_dir, hash)) continue;

        std::vector<unsigned char> code, ctrl;
        if (!read_bytes(code_path, code) || !read_bytes(ctrl_path, ctrl) ||
            ctrl.size() < 0x880 || code.size() > (16u << 20)) continue;
        const uint32_t declared = read_le32(ctrl.data() + 0x704);
        if (declared != code.size()) continue;

        Miss miss;
        miss.hash = hash;
        miss.code_name = name;
        miss.ctrl_name = ctrl_name;
        miss.stage = stage_for(code, ctrl);
        miss.code_size = code.size();
        pending.push_back(std::move(miss));
    }
    closedir(dir);

    std::sort(pending.begin(), pending.end(), [](const Miss& a, const Miss& b) {
        return a.hash < b.hash;
    });
    if (pending.empty()) {
        error = "No untranslated shader misses found. The captured shaders are already cached, or you need to boot the game once to capture them.";
        return true;
    }

    std::ostringstream manifest;
    manifest << "id\tstage\tcode_off\tcode_size\tctrl_off\tctrl_size\tprogram_start\tprogram_bytes\tconst_off\tconst_size\tcode_sha1_16\tcode_file\tctrl_file\n";
    for (const Miss& m : pending) {
        std::vector<unsigned char> ctrl;
        if (!read_bytes(misses_dir + "/" + m.ctrl_name, ctrl) || ctrl.size() < 0x880) {
            error = "A captured shader control block became unreadable: " + m.hash;
            return false;
        }
        const uint32_t program_size = read_le32(ctrl.data() + 0x6f8);
        const uint32_t const_size = read_le32(ctrl.data() + 0x6fc);
        const uint32_t const_offset = read_le32(ctrl.data() + 0x700);
        const uint32_t program_start = read_le32(ctrl.data() + 0x708);
        manifest << "ysix/" << m.hash << "/" << m.stage << '\t' << m.stage
                 << "\t0x0\t0x" << std::hex << m.code_size
                 << "\t0x0\t0x880\t0x" << program_start
                 << "\t0x" << program_size << "\t0x" << const_offset
                 << "\t0x" << const_size << '\t' << m.hash
                 << '\t' << m.code_name << '\t' << m.ctrl_name << '\n';
    }
    if (!write_text(misses_dir + "/manifest.tsv", manifest.str())) {
        error = "Could not write shader_misses/manifest.tsv";
        return false;
    }
    return true;
}

bool merge_results(const std::string& pending_dir, const std::string& cache_dir,
                   size_t& merged_count, std::string& error) {
    const std::string fresh_path = pending_dir + "/results.tsv";
    const std::string old_path = cache_dir + "/results.tsv";
    std::ifstream fresh(fresh_path);
    if (!fresh) {
        error = "Translator did not produce results.tsv";
        return false;
    }
    std::string header;
    if (!std::getline(fresh, header) || header.find("resources") == std::string::npos) {
        error = "Translator results.tsv has an unexpected format";
        return false;
    }

    std::vector<std::string> rows;
    std::set<std::string> seen;
    std::string old_header;
    {
        std::ifstream old(old_path);
        if (old && std::getline(old, old_header) && old_header.find("resources") != std::string::npos) {
            header = old_header;
            std::string line;
            while (std::getline(old, line)) {
                std::vector<std::string> cols;
                size_t pos = 0;
                while (true) {
                    const size_t tab = line.find('\t', pos);
                    cols.push_back(line.substr(pos, tab == std::string::npos ? tab : tab - pos));
                    if (tab == std::string::npos) break;
                    pos = tab + 1;
                }
                // Keep only successful cache rows. A previous exception/timeout may have no SPIR-V;
                // retaining it would block a later successful retry for the same shader hash.
                if (cols.size() < 8 || !valid_hash(cols[0]) ||
                    (cols[4] != "ok" && cols[4] != "ok-retry") ||
                    cols[6].empty()) continue;
                char* endp = nullptr;
                const unsigned long bytes = std::strtoul(cols[6].c_str(), &endp, 10);
                if (!endp || *endp != '\0' || bytes == 0 || (bytes % 4) != 0 ||
                    !shader_is_cached(cache_dir, cols[0])) continue;
                if (seen.insert(cols[0]).second) rows.push_back(std::move(line));
            }
        }
    }

    std::string line;
    while (std::getline(fresh, line)) {
        const size_t tab = line.find('\t');
        if (tab == std::string::npos) continue;
        const std::string hash = line.substr(0, tab);
        if (hash.empty()) continue;
        const std::string spv = cache_dir + "/" + hash + ".spv";
        struct stat st{};
        if (stat(spv.c_str(), &st) != 0 || st.st_size <= 0 || (st.st_size % 4) != 0) continue;
        if (seen.insert(hash).second) rows.push_back(line);
        else {
            // Preserve the original cache row; its descriptor/resource metadata is already known-good.
        }
        merged_count++;
    }

    std::ostringstream merged;
    merged << header << '\n';
    for (const std::string& row : rows) merged << row << '\n';
    if (!write_text(old_path, merged.str())) {
        error = "Could not merge shader resource metadata into spirv/results.tsv";
        return false;
    }
    return true;
}

bool load_harness(std::string& error);

bool append_captured_misses(const std::string& misses_dir, const std::string& batch_root,
                            const std::string& cache_dir, size_t& copied, std::string& error) {
    copied = 0;
    DIR* dir = opendir(misses_dir.c_str());
    if (!dir) return true; // No runtime captures yet; package extraction can still proceed.
    const std::string out_dir = batch_root + "/captured";
    if (!ensure_directory(batch_root) || !ensure_directory(out_dir)) {
        closedir(dir);
        error = "Cannot create captured-shader batch folder.";
        return false;
    }
    std::ostringstream manifest;
    manifest << "id\tstage\tcode_off\tcode_size\tctrl_off\tctrl_size\tprogram_start\tprogram_bytes\tconst_off\tconst_size\tcode_sha1_16\tcode_file\tctrl_file\n";
    while (dirent* entry = readdir(dir)) {
        const std::string name(entry->d_name);
        if (name.size() != 25 || name.compare(0,5,"code_") != 0 || name.compare(name.size()-4,4,".bin") != 0) continue;
        const std::string hash = name.substr(5,16);
        if (!valid_hash(hash) || shader_is_cached(cache_dir,hash)) continue;
        const std::string code_path = misses_dir + "/" + name;
        const std::string ctrl_name = "ctrl_" + hash + ".bin";
        const std::string ctrl_path = misses_dir + "/" + ctrl_name;
        std::vector<unsigned char> code, ctrl;
        if (!read_bytes(code_path,code) || !read_bytes(ctrl_path,ctrl) || ctrl.size() < 0x880 || code.empty() || code.size() > (16u<<20)) continue;
        if (read_le32(ctrl.data()) != 0x98761234u || read_le32(ctrl.data()+0x704) != code.size()) continue;
        if (!copy_file(code_path,out_dir+"/"+name) || !copy_file(ctrl_path,out_dir+"/"+ctrl_name)) {
            closedir(dir);
            error = "Could not stage a runtime-captured shader block: " + hash;
            return false;
        }
        const std::string stage = stage_for(code,ctrl);
        const uint32_t program_size=read_le32(ctrl.data()+0x6f8);
        const uint32_t const_size=read_le32(ctrl.data()+0x6fc);
        const uint32_t const_offset=read_le32(ctrl.data()+0x700);
        const uint32_t program_start=read_le32(ctrl.data()+0x708);
        manifest << "captured/" << hash << "/" << stage << '\t' << stage
                 << "\t0x0\t0x" << std::hex << code.size() << "\t0x0\t0x880\t0x" << program_start
                 << "\t0x" << program_size << "\t0x" << const_offset << "\t0x" << const_size
                 << '\t' << hash << '\t' << name << '\t' << ctrl_name << '\n';
        ++copied;
    }
    closedir(dir);
    if (copied > 0 && !write_text(out_dir+"/manifest.tsv",manifest.str())) {
        error = "Could not write captured-shader batch manifest.";
        return false;
    }
    return true;
}

std::string prepare_game(int game_fd, const std::string& game_name, int prod_keys_fd, int title_keys_fd,
                         const std::string& root, int jobs) {
    std::lock_guard<std::mutex> guard(g_prepare_mutex);
    g_done = 0; g_total = 0; g_phase = 1; g_running = true;
    struct RunningReset { ~RunningReset() { g_running = false; } } reset;

    const std::string cache = root + "/spirv";
    const std::string batch_root = root + "/shader_game_source";
    const std::string pending_dir = root + "/spirv.pending";
    if (!ensure_directory(root) || !ensure_directory(cache)) return "Cannot create the Ys IX shader cache folder in app storage.";
    remove_tree(batch_root);
    if (!ensure_directory(batch_root)) return "Cannot create the game shader discovery folder.";

    ysix::ShaderDiscoveryStats stats;
    std::string error;
    const bool discovered = ysix::discover_game_shaders(
        game_fd, game_name, prod_keys_fd, title_keys_fd, batch_root, cache,
        [](int phase, int done, int total) { g_phase = phase; g_done = done; g_total = total; },
        stats, error);
    if (!discovered) return "Game shader discovery failed: " + error;

    size_t captured = 0;
    if (!append_captured_misses(root+"/shader_misses",batch_root,cache,captured,error)) return error;
    const size_t staged_total = stats.new_shader_blocks_staged + captured;
    if (staged_total == 0) {
        std::ostringstream report;
        report << "Game image scan completed.\n"
               << "Unique supported shader records found: " << stats.unique_shader_blocks_found << "\n"
               << "New source blocks requiring translation: 0\n"
               << "Runtime-captured uncached blocks: " << captured << "\n"
               << "RomFS files scanned: " << stats.scanned_romfs_files << "\n"
               << "VFS3 archives parsed: " << stats.vfs3_archives_parsed << "\n"
               << "VFS3 entries seen / decoded: " << stats.vfs3_entries_seen << " / " << stats.vfs3_entries_decoded << "\n"
               << "VFS3 entries too large / decode failures: " << stats.vfs3_entries_oversized << " / " << stats.vfs3_decode_failures << "\n"
               << "First VFS3 diagnostic: " << (stats.vfs3_first_error.empty() ? "none" : stats.vfs3_first_error) << "\n\n"
               << (stats.unique_shader_blocks_found > 0
                       ? "All recognized shader blocks already have SPIR-V cache files with a valid module header."
                       : "No supported prepackaged NVN shader records were recognized. This does not mean Ys IX has no shaders; it means the current scanners did not identify a supported record format. Runtime shader captures remain the fallback.")
               << "\nNo existing shader cache was changed.";
        return report.str();
    }
    if (!load_harness(error)) return error;

    remove_tree(pending_dir);
    if (!ensure_directory(pending_dir)) return "Cannot create temporary shader translation folder.";
    g_phase = 4; g_done = 0; g_total = int(staged_total);
    const std::string jobs_s = std::to_string(std::max(1,std::min(jobs,4)));
    const char* args[] = {"--batch",batch_root.c_str(),"--out",pending_dir.c_str(),"--jobs",jobs_s.c_str(),"--no-val"};
    const int rc = g_harness_main(int(sizeof(args)/sizeof(args[0])),args);
    if (rc != 0) {
        remove_tree(pending_dir);
        return "Shader translation failed (translator exit code " + std::to_string(rc) + "). "
               "The extracted shader source was kept for diagnosis.";
    }

    g_phase = 5;
    g_done = 0;
    g_total = 0;
    size_t installed = 0;
    DIR* dir = opendir(pending_dir.c_str());
    if (!dir) { remove_tree(pending_dir); return "Translator output folder disappeared."; }
    while (dirent* entry = readdir(dir)) {
        const std::string name(entry->d_name);
        if (name.size() < 5 || name.substr(name.size()-4) != ".spv") continue;
        if (!copy_file(pending_dir+"/"+name,cache+"/"+name)) {
            closedir(dir); remove_tree(pending_dir);
            return "Could not install translated shader " + name;
        }
        ++installed;
    }
    closedir(dir);
    if (installed == 0) { remove_tree(pending_dir); return "The translator produced no usable SPIR-V files. Source manifests were retained."; }
    size_t merged = 0;
    if (!merge_results(pending_dir,cache,merged,error)) { remove_tree(pending_dir); return error; }
    copy_file(pending_dir+"/summary.txt",cache+"/last-translation-summary.txt");
    copy_file(pending_dir+"/results.tsv",cache+"/last-translation-results.tsv");
    remove_tree(pending_dir);
    g_phase = 6;
    std::ostringstream report;
    report << "Shader discovery and translation finished.\n"
           << "Unique supported shader blocks found: " << stats.unique_shader_blocks_found << "\n"
           << "New package shader blocks staged: " << stats.new_shader_blocks_staged << "\n"
           << "Runtime-captured uncached blocks added: " << captured << "\n"
           << "RomFS files scanned: " << stats.scanned_romfs_files << "\n"
           << "VFS3 archives parsed: " << stats.vfs3_archives_parsed << "\n"
           << "VFS3 entries seen / decoded: " << stats.vfs3_entries_seen << " / " << stats.vfs3_entries_decoded << "\n"
           << "VFS3 entries too large / decode failures: " << stats.vfs3_entries_oversized << " / " << stats.vfs3_decode_failures << "\n"
           << "First VFS3 diagnostic: " << (stats.vfs3_first_error.empty() ? "none" : stats.vfs3_first_error) << "\n"
           << "New SPIR-V files installed: " << installed << "\n"
           << "Resource metadata rows merged: " << merged << "\n"
           << "Cache: " << cache << "\n\n"
           << "These counts describe supported, validated records—not a proven exhaustive shader count for Ys IX. Unsupported archive variants and oversized entries are reported as skipped; runtime capture remains enabled for shaders first encountered in gameplay.";
    return report.str();
}

bool load_harness(std::string& error) {
    if (g_harness_main && g_harness_progress) return true;
    g_harness_handle = dlopen("libspirvharness.so", RTLD_NOW);
    if (!g_harness_handle) {
        const char* why = dlerror();
        error = std::string("Shader translator library is unavailable: ") + (why ? why : "unknown dlopen error");
        return false;
    }
    g_harness_main = reinterpret_cast<HarnessMain>(dlsym(g_harness_handle, "spirv_harness_main"));
    g_harness_progress = reinterpret_cast<HarnessProgress>(dlsym(g_harness_handle, "spirv_harness_progress"));
    if (!g_harness_main || !g_harness_progress) {
        error = "Shader translator library is missing the expected NativeAOT entry points";
        return false;
    }
    return true;
}

std::string prepare(const std::string& root, int jobs) {
    std::lock_guard<std::mutex> guard(g_prepare_mutex);
    g_phase = 4;
    g_done = 0;
    g_total = 0;
    g_running = true;
    struct RunningReset { ~RunningReset() { g_running = false; } } reset;

    const std::string misses = root + "/shader_misses";
    const std::string cache = root + "/spirv";
    const std::string pending_dir = root + "/spirv.pending";
    if (!ensure_directory(root) || !ensure_directory(cache)) {
        return "Cannot create the Ys IX shader cache folder in app storage.";
    }

    std::vector<Miss> pending;
    std::string error;
    if (!build_manifest(misses, cache, pending, error)) return error;
    if (pending.empty()) return error;

    if (!load_harness(error)) return error;
    remove_tree(pending_dir);
    if (!ensure_directory(pending_dir)) return "Cannot create temporary shader output folder.";

    std::string jobs_arg = std::to_string(std::max(1, std::min(jobs, 3)));
    const char* args[] = {
        "--batch", misses.c_str(),
        "--out", pending_dir.c_str(),
        "--jobs", jobs_arg.c_str(),
        "--no-val"
    };
    const int rc = g_harness_main(static_cast<int>(sizeof(args) / sizeof(args[0])), args);
    if (rc != 0) {
        remove_tree(pending_dir);
        return "Shader translation failed (translator exit code " + std::to_string(rc) +
               "). Keep the captured shader_misses folder and share the native log.";
    }

    size_t copied = 0;
    DIR* dir = opendir(pending_dir.c_str());
    if (!dir) {
        remove_tree(pending_dir);
        return "Translator output folder disappeared.";
    }
    while (dirent* entry = readdir(dir)) {
        const std::string name(entry->d_name);
        if (name.size() < 5 || name.substr(name.size() - 4) != ".spv") continue;
        const std::string from = pending_dir + "/" + name;
        const std::string to = cache + "/" + name;
        if (!copy_file(from, to)) {
            closedir(dir);
            remove_tree(pending_dir);
            return "Could not install translated shader " + name;
        }
        copied++;
    }
    closedir(dir);

    if (copied == 0) {
        remove_tree(pending_dir);
        return "The translator produced no usable SPIR-V files. Keep shader_misses and share the translation summary/log.";
    }

    size_t merged = 0;
    if (!merge_results(pending_dir, cache, merged, error)) {
        remove_tree(pending_dir);
        return error;
    }
    copy_file(pending_dir + "/summary.txt", cache + "/last-translation-summary.txt");
    remove_tree(pending_dir);

    std::ostringstream report;
    report << "Translation complete.\n"
           << "New SPIR-V shaders installed: " << copied << "\n"
           << "Captured misses in this batch: " << pending.size() << "\n"
           << "Resource metadata rows merged: " << merged << "\n"
           << "Shader cache: " << cache << "\n\n"
           << "The raw captures were kept. Boot Ys IX again; if it reaches new scenes, return here and prepare the newly captured misses.";
    return report.str();
}

}  // namespace

extern "C" JNIEXPORT jstring JNICALL
Java_io_github_ysix_launcher_NativeProbe_nativePrepareGameShaders(JNIEnv* env, jclass, jint game_fd,
        jstring game_name, jint prod_keys_fd, jint title_keys_fd, jstring root, jint jobs) {
    const std::string name = jstring_utf8(env,game_name);
    const std::string data_root = jstring_utf8(env,root);
    if (game_fd < 0 || prod_keys_fd < 0 || data_root.empty()) return env->NewStringUTF("Game image, prod.keys or app storage is unavailable.");
    try {
        const std::string report = prepare_game(game_fd,name,prod_keys_fd,title_keys_fd,data_root,jobs);
        return env->NewStringUTF(report.c_str());
    } catch (const std::exception& e) {
        const std::string report = std::string("Game shader preparation failed: ") + e.what();
        return env->NewStringUTF(report.c_str());
    } catch (...) {
        return env->NewStringUTF("Game shader preparation failed with an unknown native error.");
    }
}

extern "C" JNIEXPORT jstring JNICALL
Java_io_github_ysix_launcher_NativeProbe_nativePrepareShaders(JNIEnv* env, jclass, jstring root, jint jobs) {
    const std::string data_root = jstring_utf8(env, root);
    if (data_root.empty()) return env->NewStringUTF("App storage path is unavailable.");
    try {
        const std::string report = prepare(data_root, jobs);
        return env->NewStringUTF(report.c_str());
    } catch (const std::exception& e) {
        const std::string report = std::string("Shader preparation failed: ") + e.what();
        return env->NewStringUTF(report.c_str());
    } catch (...) {
        return env->NewStringUTF("Shader preparation failed with an unknown native error.");
    }
}

extern "C" JNIEXPORT jintArray JNICALL
Java_io_github_ysix_launcher_NativeProbe_shaderProgress(JNIEnv* env, jclass) {
    int phase = g_phase.load();
    int done = g_done.load();
    int total = g_total.load();
    if (phase == 4 && g_harness_progress && g_running.load()) {
        int translated = 0, count = 0;
        g_harness_progress(&translated, &count);
        done = translated;
        total = count;
    }
    jint values[3] = {phase,done,total};
    jintArray result = env->NewIntArray(3);
    if (result) env->SetIntArrayRegion(result,0,3,values);
    return result;
}
