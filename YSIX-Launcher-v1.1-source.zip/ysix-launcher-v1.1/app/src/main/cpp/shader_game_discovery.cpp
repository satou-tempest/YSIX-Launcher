#include "shader_game_discovery.h"

#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <cctype>
#include <cerrno>
#include <iterator>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <functional>
#include <map>
#include <set>
#include <sstream>
#include <string>
#include <utility>
#include <vector>

#include "nxgame.h"
#include "vfs3_shader_scan.h"

namespace ysix {
namespace {

constexpr uint64_t kYsIxTitleId = 0x0100E390124D8000ull;
constexpr uint32_t kCtrlMagic = 0x98761234u;
constexpr uint32_t kCodeMagic = 0x12345678u;
constexpr uint32_t kComputeMagic = 0x12345679u;
constexpr size_t kCtrlBytes = 0x880;
constexpr uint64_t kMaxCodeBytes = 16ull << 20;
constexpr size_t kScanChunk = 1u << 20;

uint32_t le32(const uint8_t* p) {
    return uint32_t(p[0]) | (uint32_t(p[1]) << 8) | (uint32_t(p[2]) << 16) | (uint32_t(p[3]) << 24);
}
uint64_t align_256(uint64_t x) { return (x + 0xffu) & ~uint64_t(0xffu); }

std::string sha1_16(const uint8_t* data, size_t size) {
    uint32_t h[5] = {0x67452301u, 0xEFCDAB89u, 0x98BADCFEu, 0x10325476u, 0xC3D2E1F0u};
    auto rol = [](uint32_t x, int n) { return (x << n) | (x >> (32 - n)); };
    auto block = [&](const uint8_t* p) {
        uint32_t w[80];
        for (int i = 0; i < 16; ++i)
            w[i] = (uint32_t(p[i*4]) << 24) | (uint32_t(p[i*4+1]) << 16) | (uint32_t(p[i*4+2]) << 8) | uint32_t(p[i*4+3]);
        for (int i = 16; i < 80; ++i) w[i] = rol(w[i-3] ^ w[i-8] ^ w[i-14] ^ w[i-16], 1);
        uint32_t a=h[0], b=h[1], c=h[2], d=h[3], e=h[4];
        for (int i = 0; i < 80; ++i) {
            uint32_t f, k;
            if (i < 20) f=(b&c)|(~b&d), k=0x5A827999u;
            else if (i < 40) f=b^c^d, k=0x6ED9EBA1u;
            else if (i < 60) f=(b&c)|(b&d)|(c&d), k=0x8F1BBCDCu;
            else f=b^c^d, k=0xCA62C1D6u;
            uint32_t t=rol(a,5)+f+e+k+w[i]; e=d; d=c; c=rol(b,30); b=a; a=t;
        }
        h[0]+=a; h[1]+=b; h[2]+=c; h[3]+=d; h[4]+=e;
    };
    size_t off = 0;
    for (; off + 64 <= size; off += 64) block(data + off);
    uint8_t tail[128] = {};
    const size_t rest = size - off;
    if (rest) std::memcpy(tail, data + off, rest);
    tail[rest] = 0x80;
    const size_t padded = rest + 1 + 8 <= 64 ? 64 : 128;
    const uint64_t bits = uint64_t(size) * 8;
    for (int i = 0; i < 8; ++i) tail[padded - 1 - i] = uint8_t(bits >> (8 * i));
    block(tail);
    if (padded == 128) block(tail + 64);
    char out[41];
    for (int i = 0; i < 5; ++i) std::snprintf(out + i*8, 9, "%08x", h[i]);
    return std::string(out, 16);
}

bool make_dir(const std::string& path) {
    if (mkdir(path.c_str(), 0700) == 0) return true;
    struct stat st{};
    return errno == EEXIST && stat(path.c_str(), &st) == 0 && S_ISDIR(st.st_mode);
}
bool ensure_dirs(const std::string& path) {
    std::string current;
    size_t pos = 0;
    while (pos < path.size()) {
        size_t next = path.find('/', pos);
        if (next == std::string::npos) next = path.size();
        current = path.substr(0, next);
        if (!current.empty() && !make_dir(current)) return false;
        pos = next + 1;
    }
    return true;
}

bool write_file(const std::string& path, const uint8_t* data, size_t size) {
    FILE* f = std::fopen(path.c_str(), "wb");
    if (!f) return false;
    const bool wrote = !size || std::fwrite(data, 1, size, f) == size;
    const bool closed = std::fclose(f) == 0;
    if (!wrote || !closed) unlink(path.c_str());
    return wrote && closed;
}

bool is_cached(const std::string& cache, const std::string& hash) {
    struct stat st{};
    const std::string path = cache + "/" + hash + ".spv";
    if (stat(path.c_str(), &st) != 0 || !S_ISREG(st.st_mode) || st.st_size < 20 || (st.st_size % 4) != 0) return false;
    FILE* f = std::fopen(path.c_str(), "rb");
    if (!f) return false;
    uint8_t magic[4]{};
    const bool read = std::fread(magic, 1, sizeof(magic), f) == sizeof(magic);
    std::fclose(f);
    return read && le32(magic) == 0x07230203u;
}

std::string stage_for(const std::vector<uint8_t>& code, const std::vector<uint8_t>& ctrl) {
    if (code.size() < 4 || ctrl.size() < kCtrlBytes) return "unknown";
    const uint32_t start = le32(ctrl.data() + 0x708);
    if (le32(code.data()) == kComputeMagic || (start == 0 && le32(ctrl.data() + 0x748) != 0)) return "compute";
    if (uint64_t(start) + 4 <= code.size()) {
        const uint32_t type = (le32(code.data() + start) >> 10) & 0xf;
        if (type == 1) return "vertex";
        if (type == 5) return "pixel";
    }
    return "unknown";
}

struct Extractor {
    std::string root;
    std::string cache;
    std::set<std::string> seen;
    std::map<std::string, std::ostringstream> manifests;
    size_t unique_count = 0;
    size_t count = 0;

    Extractor(std::string out, std::string c) : root(std::move(out)), cache(std::move(c)) {}

    bool add(const std::string& group, uint64_t code_off, const std::vector<uint8_t>& code,
             const std::vector<uint8_t>& ctrl, std::string& error) {
        if (code.empty() || ctrl.size() < kCtrlBytes) return true;
        if (le32(ctrl.data()) != kCtrlMagic || le32(ctrl.data() + 0x704) != code.size()) return true;
        const std::string hash = sha1_16(code.data(), code.size());
        if (!seen.insert(hash).second) return true;
        ++unique_count;
        if (is_cached(cache, hash)) return true;
        const std::string ctrl_hash = sha1_16(ctrl.data(), kCtrlBytes);
        const std::string dir = root + "/" + group;
        if (!ensure_dirs(dir)) { error = "Cannot create shader extraction folder: " + dir; return false; }
        const std::string code_name = "code_" + hash + ".bin";
        const std::string ctrl_name = "ctrl_" + ctrl_hash + ".bin";
        if (!write_file(dir + "/" + code_name, code.data(), code.size()) ||
            !write_file(dir + "/" + ctrl_name, ctrl.data(), kCtrlBytes)) {
            error = "Cannot write extracted shader block " + hash;
            return false;
        }
        const std::string stage = stage_for(code, ctrl);
        const uint32_t program_start = le32(ctrl.data() + 0x708);
        const uint32_t program_size = le32(ctrl.data() + 0x6f8);
        const uint32_t const_size = le32(ctrl.data() + 0x6fc);
        const uint32_t const_off = le32(ctrl.data() + 0x700);
        manifests[group] << group << "/0x" << std::hex << code_off << "/" << stage
                         << '\t' << stage << "\t0x" << code_off << "\t0x" << code.size()
                         << "\t0x0\t0x880\t0x" << program_start << "\t0x" << program_size
                         << "\t0x" << const_off << "\t0x" << const_size << '\t' << hash
                         << '\t' << code_name << '\t' << ctrl_name << '\n';
        ++count;
        return true;
    }

    bool finish_all(std::string& error) {
        const std::string header = "id\tstage\tcode_off\tcode_size\tctrl_off\tctrl_size\tprogram_start\tprogram_bytes\tconst_off\tconst_size\tcode_sha1_16\tcode_file\tctrl_file\n";
        for (const auto& item : manifests) {
            const std::string dir = root + "/" + item.first;
            if (!ensure_dirs(dir)) { error = "Cannot create shader manifest folder: " + dir; return false; }
            const std::string manifest_path = dir + "/manifest.tsv";
            const std::string content = header + item.second.str();
            FILE* f = std::fopen(manifest_path.c_str(), "wb");
            if (!f) { error = "Cannot write " + manifest_path; return false; }
            const bool wrote = std::fwrite(content.data(), 1, content.size(), f) == content.size();
            const bool closed = std::fclose(f) == 0;
            if (!wrote || !closed) { error = "Cannot finish " + manifest_path; return false; }
        }
        return true;
    }
};

bool read_entry(const nxi::GameImage& game, const nxi::GameImage::Entry& entry,
                uint64_t offset, size_t bytes, std::vector<uint8_t>& out) {
    if (offset > entry.size || bytes > entry.size - offset) return false;
    out.resize(bytes);
    return bytes == 0 || game.read(entry, offset, out.data(), bytes) == bytes;
}

bool extract_hnsh_memory(const std::vector<uint8_t>& bytes, const std::string& group,
                         Extractor& output, std::string& error) {
    static const uint8_t magic[] = {'H','N','S','H','V','0','0','2'};
    if (bytes.size() < 0x60) return true;
    auto it = bytes.begin();
    while (it != bytes.end()) {
        it = std::search(it, bytes.end(), std::begin(magic), std::end(magic));
        if (it == bytes.end()) break;
        const uint64_t record = static_cast<uint64_t>(it - bytes.begin());
        if (record <= bytes.size() && 0x60 <= bytes.size() - record) {
            const uint8_t* h = bytes.data() + record;
            const uint64_t ctrl_off = record + 0x24ull + le32(h + 0x54);
            const uint64_t code_off = record + 0x24ull + le32(h + 0x58);
            const uint64_t code_size = le32(h + 0x5c);
            if (code_size > 0 && code_size <= kMaxCodeBytes && ctrl_off <= bytes.size() &&
                kCtrlBytes <= bytes.size() - ctrl_off && code_off <= bytes.size() && code_size <= bytes.size() - code_off) {
                std::vector<uint8_t> ctrl(bytes.begin() + static_cast<ptrdiff_t>(ctrl_off),
                                          bytes.begin() + static_cast<ptrdiff_t>(ctrl_off + kCtrlBytes));
                std::vector<uint8_t> code(bytes.begin() + static_cast<ptrdiff_t>(code_off),
                                          bytes.begin() + static_cast<ptrdiff_t>(code_off + code_size));
                if (le32(ctrl.data()) == kCtrlMagic &&
                    (le32(code.data()) == kCodeMagic || le32(code.data()) == kComputeMagic) &&
                    le32(ctrl.data() + 0x704) == code_size &&
                    !output.add(group, code_off, code, ctrl, error)) return false;
            }
        }
        ++it;
    }
    return true;
}

bool extract_hnsh_file(const nxi::GameImage& game, const nxi::GameImage::Entry& entry,
                       const std::string& group, Extractor& output, std::string& error) {
    if (entry.dir || entry.size < 0x60) return true;
    std::vector<uint8_t> chunk(kScanChunk + 7);
    uint64_t offset = 0;
    while (offset < entry.size) {
        const size_t amount = size_t(std::min<uint64_t>(kScanChunk, entry.size - offset));
        const size_t read_size = size_t(std::min<uint64_t>(kScanChunk + 7, entry.size - offset));
        if (game.read(entry, offset, chunk.data(), read_size) != read_size) {
            error = "Could not read RomFS file during shader scan";
            return false;
        }
        const uint8_t magic[] = {'H','N','S','H','V','0','0','2'};
        const uint8_t* begin = chunk.data();
        const uint8_t* end = begin + read_size;
        const uint8_t* it = begin;
        while (it + sizeof(magic) <= end) {
            it = std::search(it, end, std::begin(magic), std::end(magic));
            if (it == end) break;
            const uint64_t record = offset + uint64_t(it - begin);
            if (record <= entry.size && 0x60 <= entry.size - record) {
                std::vector<uint8_t> header;
                if (read_entry(game, entry, record, 0x60, header)) {
                    const uint64_t ctrl_off = record + 0x24ull + le32(header.data() + 0x54);
                    const uint64_t code_off = record + 0x24ull + le32(header.data() + 0x58);
                    const uint64_t code_size = le32(header.data() + 0x5c);
                    if (code_size > 0 && code_size <= kMaxCodeBytes && ctrl_off <= entry.size &&
                        kCtrlBytes <= entry.size - ctrl_off && code_off <= entry.size && code_size <= entry.size - code_off) {
                        std::vector<uint8_t> ctrl, code;
                        if (read_entry(game, entry, ctrl_off, kCtrlBytes, ctrl) &&
                            read_entry(game, entry, code_off, size_t(code_size), code) &&
                            le32(ctrl.data()) == kCtrlMagic &&
                            (le32(code.data()) == kCodeMagic || le32(code.data()) == kComputeMagic) &&
                            le32(ctrl.data() + 0x704) == code_size) {
                            if (!output.add(group, code_off, code, ctrl, error)) return false;
                        }
                    }
                }
            }
            ++it;
        }
        offset += amount;
    }
    return true;
}

bool contains_exit(const std::vector<uint8_t>& d, uint64_t begin, uint64_t end) {
    static const uint8_t exit_bytes[8] = {0x0f,0x70,0x00,0x00,0x00,0x00,0x00,0xe3};
    if (begin > end || end > d.size() || end - begin < 8) return false;
    return std::search(d.begin() + ptrdiff_t(begin), d.begin() + ptrdiff_t(end),
                       std::begin(exit_bytes), std::end(exit_bytes)) != d.begin() + ptrdiff_t(end);
}
bool all_zero(const std::vector<uint8_t>& d, uint64_t begin, uint64_t end) {
    if (begin > end || end > d.size()) return false;
    for (uint64_t i = begin; i < end; ++i) if (d[size_t(i)] != 0) return false;
    return true;
}

std::vector<std::pair<uint64_t,uint64_t>> find_exefs_blocks(const std::vector<uint8_t>& d) {
    std::vector<uint64_t> controls, codes;
    for (uint64_t c = 0; c + kCtrlBytes <= d.size(); c += 4) {
        if (le32(d.data() + c) == kCtrlMagic) {
            const uint32_t size = le32(d.data() + c + 0x704);
            if (size > 0 && size < (1u << 24)) controls.push_back(c);
        }
    }
    for (uint64_t p = 0; p + 0x30 <= d.size();) {
        const uint32_t magic = le32(d.data() + p);
        if ((magic == kCodeMagic || magic == kComputeMagic) && all_zero(d, p + 4, p + 0x30)) {
            codes.push_back(p); p += 0x30;
        } else ++p;
    }
    auto fits = [&](uint64_t p, uint64_t c) {
        const uint64_t size = le32(d.data() + c + 0x704), start = le32(d.data() + c + 0x708);
        const uint64_t plen = le32(d.data() + c + 0x6f8), csize = le32(d.data() + c + 0x6fc), coff = le32(d.data() + c + 0x700);
        const bool compute = le32(d.data() + p) == kComputeMagic;
        if (p + size > d.size() || start != (compute ? 0x100u : 0x30u) || start + plen > size || start + 0x34 > size) return false;
        if (plen < 8 || !contains_exit(d, p + start, p + start + plen) || all_zero(d, p + start + plen - 8, p + start + plen)) return false;
        if (csize) {
            if (coff != align_256(start + plen) || size != align_256(coff + csize) || !all_zero(d, p + coff + csize, p + size)) return false;
        } else if (size != align_256(start + plen)) return false;
        if (!all_zero(d, p + start + plen, std::min<uint64_t>(p + align_256(start + plen), p + size))) return false;
        const uint32_t type = (le32(d.data() + p + start) >> 10) & 0xf;
        return compute || type == 1 || type == 5;
    };
    auto key = [&](uint64_t c) {
        std::string k(reinterpret_cast<const char*>(d.data() + c + 0x6f8), 0x14);
        k.append(reinterpret_cast<const char*>(d.data() + c + 0x748), 0x10);
        return k;
    };
    std::vector<std::pair<uint64_t,uint64_t>> found;
    std::set<uint64_t> paired;
    for (size_t i = 0; i < codes.size(); ++i) {
        const uint64_t p = codes[i];
        const uint64_t room = (i + 1 < codes.size() ? codes[i + 1] : d.size()) - p;
        std::vector<uint64_t> candidates;
        for (uint64_t c : controls)
            if (le32(d.data() + c + 0x704) <= room && fits(p,c)) candidates.push_back(c);
        std::vector<uint64_t> adjacent;
        for (uint64_t c : candidates) if (p >= c && p - c == 0x850) adjacent.push_back(c);
        if (adjacent.size() == 1) candidates.swap(adjacent);
        uint32_t max_size = 0;
        for (uint64_t c : candidates) max_size = std::max(max_size, le32(d.data() + c + 0x704));
        candidates.erase(std::remove_if(candidates.begin(), candidates.end(), [&](uint64_t c) {
            return le32(d.data() + c + 0x704) != max_size;
        }), candidates.end());
        std::set<std::string> keys;
        for (uint64_t c : candidates) keys.insert(key(c));
        if (!candidates.empty() && keys.size() == 1) {
            found.push_back({p,candidates.front()}); paired.insert(p);
        }
    }
    for (uint64_t c : controls) {
        const uint64_t p = c + 0x850, size = le32(d.data() + c + 0x704), plen = le32(d.data() + c + 0x6f8);
        if (le32(d.data() + c + 0x708) || !le32(d.data() + c + 0x748) || paired.count(p) ||
            p + size > d.size() || plen == 0 || plen > size) continue;
        const uint32_t magic = le32(d.data() + p);
        if (magic == kCodeMagic || magic == kComputeMagic || !contains_exit(d,p,p+plen)) continue;
        found.push_back({p,c});
    }
    return found;
}

bool extract_exefs(const std::vector<uint8_t>& flat, Extractor& output, std::string& error) {
    const auto found = find_exefs_blocks(flat);
    for (const auto& pair : found) {
        const uint64_t p=pair.first, c=pair.second;
        const size_t size=le32(flat.data()+c+0x704);
        if (p + size > flat.size() || c + kCtrlBytes > flat.size()) continue;
        std::vector<uint8_t> code(flat.begin()+ptrdiff_t(p),flat.begin()+ptrdiff_t(p+size));
        std::vector<uint8_t> ctrl(flat.begin()+ptrdiff_t(c),flat.begin()+ptrdiff_t(c+kCtrlBytes));
        if (!output.add("exefs", p, code, ctrl, error)) return false;
    }
    return true;
}

void list_files(const nxi::GameImage& game, const std::string& dir,
                std::vector<std::pair<std::string,nxi::GameImage::Entry>>& files, int depth) {
    if (depth > 64) return;
    for (const auto& item : game.list(dir)) {
        const std::string path = dir.empty() ? item.first : dir + "/" + item.first;
        if (item.second.dir) list_files(game, path, files, depth + 1);
        else files.push_back({path,item.second});
    }
}

} // namespace

bool discover_game_shaders(int game_fd, const std::string& game_name,
                           int prod_keys_fd, int title_keys_fd,
                           const std::string& output_root,
                           const std::string& shader_cache,
                           const std::function<void(int,int,int)>& progress,
                           ShaderDiscoveryStats& stats,
                           std::string& error) {
    stats = {};
    std::vector<nxi::InputFile> inputs;
    inputs.push_back({game_name.empty() ? "YsIX.nsp" : game_name, game_fd});
    inputs.push_back({"prod.keys", prod_keys_fd});
    if (title_keys_fd >= 0) inputs.push_back({"title.keys", title_keys_fd});
    if (progress) progress(1,0,1);
    auto game = nxi::GameImage::open(inputs, kYsIxTitleId, error);
    if (!game) return false;
    if (game->title_id() != kYsIxTitleId) { error = "Selected game image is not Ys IX (title ID mismatch)."; return false; }

    std::vector<std::pair<std::string,nxi::GameImage::Entry>> files;
    list_files(*game, "", files, 0);
    stats.scanned_romfs_files = files.size();
    Extractor output(output_root, shader_cache);
    Vfs3ScanStats vfs_stats;
    for (size_t i = 0; i < files.size(); ++i) {
        if (progress && (i % 8 == 0 || i + 1 == files.size())) progress(2, int(i+1), int(files.size()));
        const auto& entry = files[i].second;
        // Raw files are scanned directly. VFS3 archives are also parsed as containers,
        // then their decoded entries are scanned independently.
        if (!extract_hnsh_file(*game, entry, "romfs", output, error)) return false;
        std::vector<uint8_t> signature;
        if (!entry.dir && entry.size >= 4 && read_entry(*game, entry, 0, 4, signature) &&
            std::memcmp(signature.data(), "VFS3", 4) == 0) {
            auto read_at = [&game, &entry](uint64_t offset, size_t bytes, std::vector<uint8_t>& out) {
                return read_entry(*game, entry, offset, bytes, out);
            };
            std::string archive_error;
            const std::string prefix = "vfs3_" + sha1_16(reinterpret_cast<const uint8_t*>(files[i].first.data()), files[i].first.size());
            if (!scan_vfs3_archive(entry.size, read_at, prefix,
                    [&output, &error](const std::string& group, const std::vector<uint8_t>& decoded) {
                        return extract_hnsh_memory(decoded, group, output, error);
                    }, vfs_stats, archive_error)) {
                ++stats.vfs3_decode_failures;
                if (vfs_stats.first_error.empty()) vfs_stats.first_error = archive_error;
                // A VFS3 magic collision or unsupported variant must not abort the entire import.
            }
        }
    }

    const auto& exefs = game->exefs();
    auto main = exefs.find("main");
    if (main != exefs.end()) {
        if (progress) progress(3,0,1);
        std::vector<uint8_t> flat;
        if (nxi::nso_to_flat_image(main->second, flat, error)) {
            if (!extract_exefs(flat, output, error)) return false;
        } else {
            error = "The game opened, but its main NSO could not be decompressed for shader discovery: " + error;
            return false;
        }
    }
    if (!output.finish_all(error)) return false;
    stats.unique_shader_blocks_found = output.unique_count;
    stats.new_shader_blocks_staged = output.count;
    stats.vfs3_archives_parsed = vfs_stats.archives;
    stats.vfs3_entries_seen = vfs_stats.entries;
    stats.vfs3_entries_decoded = vfs_stats.decoded_entries;
    stats.vfs3_entries_oversized = vfs_stats.oversized_entries;
    stats.vfs3_decode_failures += vfs_stats.decode_failures;
    stats.vfs3_first_error = vfs_stats.first_error;
    if (progress) progress(3,1,1);
    return true;
}

} // namespace ysix
