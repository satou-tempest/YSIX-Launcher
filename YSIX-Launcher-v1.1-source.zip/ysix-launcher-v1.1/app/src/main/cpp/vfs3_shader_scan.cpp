#include "vfs3_shader_scan.h"

#include <algorithm>
#include <climits>
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <limits>
#include <map>
#include <string>
#include <utility>
#include <vector>

#include <zlib.h>
#include <zstd.h>

namespace ysix {
namespace {

constexpr uint64_t kMaxTableBytes = 64ull << 20;
constexpr uint64_t kMaxEntryStored = 64ull << 20;
constexpr uint64_t kMaxEntryDecoded = 128ull << 20;
constexpr uint32_t kMaxDirectories = 100000;
constexpr uint32_t kMaxFiles = 500000;
constexpr uint32_t kMaxStrings = 500000;
constexpr unsigned kMaxDepth = 2;

uint32_t le32(const uint8_t* p) {
    return uint32_t(p[0]) | (uint32_t(p[1]) << 8) | (uint32_t(p[2]) << 16) | (uint32_t(p[3]) << 24);
}
uint64_t le64(const uint8_t* p) {
    return uint64_t(le32(p)) | (uint64_t(le32(p + 4)) << 32);
}
int32_t sle32(const uint8_t* p) {
    return static_cast<int32_t>(le32(p));
}

bool add_fits(uint64_t a, uint64_t b, uint64_t limit) {
    return a <= limit && b <= limit - a;
}

bool read_exact(const std::function<bool(uint64_t, size_t, std::vector<uint8_t>&)>& read_at,
                uint64_t source_size, uint64_t offset, size_t bytes, std::vector<uint8_t>& out) {
    if (!add_fits(offset, bytes, source_size)) return false;
    return read_at(offset, bytes, out) && out.size() == bytes;
}

bool read_string_table(const std::function<bool(uint64_t, size_t, std::vector<uint8_t>&)>& read_at,
                       uint64_t source_size, uint64_t offset, std::vector<std::string>& strings) {
    std::vector<uint8_t> count_bytes;
    if (!read_exact(read_at, source_size, offset, 4, count_bytes)) return false;
    const uint32_t count = le32(count_bytes.data());
    if (count > kMaxStrings) return false;
    uint64_t pos = offset + 4;
    strings.clear();
    strings.reserve(count);
    uint64_t total = 0;
    for (uint32_t i = 0; i < count; ++i) {
        std::vector<uint8_t> len_bytes;
        if (!read_exact(read_at, source_size, pos, 4, len_bytes)) return false;
        const uint32_t len = le32(len_bytes.data());
        pos += 4;
        if (len > (1u << 20) || !add_fits(pos, len, source_size) || total + len > kMaxTableBytes) return false;
        std::vector<uint8_t> value;
        if (!read_exact(read_at, source_size, pos, len, value)) return false;
        strings.emplace_back(value.empty() ? "" : reinterpret_cast<const char*>(value.data()), value.size());
        pos += len;
        total += len;
    }
    return true;
}

std::string safe_component(const std::string& s) {
    std::string out;
    out.reserve(std::min<size_t>(s.size(), 64));
    uint32_t hash = 2166136261u;
    for (unsigned char c : s) {
        hash = (hash ^ c) * 16777619u;
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
            (c >= '0' && c <= '9') || c == '_' || c == '-') out.push_back(static_cast<char>(c));
        else if (out.empty() || out.back() != '_') out.push_back('_');
    }
    while (!out.empty() && (out.front() == '_' || out.front() == '-')) out.erase(out.begin());
    while (!out.empty() && (out.back() == '_' || out.back() == '-')) out.pop_back();
    if (out.empty()) out = "entry";
    // Keep generated directory names below common filesystem NAME_MAX limits,
    // without making long distinct archive paths collide after sanitization.
    if (out.size() > 72) {
        char suffix[10];
        std::snprintf(suffix, sizeof(suffix), "_%08x", hash);
        out.resize(72);
        out += suffix;
    }
    return out;
}

struct DirectoryRecord {
    int32_t id = -1;
    int32_t parent = -1;
    uint32_t name_index = 0;
};
struct FileRecord {
    uint64_t offset = 0;
    uint64_t stored_size = 0;
    uint64_t decoded_size = 0;
    uint32_t name_index = 0;
    uint32_t chunk_index = 0;
    uint32_t flags = 0;
    uint32_t directory_id = 0;
};

bool resolve_directory(int32_t id, const std::map<int32_t, DirectoryRecord>& records,
                       const std::vector<std::string>& names, std::map<int32_t, std::string>& resolved,
                       std::vector<int32_t>& stack) {
    auto done = resolved.find(id);
    if (done != resolved.end()) return true;
    auto it = records.find(id);
    if (it == records.end() || it->second.name_index >= names.size()) return false;
    if (std::find(stack.begin(), stack.end(), id) != stack.end()) return false;
    stack.push_back(id);
    std::string path = names[it->second.name_index];
    if (it->second.parent != -1) {
        if (!resolve_directory(it->second.parent, records, names, resolved, stack)) return false;
        const std::string& parent = resolved[it->second.parent];
        if (!parent.empty()) path = parent + "/" + path;
    }
    stack.pop_back();
    resolved[id] = path;
    return true;
}

bool decode_zlib(const std::vector<uint8_t>& input, size_t expected, std::vector<uint8_t>& output) {
    if (expected == 0 || expected > kMaxEntryDecoded) return false;
    output.resize(expected);
    uLongf size = static_cast<uLongf>(expected);
    const int rc = uncompress(output.data(), &size, input.data(), static_cast<uLong>(input.size()));
    if (rc != Z_OK || size != expected) {
        output.clear();
        return false;
    }
    return true;
}

bool make_nis_zstd_frame(const std::vector<uint8_t>& input, const std::vector<int32_t>& chunks,
                         std::vector<uint8_t>& frame) {
    // NIS VFS3 stores independent Zstd blocks with signed lengths: negative = raw block,
    // positive = compressed block. Rebuild a standard single-segment Zstd frame around them.
    static constexpr uint8_t prefix[] = {0x28, 0xB5, 0x2F, 0xFD, 0x00, 0x88};
    frame.assign(std::begin(prefix), std::end(prefix));
    uint64_t input_pos = 0;
    for (int32_t signed_size : chunks) {
        if (signed_size == 0 || signed_size == INT32_MIN) return false;
        const uint32_t block_size = static_cast<uint32_t>(signed_size < 0 ? -signed_size : signed_size);
        if (block_size > 0x1FFFFF || !add_fits(input_pos, block_size, input.size())) return false;
        const uint32_t block_type = signed_size < 0 ? 0u : 4u;
        const uint32_t header = (block_size << 3) | block_type;
        frame.push_back(static_cast<uint8_t>(header));
        frame.push_back(static_cast<uint8_t>(header >> 8));
        frame.push_back(static_cast<uint8_t>(header >> 16));
        frame.insert(frame.end(), input.begin() + static_cast<ptrdiff_t>(input_pos),
                     input.begin() + static_cast<ptrdiff_t>(input_pos + block_size));
        input_pos += block_size;
    }
    if (input_pos != input.size()) return false;
    frame.push_back(1); frame.push_back(0); frame.push_back(0); // last, empty final block
    return true;
}

bool decode_zstd(const std::vector<uint8_t>& input, size_t expected,
                 const std::vector<int32_t>* chunks, const std::vector<uint8_t>* dictionary,
                 std::vector<uint8_t>& output) {
    if (expected == 0 || expected > kMaxEntryDecoded) return false;
    std::vector<uint8_t> framed;
    const std::vector<uint8_t>* source = &input;
    if (chunks && !chunks->empty()) {
        if (!make_nis_zstd_frame(input, *chunks, framed)) return false;
        source = &framed;
    }
    output.resize(expected);
    ZSTD_DCtx* context = ZSTD_createDCtx();
    if (!context) { output.clear(); return false; }
    const void* dict_data = (dictionary && !dictionary->empty()) ? dictionary->data() : nullptr;
    const size_t dict_size = (dictionary && !dictionary->empty()) ? dictionary->size() : 0;
    const size_t result = ZSTD_decompress_usingDict(context, output.data(), output.size(),
                                                     source->data(), source->size(), dict_data, dict_size);
    ZSTD_freeDCtx(context);
    if (ZSTD_isError(result) || result != expected) {
        output.clear();
        return false;
    }
    return true;
}

bool scan_source(uint64_t source_size,
                 const std::function<bool(uint64_t, size_t, std::vector<uint8_t>&)>& read_at,
                 const std::string& group_prefix,
                 const std::function<bool(const std::string&, const std::vector<uint8_t>&)>& visit,
                 Vfs3ScanStats& stats, std::string& error, unsigned depth) {
    if (depth > kMaxDepth) return true;
    std::vector<uint8_t> fixed;
    if (!read_exact(read_at, source_size, 0, 16, fixed) || std::memcmp(fixed.data(), "VFS3", 4) != 0) return false;
    const uint32_t flags = le32(fixed.data() + 4);
    const uint32_t version = le32(fixed.data() + 8);
    const uint32_t directory_count = le32(fixed.data() + 12);
    if (version != 1 || directory_count > kMaxDirectories) {
        error = "VFS3 header has an unsupported version or implausible directory count";
        return false;
    }
    const uint64_t dir_table_offset = 0x10;
    const uint64_t dir_table_size = uint64_t(directory_count) * 0x1C;
    if (dir_table_size > kMaxTableBytes || !add_fits(dir_table_offset, dir_table_size + 4, source_size)) {
        error = "VFS3 directory table is outside the archive bounds";
        return false;
    }
    std::vector<uint8_t> dir_table;
    if (!read_exact(read_at, source_size, dir_table_offset, static_cast<size_t>(dir_table_size), dir_table)) {
        error = "Could not read VFS3 directory table";
        return false;
    }
    std::vector<uint8_t> count_buf;
    const uint64_t file_count_offset = dir_table_offset + dir_table_size;
    if (!read_exact(read_at, source_size, file_count_offset, 4, count_buf)) {
        error = "VFS3 file table count is truncated";
        return false;
    }
    const uint32_t file_count = le32(count_buf.data());
    if (file_count > kMaxFiles) {
        error = "VFS3 file count exceeds the safety limit";
        return false;
    }
    const uint64_t file_table_offset = file_count_offset + 4;
    const uint64_t file_table_size = uint64_t(file_count) * 0x28;
    if (file_table_size > kMaxTableBytes || !add_fits(file_table_offset, file_table_size + 24, source_size)) {
        error = "VFS3 file table is outside the archive bounds";
        return false;
    }
    std::vector<uint8_t> file_table;
    std::vector<uint8_t> offsets;
    if (!read_exact(read_at, source_size, file_table_offset, static_cast<size_t>(file_table_size), file_table) ||
        !read_exact(read_at, source_size, file_table_offset + file_table_size, 24, offsets)) {
        error = "Could not read VFS3 file table or offset directory";
        return false;
    }
    uint64_t chunk_table_offset = 0, dictionary_table_offset = 0, string_table_offset = 0;
    size_t offset_index = 0;
    if (flags & 0x10u) chunk_table_offset = le64(offsets.data() + offset_index++ * 8);
    if (flags & 0x20u) dictionary_table_offset = le64(offsets.data() + offset_index++ * 8);
    string_table_offset = le64(offsets.data() + offset_index * 8);
    const uint64_t data_base = file_table_offset + file_table_size + 24;
    std::vector<std::string> file_names, directory_names;
    if (!read_string_table(read_at, source_size, string_table_offset, file_names)) {
        error = "VFS3 file-name string table is invalid";
        return false;
    }
    // The directory-name table immediately follows the file-name table.
    std::vector<uint8_t> fsc_bytes;
    if (!read_exact(read_at, source_size, string_table_offset, 4, fsc_bytes)) return false;
    uint64_t dir_string_offset = string_table_offset + 4;
    for (const std::string& name : file_names) dir_string_offset += 4 + name.size();
    if (!read_string_table(read_at, source_size, dir_string_offset, directory_names)) {
        error = "VFS3 directory-name string table is invalid";
        return false;
    }

    std::map<int32_t, DirectoryRecord> directories;
    for (uint32_t i = 0; i < directory_count; ++i) {
        const uint8_t* p = dir_table.data() + size_t(i) * 0x1C;
        DirectoryRecord d;
        d.id = sle32(p + 4);
        d.parent = sle32(p + 8);
        d.name_index = static_cast<uint32_t>(d.id);
        if (d.id < 0 || d.name_index >= directory_names.size() || !directories.emplace(d.id, d).second) {
            error = "VFS3 directory table contains an invalid ID or name index";
            return false;
        }
    }
    std::map<int32_t, std::string> directory_paths;
    std::vector<int32_t> stack;
    for (const auto& item : directories) {
        if (!resolve_directory(item.first, directories, directory_names, directory_paths, stack)) {
            error = "VFS3 directory tree contains a missing parent or cycle";
            return false;
        }
    }

    std::vector<std::vector<int32_t>> chunk_lists;
    if ((flags & 0x10u) && chunk_table_offset != 0) {
        std::vector<uint8_t> len_bytes;
        if (!read_exact(read_at, source_size, chunk_table_offset, 4, len_bytes)) {
            error = "VFS3 chunk table is truncated";
            return false;
        }
        const uint64_t end = chunk_table_offset + 4ull + le32(len_bytes.data());
        if (end > source_size || end < chunk_table_offset + 4) {
            error = "VFS3 chunk table has an invalid size";
            return false;
        }
        uint64_t pos = chunk_table_offset + 4;
        while (pos < end) {
            std::vector<uint8_t> row_len_bytes;
            if (!read_exact(read_at, source_size, pos, 4, row_len_bytes)) return false;
            const uint32_t row_bytes = le32(row_len_bytes.data());
            pos += 4;
            if (row_bytes == 0 || (row_bytes % 4) != 0 || row_bytes > kMaxTableBytes || !add_fits(pos, row_bytes, end)) {
                error = "VFS3 chunk row has an invalid size";
                return false;
            }
            std::vector<uint8_t> row;
            if (!read_exact(read_at, source_size, pos, row_bytes, row)) return false;
            std::vector<int32_t> chunks;
            chunks.reserve(row_bytes / 4);
            for (size_t j = 0; j < row.size(); j += 4) chunks.push_back(sle32(row.data() + j));
            chunk_lists.push_back(std::move(chunks));
            pos += row_bytes;
        }
    }

    std::vector<std::vector<uint8_t>> dictionaries;
    if ((flags & 0x20u) && dictionary_table_offset != 0) {
        std::vector<uint8_t> count_bytes;
        if (!read_exact(read_at, source_size, dictionary_table_offset, 8, count_bytes)) return false;
        const uint32_t count = le32(count_bytes.data());
        if (count > 4096) { error = "VFS3 dictionary count exceeds the safety limit"; return false; }
        uint64_t pos = dictionary_table_offset + 8;
        dictionaries.reserve(count);
        for (uint32_t i = 0; i < count; ++i) {
            std::vector<uint8_t> len_bytes;
            if (!read_exact(read_at, source_size, pos, 4, len_bytes)) return false;
            const uint32_t len = le32(len_bytes.data());
            pos += 4;
            if (len > kMaxEntryStored || !add_fits(pos, len, source_size)) {
                error = "VFS3 dictionary has an invalid size";
                return false;
            }
            std::vector<uint8_t> dict;
            if (!read_exact(read_at, source_size, pos, len, dict)) return false;
            dictionaries.push_back(std::move(dict));
            pos += len;
        }
    }

    ++stats.archives;
    const std::string prefix = group_prefix.empty() ? "vfs3" : safe_component(group_prefix);
    for (uint32_t i = 0; i < file_count; ++i) {
        const uint8_t* p = file_table.data() + size_t(i) * 0x28;
        FileRecord f;
        const uint64_t relative_offset = le64(p);
        if (relative_offset > std::numeric_limits<uint64_t>::max() - data_base) {
            ++stats.decode_failures;
            continue;
        }
        f.offset = relative_offset + data_base;
        f.stored_size = le64(p + 8);
        f.decoded_size = le64(p + 16);
        f.name_index = le32(p + 28);
        f.chunk_index = le32(p + 28);
        f.flags = le32(p + 32);
        f.directory_id = le32(p + 36);
        ++stats.entries;
        auto dir = directory_paths.find(static_cast<int32_t>(f.directory_id));
        if (f.name_index >= file_names.size() || dir == directory_paths.end() ||
            !add_fits(f.offset, f.stored_size, source_size)) {
            ++stats.decode_failures;
            if (stats.first_error.empty()) stats.first_error = "VFS3 file entry has an invalid name, directory, or data range";
            continue;
        }
        if (f.stored_size > kMaxEntryStored || f.decoded_size > kMaxEntryDecoded ||
            f.stored_size == 0 || f.decoded_size == 0) {
            ++stats.oversized_entries;
            if (stats.first_error.empty()) stats.first_error = "VFS3 entry exceeded the configured stored/decoded size limit";
            continue;
        }
        std::vector<uint8_t> stored;
        if (!read_exact(read_at, source_size, f.offset, static_cast<size_t>(f.stored_size), stored)) {
            ++stats.decode_failures;
            continue;
        }
        std::vector<uint8_t> decoded;
        if (f.flags & 0x2u) {
            bool ok = false;
            if (f.flags & 0x1u) {
                const std::vector<int32_t>* chunks = nullptr;
                if (!chunk_lists.empty()) {
                    if (f.chunk_index >= chunk_lists.size()) { ++stats.decode_failures; continue; }
                    chunks = &chunk_lists[f.chunk_index];
                }
                const std::vector<uint8_t>* dictionary = nullptr;
                const uint32_t dictionary_index = f.flags >> 16;
                if ((flags & 0x20u) && dictionary_index != 0xFFFFu) {
                    if (dictionary_index >= dictionaries.size()) { ++stats.decode_failures; continue; }
                    dictionary = &dictionaries[dictionary_index];
                }
                ok = decode_zstd(stored, static_cast<size_t>(f.decoded_size), chunks, dictionary, decoded);
            } else {
                ok = decode_zlib(stored, static_cast<size_t>(f.decoded_size), decoded);
            }
            if (!ok) {
                ++stats.decode_failures;
                if (stats.first_error.empty()) stats.first_error = "VFS3 entry decompression failed or used an unsupported encoding";
                continue;
            }
        } else {
            if (f.stored_size != f.decoded_size) { ++stats.decode_failures; continue; }
            decoded = std::move(stored);
        }
        ++stats.decoded_entries;
        const std::string path = dir->second.empty() ? file_names[f.name_index] : dir->second + "/" + file_names[f.name_index];
        const std::string group = prefix + "_" + safe_component(path);
        if (decoded.size() >= 4 && std::memcmp(decoded.data(), "VFS3", 4) == 0 && depth < kMaxDepth) {
            auto nested_read = [&decoded](uint64_t offset, size_t bytes, std::vector<uint8_t>& out) {
                if (!add_fits(offset, bytes, decoded.size())) return false;
                out.assign(decoded.begin() + static_cast<ptrdiff_t>(offset),
                           decoded.begin() + static_cast<ptrdiff_t>(offset + bytes));
                return true;
            };
            std::string nested_error;
            if (!scan_source(decoded.size(), nested_read, group, visit, stats, nested_error, depth + 1)) {
                ++stats.decode_failures;
            }
        } else if (!visit(group, decoded)) {
            error = "VFS3 shader visitor could not process " + path;
            return false;
        }
    }
    return true;
}

} // namespace

bool scan_vfs3_archive(uint64_t source_size,
                       const std::function<bool(uint64_t, size_t, std::vector<uint8_t>&)>& read_at,
                       const std::string& group_prefix,
                       const std::function<bool(const std::string&, const std::vector<uint8_t>&)>& visit,
                       Vfs3ScanStats& stats, std::string& error, unsigned depth) {
    if (!read_at || !visit) {
        error = "VFS3 scanner requires read and visit callbacks";
        return false;
    }
    const bool ok = scan_source(source_size, read_at, group_prefix, visit, stats, error, depth);
    if (!ok && stats.first_error.empty()) stats.first_error = error;
    return ok;
}

} // namespace ysix
