#pragma once

#include <cstddef>
#include <functional>
#include <string>

namespace ysix {

struct ShaderDiscoveryStats {
    size_t scanned_romfs_files = 0;
    size_t unique_shader_blocks_found = 0;
    size_t new_shader_blocks_staged = 0;
    size_t vfs3_archives_parsed = 0;
    size_t vfs3_entries_seen = 0;
    size_t vfs3_entries_decoded = 0;
    size_t vfs3_entries_oversized = 0;
    size_t vfs3_decode_failures = 0;
    std::string vfs3_first_error;
};

// Extracts shader records from the selected Ys IX image, supported nested VFS3
// content, and the main NSO. Only records that pass structural checks are accepted.
bool discover_game_shaders(int game_fd, const std::string& game_name,
                           int prod_keys_fd, int title_keys_fd,
                           const std::string& output_root,
                           const std::string& shader_cache,
                           const std::function<void(int phase, int done, int total)>& progress,
                           ShaderDiscoveryStats& stats,
                           std::string& error);

} // namespace ysix
