#pragma once

#include <cstddef>
#include <cstdint>
#include <functional>
#include <string>
#include <vector>

namespace ysix {

struct Vfs3ScanStats {
    size_t archives = 0;
    size_t entries = 0;
    size_t decoded_entries = 0;
    size_t oversized_entries = 0;
    size_t decode_failures = 0;
    std::string first_error;
};

// Reads a NIS America VFS3 archive through a bounded random-access callback. Decoded
// entries are passed to visit(); compressed entries that exceed the memory guard or
// use an unsupported/invalid encoding are counted and skipped, never guessed.
bool scan_vfs3_archive(
    uint64_t source_size,
    const std::function<bool(uint64_t, size_t, std::vector<uint8_t>&)>& read_at,
    const std::string& group_prefix,
    const std::function<bool(const std::string&, const std::vector<uint8_t>&)>& visit,
    Vfs3ScanStats& stats,
    std::string& error,
    unsigned depth = 0);

} // namespace ysix
