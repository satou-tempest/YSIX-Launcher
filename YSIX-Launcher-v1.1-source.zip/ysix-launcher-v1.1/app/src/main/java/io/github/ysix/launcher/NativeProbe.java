package io.github.ysix.launcher;

/** JNI bridge for Ys IX diagnostics and package/runtime shader discovery + translation. */
public final class NativeProbe {
    static { System.loadLibrary("ysixprobe"); }
    public static native String inspect(int gameFd, String gameName, int prodKeysFd, int titleKeysFd);
    /** Scan the selected Ys IX image for recognized Maxwell shader records, add runtime captures, and translate. */
    public static String prepareGameShaders(int gameFd, String gameName, int prodKeysFd, int titleKeysFd,
                                            String dataRoot, int jobs) {
        try {
            System.loadLibrary("spirvharness");
        } catch (UnsatisfiedLinkError e) {
            return "The bundled ARM64 shader translator could not be loaded: " + e.getMessage();
        }
        return nativePrepareGameShaders(gameFd, gameName, prodKeysFd, titleKeysFd, dataRoot, jobs);
    }
    /** Legacy runtime-capture-only translation entry point, retained for diagnostics. */
    public static String prepareShaders(String dataRoot, int jobs) {
        try {
            System.loadLibrary("spirvharness");
        } catch (UnsatisfiedLinkError e) {
            return "The bundled ARM64 shader translator could not be loaded: " + e.getMessage();
        }
        return nativePrepareShaders(dataRoot, jobs);
    }
    private static native String nativePrepareShaders(String dataRoot, int jobs);
    private static native String nativePrepareGameShaders(int gameFd, String gameName, int prodKeysFd,
                                                           int titleKeysFd, String dataRoot, int jobs);
    /** Preparation progress: [phase, completed, total]. */
    public static native int[] shaderProgress();
    private NativeProbe() { }
}
