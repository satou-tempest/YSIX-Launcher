# Development roadmap

## v0.1 — Launcher foundation
Completed: Java-only UI, document pickers and saved preferences.

## v0.2 — Visual identity
Completed: gothic adaptive launcher icon patch.

## v0.3 — Launcher frontend
Completed: navigation, library selection, graphics/control preferences and device diagnostics.

## v0.4 — Native bring-up probe
Device-tested on Galaxy A22 5G (Mali-G57 MC2) and Redmi Turbo 4 (Mali-G720 MC7): local Ys IX image open/decryption, ExeFS `main`/`sdk` NSO hash checks, Vulkan instance/device/graphics queue initialization all reported PASS on both devices.

## v0.5 — Native loader staging + content tools
Device-tested on both target phones: MOD0/dynamic/symbol/relocation metadata inspection and temporary `MAP_FIXED_NOREPLACE` staging maps for `main` and `sdk` passed Gate B1. ZIP save archive import/export and a DLC package reference queue were added. Live in-game save-data and DLC mounting remain unimplemented.

## v0.6 — Temporary relocation and symbol-resolution test
Adds simultaneous RW/non-executable mappings for both modules, a defined-symbol export index, application of supported relocations when resolvable inside the `main`/`sdk` scope, and read-back verification. Unresolved strong imports and unsupported relocation types are reported; unresolved addresses are never faked. Both phones later passed Gate B2a.

## v0.7 — Horizon import resolver and NCE bootstrap
Attempts the actual generic NCE runtime startup path, with four Ys IX ExeFS modules loaded and the reference Horizon/HLE + NVN runtime integrated. The Galaxy A22 test showed the runtime reaching NVN frame presentation but failing to execute shader draws because translated SPIR-V programs were absent. The same log showed a later video/movie stall.

## v0.8 — Runtime shader preparation and touch overlay
Adds lazy capture of shaders actually requested by Ys IX, generic Ryujinx Maxwell-to-SPIR-V translation, persistent shader cache and a provisional on-screen Switch layout. This version must be tested on Galaxy A22 5G. The MP4/movie path remains an open blocker.

## v0.9 — Startup compatibility and input diagnostics
Adds a test-only `NX_SKIP_MOVIE` hook around the `ClientStreamReader`-based movie source path that stalled in the A22 trace, with a lower-level fallback. Adds Android touch/key and guest pad-state logs, and rate-limits repeated unresolved-import warnings. Movie playback is not fixed; the bypass may skip startup films/cutscenes. The `WorkBufferBase::inUse` TLS initializer remains unresolved. The v0.9 acceptance target is the Ys IX main menu with responsive touch controls; it is not yet verified.

## Next gates
1. Verify that one movie-source hook installs and returns an error before Android Stagefright waits.
2. Check whether the game progresses to the main menu; investigate any new service/import failure.
3. Confirm raw touch events and guest pad changes in `nx.log`, then verify A/B/X/Y and directional input at the menu.
4. Resolve the `WorkBufferBase::inUse` TLS initializer using a correct per-thread initialization, not a permanent zero stub.
5. Implement real Ys IX media streaming/decoding so videos/cutscenes work without the temporary bypass.
6. Implement remaining Ys IX service imports, file/save behavior, audio, resource formats and synchronization.
7. Validate a stable playable scene and a clean 10-minute run before claiming gameplay readiness.


## v1.0 — Audio discovery and FPS overlay
Expose the generic runtime's existing present-rate overlay through a persistent launcher switch. Instrument the Ys IX audio renderer's failed SDK-vtable lookup and AAudio errors without guessing an SDK offset. Acceptance: toggleable visible two-digit FPS display; next log identifies the renderer object candidates. Audio is not counted as fixed until non-silent PCM reaches AAudio. New Game load time and Redmi graphics glitches remain follow-on work.
