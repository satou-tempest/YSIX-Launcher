# Native loader synthetic regression test

Run on Linux x86-64 with a C++17 compiler:

```sh
./tests/run_native_loader_test.sh
```

The test supplies tiny synthetic flat module images through a stub `nxi::nso_to_flat_image`. It verifies that the loader:
- maps both modules simultaneously with `MAP_FIXED_NOREPLACE`;
- applies a relative relocation;
- resolves a defined local symbol;
- resolves an import from the other module;
- binds an unresolved weak import to zero;
- leaves an unresolved strong import untouched and lists it;
- skips and reports an unknown relocation type;
- reads back all temporary writes and discards the mappings.

This test isolates the symbol/relocation code. It does **not** test NSP/XCI parsing, NSO decompression, Android NDK integration, real Ys IX binaries, Horizon services, or gameplay.

## v1.1 shader-discovery regression

Run `bash tests/check_v11_shader_source.sh`. It retains the v1.0 runtime/loader fixtures, checks the new game-image shader-preparation wiring, compiles the VFS3 scanner, and exercises raw, zlib, Zstandard, and NIS chunked-raw VFS3 entries. The scanner deliberately labels only validated records as discovered; unsupported archive variants are counted as skips rather than being reported as translated.
