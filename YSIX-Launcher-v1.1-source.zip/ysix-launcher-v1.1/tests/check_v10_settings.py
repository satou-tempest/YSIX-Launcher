from pathlib import Path

root = Path(__file__).resolve().parents[1]
s = (root / "app/src/main/java/io/github/ysix/launcher/MainActivity.java").read_text()
assert 'CheckBox showFps = checkBox("Show in-game FPS counter"' in s
assert 'writeRuntimeConfig(prefs.getBoolean("touch_controls", true),' in s
assert 'lines.add("NX_SHOW_FPS=" + (showFps ? "1" : "0"));' in s
assert '!line.startsWith("NX_SHOW_FPS=")' in s
assert 'lines.add("NX_TRACE_AUDIO_DISCOVERY=1");' in s
assert 'putBoolean("show_fps", false)' in s
print("v1.0 launcher FPS toggle/config checks: PASS")
