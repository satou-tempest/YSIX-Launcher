#pragma once
#include <cstdint>
namespace nx {
struct CPU { uint64_t x[31]{}; };
using HleFn = void (*)(CPU&);
void log(const char* fmt, ...);
uint64_t hook_function(uint64_t addr, HleFn fn);
}
