#pragma once
#include <cstdint>
namespace nx::game {
struct Info {
    const char* id;
    const char* title;
    uint64_t program_id;
    const char* android_package;
    const char* data_dir;
    uint32_t flags;
    const char* main_build_id;
};
extern const Info kInfo;
void after_init();
void renderer_start();
void first_frame();
}
