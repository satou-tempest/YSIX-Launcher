#pragma once
#include <cstdint>
#include <functional>
#include <map>
#include <memory>
#include <string>
#include <utility>
#include <vector>
namespace nxi {
struct InputFile { std::string name; int fd = -1; };
class GameImage {
public:
  struct Entry { uint64_t off = 0, size = 0; bool dir = false; };
  static std::unique_ptr<GameImage> open(const std::vector<InputFile>&, uint64_t, std::string&) { return nullptr; }
  uint64_t title_id() const { return 0; }
  const std::map<std::string, std::vector<uint8_t>>& exefs() const { return files; }
  std::vector<std::pair<std::string, Entry>> list(const std::string&) const { return {}; }
  uint64_t read(const Entry&, uint64_t, void*, uint64_t) const { return 0; }
  std::map<std::string, std::vector<uint8_t>> files;
};
bool nso_to_flat_image(const std::vector<uint8_t>& raw, std::vector<uint8_t>& flat, std::string& error);
}
