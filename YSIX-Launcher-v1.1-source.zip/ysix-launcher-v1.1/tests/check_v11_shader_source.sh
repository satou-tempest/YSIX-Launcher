#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
python3 -m py_compile "$ROOT/tools/runtime-bridge/patch_p5r_runtime.py" "$ROOT/tests/runtime_patch_fixture.py"
python3 "$ROOT/tests/runtime_patch_fixture.py"
python3 "$ROOT/tests/check_v10_settings.py"
bash "$ROOT/tests/run_native_loader_test.sh"

if command -v c++ >/dev/null 2>&1; then
  JDK_HOME="${JAVA_HOME:-}"
  if [[ -z "$JDK_HOME" ]] && command -v javac >/dev/null 2>&1; then
    JDK_HOME="$(dirname "$(dirname "$(readlink -f "$(command -v javac)")")")"
  fi
  JNI_FLAGS=()
  if [[ -n "$JDK_HOME" && -d "$JDK_HOME/include" ]]; then
    JNI_FLAGS+=( -I"$JDK_HOME/include" -I"$JDK_HOME/include/linux" )
  fi
  c++ -std=c++17 -Wall -Wextra -Werror "${JNI_FLAGS[@]}" -I"$ROOT/tests/support" -I"$ROOT/app/src/main/cpp" -fsyntax-only \
    "$ROOT/tools/runtime-bridge/ysix_game.cpp" \
    "$ROOT/app/src/main/cpp/shader_game_discovery.cpp" \
    "$ROOT/app/src/main/cpp/shader_prepare.cpp"
  c++ -std=c++17 -Wall -Wextra -Werror -I"$ROOT/app/src/main/cpp" \
    "$ROOT/app/src/main/cpp/vfs3_shader_scan.cpp" "$ROOT/tests/vfs3_shader_scan_test.cpp" \
    -lz -lzstd -o "$ROOT/tests/.vfs3_shader_scan_test"
  "$ROOT/tests/.vfs3_shader_scan_test"
  rm -f "$ROOT/tests/.vfs3_shader_scan_test"
fi

python3 - <<'PY' "$ROOT"
import pathlib, sys
root = pathlib.Path(sys.argv[1])
cmake = (root / "app/src/main/cpp/CMakeLists.txt").read_text()
assert "vfs3_shader_scan.cpp" in cmake
assert "YSIX_ZSTD_LIBRARY" in cmake
src = (root / "app/src/main/cpp/shader_game_discovery.cpp").read_text()
assert "'H','N','S','H'" in src and "scan_vfs3_archive" in src
ui = (root / "app/src/main/java/io/github/ysix/launcher/MainActivity.java").read_text()
assert "GAME SHADER PREPARATION" in ui
assert "Translating Maxwell shaders" in ui
probe = (root / "app/src/main/cpp/native_probe.cpp").read_text()
for feature in ("storage-image-read-no-format", "ASTC 8x8", "RGBA16F", "D24S8"):
    assert feature in probe
PY

echo "YS IX v1.1 shader discovery and Vulkan diagnostics checks: PASS"
