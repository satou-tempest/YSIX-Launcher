#include "vfs3_shader_scan.h"

#include <cassert>
#include <cstdint>
#include <cstring>
#include <iostream>
#include <string>
#include <vector>

#include <zlib.h>
#include <zstd.h>

namespace {
void put32(std::vector<uint8_t>& b, size_t o, uint32_t v) {
    for (int i = 0; i < 4; ++i) b[o + i] = static_cast<uint8_t>(v >> (i * 8));
}
void put64(std::vector<uint8_t>& b, size_t o, uint64_t v) {
    for (int i = 0; i < 8; ++i) b[o + i] = static_cast<uint8_t>(v >> (i * 8));
}
void append32(std::vector<uint8_t>& b, uint32_t v) {
    const size_t o = b.size(); b.resize(o + 4); put32(b, o, v);
}
void append_string(std::vector<uint8_t>& b, const std::string& s) {
    append32(b, static_cast<uint32_t>(s.size()));
    b.insert(b.end(), s.begin(), s.end());
}

struct Payload {
    std::string name;
    std::vector<uint8_t> stored;
    uint32_t flags = 0;
    uint32_t chunk_index = 0;
    std::vector<uint8_t> decoded;
};

std::vector<uint8_t> make_archive(const std::vector<Payload>& payloads,
                                  bool chunked_raw = false) {
    const uint32_t archive_flags = chunked_raw ? 0x10u : 0u;
    std::vector<uint8_t> b(16 + 0x1C + 4 + payloads.size() * 0x28 + 24, 0);
    std::memcpy(b.data(), "VFS3", 4);
    put32(b, 4, archive_flags);
    put32(b, 8, 1); // VFS3 version
    put32(b, 12, 1); // one directory
    // Directory record: reserved, id, parent id, reserved.
    put32(b, 16 + 4, 0);
    put32(b, 16 + 8, 0xFFFFFFFFu);

    const size_t file_count_off = 16 + 0x1C;
    put32(b, file_count_off, static_cast<uint32_t>(payloads.size()));
    const size_t file_table_off = file_count_off + 4;
    const size_t offsets_off = file_table_off + payloads.size() * 0x28;
    const size_t data_base = offsets_off + 24;

    size_t data_pos = data_base;
    std::vector<size_t> data_offsets;
    for (const auto& p : payloads) {
        data_offsets.push_back(data_pos - data_base);
        b.insert(b.end(), p.stored.begin(), p.stored.end());
        data_pos += p.stored.size();
    }

    size_t chunk_table_off = 0;
    if (chunked_raw) {
        chunk_table_off = b.size();
        append32(b, 4 + 4); // table bytes after size word: one row-size + one s32 chunk length
        append32(b, static_cast<uint32_t>(payloads.front().stored.size() < 0x80000000u
                                          ? 4 : 0));
        append32(b, static_cast<uint32_t>(-static_cast<int32_t>(payloads.front().stored.size()))); // signed negative raw block size
    }

    const size_t string_table_off = b.size();
    append32(b, static_cast<uint32_t>(payloads.size()));
    for (const auto& p : payloads) append_string(b, p.name);
    append32(b, 1); // one directory name
    append_string(b, "romfs");

    for (size_t i = 0; i < payloads.size(); ++i) {
        const size_t r = file_table_off + i * 0x28;
        put64(b, r, data_offsets[i]);
        put64(b, r + 8, payloads[i].stored.size());
        put64(b, r + 16, payloads[i].decoded.size());
        put32(b, r + 24, 0); // reserved in the observed VFS3 entry layout
        put32(b, r + 28, static_cast<uint32_t>(i)); // filename/chunk-list index
        put32(b, r + 32, payloads[i].flags);
        put32(b, r + 36, 0);
    }
    if (chunked_raw) {
        put64(b, offsets_off, chunk_table_off);
        put64(b, offsets_off + 8, string_table_off);
    } else {
        put64(b, offsets_off, string_table_off);
    }
    return b;
}

std::vector<uint8_t> bytes(const std::string& s) { return {s.begin(), s.end()}; }

} // namespace

int main() {
    const auto raw = bytes("Ys IX raw shader payload");
    const auto zlib_plain = bytes("Ys IX zlib compressed payload");
    const auto zstd_plain = bytes("Ys IX zstandard compressed payload");

    Payload p0{"raw.bin", raw, 0, 0, raw};
    Payload p1;
    p1.name = "zlib.bin";
    p1.decoded = zlib_plain;
    p1.flags = 2;
    uLongf zlib_size = compressBound(static_cast<uLong>(zlib_plain.size()));
    p1.stored.resize(zlib_size);
    assert(compress2(p1.stored.data(), &zlib_size, zlib_plain.data(),
                     static_cast<uLong>(zlib_plain.size()), Z_BEST_COMPRESSION) == Z_OK);
    p1.stored.resize(zlib_size);

    Payload p2;
    p2.name = "zstd.bin";
    p2.decoded = zstd_plain;
    p2.flags = 3;
    p2.stored.resize(ZSTD_compressBound(zstd_plain.size()));
    const size_t zstd_size = ZSTD_compress(p2.stored.data(), p2.stored.size(),
                                            zstd_plain.data(), zstd_plain.size(), 3);
    assert(!ZSTD_isError(zstd_size));
    p2.stored.resize(zstd_size);

    auto archive = make_archive({p0, p1, p2});
    ysix::Vfs3ScanStats stats;
    std::string error;
    std::vector<std::string> paths;
    const auto read_at = [&archive](uint64_t offset, size_t size, std::vector<uint8_t>& out) {
        if (offset > archive.size() || size > archive.size() - static_cast<size_t>(offset)) return false;
        out.assign(archive.begin() + static_cast<ptrdiff_t>(offset),
                   archive.begin() + static_cast<ptrdiff_t>(offset + size));
        return true;
    };
    const bool ok = ysix::scan_vfs3_archive(archive.size(), read_at, "fixture",
        [&paths](const std::string& path, const std::vector<uint8_t>& data) {
            paths.push_back(path);
            if (path.find("raw_bin") != std::string::npos) return data == bytes("Ys IX raw shader payload");
            if (path.find("zlib_bin") != std::string::npos) return data == bytes("Ys IX zlib compressed payload");
            if (path.find("zstd_bin") != std::string::npos) return data == bytes("Ys IX zstandard compressed payload");
            return false;
        }, stats, error);
    assert(ok && error.empty());
    assert(stats.archives == 1);
    assert(stats.entries == 3);
    assert(stats.decoded_entries == 3);
    assert(stats.decode_failures == 0);
    assert(paths.size() == 3);

    // A NIS chunked Zstd entry using a single raw block must also be accepted.
    Payload p3{"chunked.bin", raw, 3, 0, raw};
    auto chunked = make_archive({p3}, true);
    ysix::Vfs3ScanStats chunk_stats;
    std::string chunk_error;
    const auto chunk_read = [&chunked](uint64_t offset, size_t size, std::vector<uint8_t>& out) {
        if (offset > chunked.size() || size > chunked.size() - static_cast<size_t>(offset)) return false;
        out.assign(chunked.begin() + static_cast<ptrdiff_t>(offset),
                   chunked.begin() + static_cast<ptrdiff_t>(offset + size));
        return true;
    };
    bool chunk_visited = false;
    const bool chunk_ok = ysix::scan_vfs3_archive(chunked.size(), chunk_read, "fixture",
        [&chunk_visited, &raw](const std::string&, const std::vector<uint8_t>& data) {
            chunk_visited = true; return data == raw;
        }, chunk_stats, chunk_error);
    assert(chunk_ok && chunk_error.empty() && chunk_visited);
    assert(chunk_stats.decoded_entries == 1 && chunk_stats.decode_failures == 0);

    std::cout << "VFS3 raw/zlib/zstd/chunked-raw parser tests: PASS\n";
    return 0;
}
