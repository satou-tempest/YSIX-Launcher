# Changelog

## v0.9.0 — startup compatibility and input diagnostics

- Adds an opt-in, launcher-controlled movie-source bypass for the specific Ys IX `movie::Extractor::SetDataSource` / `NnExtractor::SetDataSource` path implicated by the Galaxy A22 trace. The hook returns `-ENOSYS` before Android Stagefright attempts to sniff a stream that previously blocked in `NuCachedSource2::readAt`. The bypass is enabled by default for the startup test and may skip startup films or in-game cutscenes; this is not native video playback support.
- Adds an input trace mode that records Android touch/key events and changes in the guest pad state, allowing the next `nx.log` to distinguish visible controls from input actually delivered to the game.
- Rate-limits repeated unresolved-import logs to the first call per symbol. The missing `WorkBufferBase::inUse` TLS initializer remains unresolved; the change only prevents repeated messages from drowning out useful diagnostics.
- Keeps the v0.8 shader-miss capture, Ryujinx SPIR-V preparation, four-module NCE loader and provisional Switch overlay.
- Main-menu boot with responsive input remains unverified.

## v0.8.0 — shader preparation pipeline

- Captures missing Ys IX Maxwell shader blocks at runtime.
- Adds the Ryujinx/Ryubing ARM64 NativeAOT SPIR-V harness and launcher-side shader-cache preparation.
- Adds the initial in-game Switch touch overlay.

## Earlier versions

- v0.7: first NCE runtime bring-up attempt.
- v0.6: temporary native relocation validation.
- v0.5: NSO/MOD0 and module-link inspection.
- v0.4: NSP/ExeFS and Vulkan device probe.


## v1.0.0 — audio discovery diagnostics and FPS overlay
- Added a persistent Graphics setting for the in-game FPS counter. It writes `NX_SHOW_FPS` to the runtime config; the pinned generic runtime's present pass draws a two-digit last-second present rate at the top-left when enabled.
- Added opt-in-by-config audio renderer discovery tracing around the SDK object/vtable lookup that returned `impl 0` on the Galaxy A22. The trace reports candidate pointers and vtable values; it deliberately does not guess a replacement SDK offset or claim audio is fixed.
- Added AAudio initialization error reporting for later runs if a valid guest audio renderer is found and submits a mix.
- Preserved the v0.9 movie bypass, input tracing, four-module loader and shader capture behavior.

## v1.1.0 — game shader discovery, VFS3 decoding and Vulkan diagnostics
- Added game-image shader discovery for validated `HNSHV002` records in raw RomFS files, supported VFS3 v1 entries, and Maxwell shader blocks in the decompressed main ExeFS NSO.
- Added bounded VFS3 decoding for uncompressed, zlib, Zstandard, and NIS chunked-Zstandard files with optional dictionaries; oversized/invalid entries are reported as skips.
- Added the **PREPARE GAME SHADERS** progress screen and batch-translates supported package records plus uncached runtime-captured misses.
- Added valid SPIR-V module-header checks before treating a cache entry as prepared.
- Expanded Vulkan diagnostics with storage-image/compression features, GPU limits, and format support for common color, compressed, depth and storage formats.
- Redmi Turbo 4 is now the primary target; Galaxy A22 remains a secondary regression target.
- No claim that shader scanning is exhaustive, Mali glitches are fixed, gameplay performance is playable, or audio is restored.
