# No native runtime bindings are included in v0.3. Add keep rules when JNI interfaces are introduced.
