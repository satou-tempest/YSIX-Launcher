package io.github.ysix.launcher;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.FeatureInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.opengl.GLES20;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;
import javax.microedition.khronos.egl.EGLSurface;

/**
 * YS IX: Monstrum Nox — v0.8 experimental shader-preparation runtime integration.
 *
 * This release embeds a generic ARM64 NCE runtime and attempts to enter Ys IX's native Switch startup path.
 * Save ZIP import/export and DLC package staging remain separate from live in-game services.
 */
public final class MainActivity extends Activity {
    private static final int REQ_GAME = 301;
    private static final int REQ_KEYS = 302;
    private static final int REQ_TITLE_KEYS = 303;
    private static final int REQ_SAVE_IMPORT = 304;
    private static final int REQ_SAVE_EXPORT = 305;
    private static final int REQ_DLC = 306;
    private static final String PREFS = "ysix_launcher_v01"; // Preserve existing v0.1/v0.2 selections and preferences.
    private static final String VERSION = "0.8.0-shader-pipeline";

    private static final int BG = Color.rgb(9, 10, 14);
    private static final int BAR = Color.rgb(13, 14, 20);
    private static final int PANEL = Color.rgb(21, 22, 29);
    private static final int PANEL_ALT = Color.rgb(31, 31, 41);
    private static final int TEXT = Color.rgb(244, 240, 239);
    private static final int MUTED = Color.rgb(163, 160, 169);
    private static final int RED = Color.rgb(190, 49, 61);
    private static final int RED_DARK = Color.rgb(91, 25, 36);
    private static final int GOLD = Color.rgb(211, 174, 113);
    private static final int GREEN = Color.rgb(121, 185, 145);
    private static final int AMBER = Color.rgb(218, 164, 91);

    private SharedPreferences prefs;
    private LinearLayout pageHost;
    private String currentPage = "HOME";
    private String gpuRenderer = "Not reported";
    private String vulkanVersion = "Not reported by Android";
    private String gameName = "No game selected";
    private String keysName = "No prod.keys selected";
    private String titleKeysName = "Optional — not selected";
    private Uri gameUri;
    private Uri keysUri;
    private Uri titleKeysUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(BG);
        window.setNavigationBarColor(BG);
        window.getDecorView().setSystemUiVisibility(0);

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        gameName = prefs.getString("game_name", gameName);
        keysName = prefs.getString("keys_name", keysName);
        titleKeysName = prefs.getString("title_keys_name", titleKeysName);
        String savedGame = prefs.getString("game_uri", null);
        String savedKeys = prefs.getString("keys_uri", null);
        String savedTitleKeys = prefs.getString("title_keys_uri", null);
        if (savedGame != null) gameUri = Uri.parse(savedGame);
        if (savedKeys != null) keysUri = Uri.parse(savedKeys);
        if (savedTitleKeys != null) titleKeysUri = Uri.parse(savedTitleKeys);
        writeRuntimeTouchConfig(prefs.getBoolean("touch_controls", true));

        gpuRenderer = detectGlRenderer();
        vulkanVersion = detectVulkanVersion();
        applyDefaultsIfNeeded();
        renderApp();
    }

    private void renderApp() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        if (Build.VERSION.SDK_INT >= 35) {
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                view.setPadding(0, bars.top, 0, bars.bottom);
                return insets;
            });
        }

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setPadding(dp(16), dp(9), dp(16), dp(14));
        pageHost = new LinearLayout(this);
        pageHost.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(pageHost, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(buildNavigation(), new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
        renderPage();
    }

    private View buildNavigation() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER);
        bar.setPadding(dp(6), dp(7), dp(6), dp(8));
        bar.setBackgroundColor(BAR);
        String[][] tabs = {
                {"HOME", "⌂"}, {"LIBRARY", "▤"}, {"CONTENT", "⇄"}, {"GRAPHICS", "◈"},
                {"CONTROLS", "⌘"}, {"DIAGNOSTICS", "⌁"}
        };
        for (String[] tab : tabs) {
            boolean selected = currentPage.equals(tab[0]);
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER);
            item.setPadding(dp(2), dp(5), dp(2), dp(5));
            item.setBackground(selected ? rounded(RED_DARK, 12) : rounded(Color.TRANSPARENT, 12));
            TextView glyph = label(tab[1], 17, selected ? TEXT : MUTED);
            glyph.setGravity(Gravity.CENTER);
            TextView name = label(tab[0], 8, selected ? TEXT : MUTED);
            name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            name.setGravity(Gravity.CENTER);
            item.addView(glyph);
            item.addView(name);
            bar.addView(item, new LinearLayout.LayoutParams(0, dp(48), 1f));
            item.setOnClickListener(v -> {
                currentPage = tab[0];
                renderApp();
            });
        }
        return bar;
    }

    private void renderPage() {
        pageHost.removeAllViews();
        addHeader(pageHost);
        switch (currentPage) {
            case "LIBRARY": renderLibrary(pageHost); break;
            case "CONTENT": renderContent(pageHost); break;
            case "GRAPHICS": renderGraphics(pageHost); break;
            case "CONTROLS": renderControls(pageHost); break;
            case "DIAGNOSTICS": renderDiagnostics(pageHost); break;
            default: renderHome(pageHost); break;
        }
        TextView footer = label("UNOFFICIAL FAN PROJECT  •  VERSION " + VERSION.toUpperCase(Locale.ROOT), 8, MUTED);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(22), 0, dp(9));
        pageHost.addView(footer);
    }

    private void addHeader(LinearLayout host) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(2), 0, dp(13));

        ImageView emblem = new ImageView(this);
        emblem.setImageResource(R.drawable.ic_launcher_foreground);
        emblem.setScaleType(ImageView.ScaleType.FIT_CENTER);
        row.addView(emblem, new LinearLayout.LayoutParams(dp(45), dp(45)));

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        brand.setPadding(dp(8), 0, 0, 0);
        TextView name = label("YS IX", 20, TEXT);
        name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        TextView sub = label("MONSTRUM NOX  /  ANDROID", 8, MUTED);
        sub.setLetterSpacing(0.12f);
        brand.addView(name);
        brand.addView(sub);
        row.addView(brand, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView version = label("V0.8  •  SHADERS", 9, GOLD);
        version.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        version.setPadding(dp(10), dp(7), dp(10), dp(7));
        version.setBackground(rounded(Color.rgb(48, 37, 27), 18));
        row.addView(version);
        host.addView(row);
    }

    private void renderHome(LinearLayout host) {
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(18), dp(18), dp(18), dp(18));
        hero.setBackground(gradient(new int[]{Color.rgb(65, 20, 31), Color.rgb(31, 18, 27), Color.rgb(17, 18, 25)}, 20));
        TextView eyebrow = label("THE CITY IS WAITING", 9, GOLD);
        eyebrow.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        eyebrow.setLetterSpacing(0.18f);
        hero.addView(eyebrow);
        TextView title = label("MONSTRUM\nNOX", 31, TEXT);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setLineSpacing(0, 0.98f);
        title.setPadding(0, dp(7), 0, dp(5));
        hero.addView(title);
        hero.addView(label("A dedicated Android project for Ys IX: Monstrum Nox.", 12, Color.rgb(220, 207, 210)));
        TextView state = chip("EXPERIMENTAL NATIVE RUNTIME BUILD", GOLD);
        LinearLayout.LayoutParams stateLp = new LinearLayout.LayoutParams(-2, -2);
        stateLp.setMargins(0, dp(13), 0, 0);
        hero.addView(state, stateLp);
        host.addView(hero, matchWrap());

        addSection(host, "YOUR GAME", "Your local NSP/XCI and prod.keys are passed by file descriptor to native C++ for a real ExeFS/decryption test. Nothing is uploaded.");
        LinearLayout files = verticalCard();
        files.addView(fileSummary("GAME IMAGE", gameName, gameUri != null && hasReadAccess(gameUri) ? "ACCESS OK" : "NOT READY", () -> { currentPage = "LIBRARY"; renderApp(); }));
        addDivider(files);
        files.addView(fileSummary("PROD.KEYS", keysName, keysUri != null && hasReadAccess(keysUri) ? "ACCESS OK" : "NOT READY", () -> { currentPage = "LIBRARY"; renderApp(); }));
        addDivider(files);
        files.addView(fileSummary("TITLE.KEYS (OPTIONAL)", titleKeysName,
                titleKeysUri == null ? "OPTIONAL" : (hasReadAccess(titleKeysUri) ? "ACCESS OK" : "NOT READY"),
                () -> { currentPage = "LIBRARY"; renderApp(); }));
        host.addView(files, matchWrap());

        addSection(host, "NATIVE RUNTIME INTEGRATION", "v0.8 embeds the generic ARM64 native execution bridge, shader translator and Switch runtime as a separate NativeActivity. The boot button attempts the real game startup path; missing services or graphics support may stop it before the title screen.");
        LinearLayout runtime = verticalCard();
        runtime.addView(statusRow("Game file selection", gameUri != null ? "SELECTED" : "NEEDED", gameUri != null ? GREEN : AMBER));
        runtime.addView(statusRow("Key file selection", keysUri != null ? "SELECTED" : "NEEDED", keysUri != null ? GREEN : AMBER));
        runtime.addView(statusRow("ARM64 C++ / JNI library", "INTEGRATED", GREEN));
        runtime.addView(statusRow("NSP / XCI ExeFS probe", "INTEGRATED", GREEN));
        runtime.addView(statusRow("Vulkan device-init probe", "INTEGRATED", GREEN));
        runtime.addView(statusRow("MOD0 + dynamic metadata", "NATIVE AUDIT", GREEN));
        runtime.addView(statusRow("Native execution bridge (NCE)", "INTEGRATED · EXPERIMENTAL", GOLD));
        runtime.addView(statusRow("main / SDK / subsdk0 / subsdk1", "LOAD ATTEMPT ENABLED", GOLD));
        runtime.addView(statusRow("Switch services / movie HLE", "PARTIAL · LOG MISSING IMPORTS", AMBER));
        runtime.addView(statusRow("NVN renderer on Vulkan", "INTEGRATED · UNVERIFIED FOR YS IX", AMBER));
        runtime.addView(statusRow("Ys IX native boot", "EXPERIMENTAL ATTEMPT", GOLD));
        host.addView(runtime, matchWrap());

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button prepare = actionButton("RUN LOADER + GPU TEST", RED_DARK, TEXT);
        Button start = actionButton("TRY NATIVE BOOT", RED_DARK, TEXT);
        prepare.setOnClickListener(v -> runNativeProbe());
        start.setOnClickListener(v -> launchNativeRuntime());
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, dp(48), 1f);
        half.setMargins(0, dp(12), dp(5), 0);
        actions.addView(prepare, half);
        LinearLayout.LayoutParams half2 = new LinearLayout.LayoutParams(0, dp(48), 1f);
        half2.setMargins(dp(5), dp(12), 0, 0);
        actions.addView(start, half2);
        host.addView(actions);

        addSection(host, "SHADER PREPARATION", "Boot the native runtime once to record missing Ys IX shaders. Return here to translate the captured shaders into Vulkan SPIR-V, then boot again. New areas may reveal additional shader misses.");
        Button shaderPrepare = actionButton("PREPARE CAPTURED SHADERS", RED_DARK, TEXT);
        shaderPrepare.setOnClickListener(v -> prepareCapturedShaders());
        LinearLayout.LayoutParams shaderLp = matchWrap();
        shaderLp.setMargins(0, dp(4), 0, 0);
        host.addView(shaderPrepare, shaderLp);

        Button diagnostics = actionButton("OPEN DEVICE DIAGNOSTICS  ›", PANEL, TEXT);
        diagnostics.setOnClickListener(v -> { currentPage = "DIAGNOSTICS"; renderApp(); });
        LinearLayout.LayoutParams dlp = matchWrap();
        dlp.setMargins(0, dp(9), 0, 0);
        host.addView(diagnostics, dlp);

        Button logButton = actionButton("VIEW LAST NATIVE BOOT LOG  ›", PANEL_ALT, TEXT);
        logButton.setOnClickListener(v -> showLastNativeLog());
        LinearLayout.LayoutParams logLp = matchWrap();
        logLp.setMargins(0, dp(8), 0, 0);
        host.addView(logButton, logLp);

        TextView disclaimer = label("Experimental first native boot attempt. This may crash or return to Android before gameplay. It uses your selected NSP/XCI and keys locally through file descriptors; no game content is uploaded.", 10, MUTED);
        disclaimer.setPadding(dp(3), dp(13), dp(3), 0);
        host.addView(disclaimer);
    }

    private void renderLibrary(LinearLayout host) {
        addPageIntro(host, "GAME LIBRARY", "Select your own complete NSP/XCI and prod.keys. Native tests decrypt the package, validate the main/SDK images, inspect loader metadata and test safe relocations in temporary module mappings.");
        LinearLayout game = verticalCard();
        game.addView(filePickerBlock("GAME IMAGE", "NSP / XCI", gameName, "Choose the Ys IX game image from your device.", () -> chooseFile(REQ_GAME)));
        addDivider(game);
        game.addView(filePickerBlock("PROD.KEYS", "REQUIRED KEY FILE", keysName, "Choose prod.keys. The native importer reads it locally; key values are never included in its report.", () -> chooseFile(REQ_KEYS)));
        addDivider(game);
        game.addView(filePickerBlock("TITLE.KEYS", "OPTIONAL KEY FILE", titleKeysName, "Some NSP dumps also need title.keys. XCI dumps commonly work with prod.keys alone.", () -> chooseFile(REQ_TITLE_KEYS)));
        host.addView(game, matchWrap());

        addSection(host, "FILE ACCESS", "Saved Android document references are reopened and passed directly to native C++ during the test.");
        LinearLayout access = verticalCard();
        access.addView(infoRow("GAME REFERENCE", gameUri == null ? "Not selected" : "Saved"));
        access.addView(infoRow("GAME READ ACCESS", gameUri == null ? "Not checked" : (hasReadAccess(gameUri) ? "Available" : "Unavailable")));
        access.addView(infoRow("KEY REFERENCE", keysUri == null ? "Not selected" : "Saved"));
        access.addView(infoRow("PROD.KEYS READ ACCESS", keysUri == null ? "Not checked" : (hasReadAccess(keysUri) ? "Available" : "Unavailable")));
        access.addView(infoRow("TITLE.KEYS", titleKeysUri == null ? "Optional / not selected" : "Selected"));
        access.addView(infoRow("TITLE.KEYS READ ACCESS", titleKeysUri == null ? "Not required" : (hasReadAccess(titleKeysUri) ? "Available" : "Unavailable")));
        host.addView(access, matchWrap());

        Button recheck = actionButton("RECHECK FILE ACCESS", PANEL_ALT, TEXT);
        recheck.setOnClickListener(v -> {
            boolean gameOk = gameUri != null && hasReadAccess(gameUri);
            boolean keysOk = keysUri != null && hasReadAccess(keysUri);
            Toast.makeText(this, "Game: " + (gameOk ? "accessible" : "not accessible") + " · prod.keys: " + (keysOk ? "accessible" : "not accessible") + " · title.keys: " + (titleKeysUri == null ? "optional" : (hasReadAccess(titleKeysUri) ? "accessible" : "not accessible")), Toast.LENGTH_LONG).show();
            renderApp();
        });
        LinearLayout.LayoutParams rlp = matchWrap(); rlp.setMargins(0, dp(12), 0, 0);
        host.addView(recheck, rlp);

        Button clear = actionButton("CLEAR SELECTED FILE REFERENCES", PANEL, MUTED);
        clear.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Clear file references?")
                .setMessage("This removes the saved document selections from the launcher. It does not delete your game image or key file.")
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("CLEAR", (dialog, which) -> {
                    releasePersistedPermission(gameUri);
                    releasePersistedPermission(keysUri);
                    releasePersistedPermission(titleKeysUri);
                    gameUri = null; keysUri = null; titleKeysUri = null;
                    gameName = "No game selected"; keysName = "No prod.keys selected"; titleKeysName = "Optional — not selected";
                    prefs.edit().remove("game_uri").remove("keys_uri").remove("title_keys_uri")
                            .remove("game_name").remove("keys_name").remove("title_keys_name").apply();
                    renderApp();
                }).show());
        LinearLayout.LayoutParams clp = matchWrap(); clp.setMargins(0, dp(8), 0, 0);
        host.addView(clear, clp);
    }

    private void renderContent(LinearLayout host) {
        addPageIntro(host, "SAVE & DLC MANAGER", "Portable save archives and a local DLC package queue. The native game runtime does not yet produce or mount Ys IX saves/DLC; this page prepares and manages your own files without claiming they are live in-game.");

        addSection(host, "SAVE DATA", "Import/export ZIP archives to the YS IX save workspace. Existing same-name files are replaced on import; other files are kept.");
        LinearLayout saves = verticalCard();
        saves.addView(infoRow("SAVE WORKSPACE", saveRoot().getAbsolutePath()));
        saves.addView(statusRow("Game-generated saves", "WAITING FOR FILESYSTEM HLE", AMBER));
        Button importSave = actionButton("IMPORT SAVE ARCHIVE (.ZIP)", RED_DARK, TEXT);
        importSave.setOnClickListener(v -> chooseSaveImport());
        LinearLayout.LayoutParams saveLp = matchWrap(); saveLp.setMargins(0, dp(10), 0, 0);
        saves.addView(importSave, saveLp);
        Button exportSave = actionButton("EXPORT / BACK UP SAVE (.ZIP)", PANEL_ALT, TEXT);
        exportSave.setOnClickListener(v -> chooseSaveExport());
        LinearLayout.LayoutParams exportLp = matchWrap(); exportLp.setMargins(0, dp(8), 0, 0);
        saves.addView(exportSave, exportLp);
        Button clearSave = actionButton("CLEAR SAVE WORKSPACE", PANEL, MUTED);
        clearSave.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Clear local save workspace?")
                .setMessage("This permanently deletes files in the launcher's private Ys IX save workspace. Export a ZIP first if you want a backup.")
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("DELETE FILES", (d, w) -> clearSaveWorkspace())
                .show());
        LinearLayout.LayoutParams clearLp = matchWrap(); clearLp.setMargins(0, dp(8), 0, 0);
        saves.addView(clearSave, clearLp);
        host.addView(saves, matchWrap());

        addSection(host, "DLC PACKAGE QUEUE", "Add your own DLC/update NSP or XCI files to the local queue. The queue stores document references only; title-ID matching, package extraction, content mounting and activation are not implemented yet.");
        LinearLayout dlc = verticalCard();
        List<String> refs = getDlcRefs();
        dlc.addView(statusRow("Packages staged", String.valueOf(refs.size()), refs.isEmpty() ? MUTED : GOLD));
        if (refs.isEmpty()) {
            dlc.addView(label("No DLC packages added.", 11, MUTED));
        } else {
            for (int i = 0; i < refs.size(); i++) {
                Uri u = Uri.parse(refs.get(i));
                String name = queryDisplayName(u);
                dlc.addView(infoRow("STAGED · NOT INSTALLED", name));
            }
        }
        Button addDlc = actionButton("ADD DLC / UPDATE PACKAGE TO QUEUE (.NSP / .XCI)", RED_DARK, TEXT);
        addDlc.setOnClickListener(v -> chooseDlcPackage());
        LinearLayout.LayoutParams addLp = matchWrap(); addLp.setMargins(0, dp(10), 0, 0);
        dlc.addView(addDlc, addLp);
        Button clearDlc = actionButton("REMOVE ALL STAGED DLC REFERENCES", PANEL, MUTED);
        clearDlc.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Remove staged DLC references?")
                .setMessage("Only the launcher's saved references are removed. Your NSP/XCI files remain untouched.")
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("REMOVE", (d, w) -> {
                    for (String ref : getDlcRefs()) releasePersistedPermission(Uri.parse(ref));
                    saveDlcRefs(new ArrayList<>());
                    renderApp();
                }).show());
        LinearLayout.LayoutParams removeLp = matchWrap(); removeLp.setMargins(0, dp(8), 0, 0);
        dlc.addView(clearDlc, removeLp);
        host.addView(dlc, matchWrap());

        LinearLayout note = verticalCard();
        note.addView(label("IMPORTANT", 9, GOLD));
        note.addView(label("Save archives can be imported/exported now, but until the Switch filesystem/save services are implemented the game cannot create or load these as live Ys IX saves. DLC packages are queued only; this version does not decrypt, install, activate or mount them.", 10, MUTED));
        LinearLayout.LayoutParams noteLp = matchWrap(); noteLp.setMargins(0, dp(10), 0, 0);
        host.addView(note, noteLp);
    }

    private void renderGraphics(LinearLayout host) {
        addPageIntro(host, "GRAPHICS", "Saved preferences for future runtime integration. These values do not currently affect Ys IX rendering.");
        LinearLayout profile = verticalCard();
        profile.addView(label("DETECTED GPU PROFILE", 9, GOLD));
        TextView profileName = label(getSuggestedProfile(), 19, TEXT);
        profileName.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        profileName.setPadding(0, dp(5), 0, dp(3));
        profile.addView(profileName);
        profile.addView(label(gpuRenderer, 10, MUTED));
        host.addView(profile, matchWrap());

        LinearLayout settings = verticalCard();
        settings.addView(label("RENDER SCALE", 9, GOLD));
        Spinner scale = spinner(new String[]{"0.5x", "0.75x", "1.0x", "1.25x"}, prefs.getString("scale", suggestedScale()));
        settings.addView(scale, new LinearLayout.LayoutParams(-1, dp(47)));
        scale.setOnItemSelectedListener(simpleSelection(() -> prefs.edit().putString("scale", scale.getSelectedItem().toString()).apply()));
        settings.addView(label("FRAME-RATE TARGET", 9, GOLD));
        Spinner fps = spinner(new String[]{"30 FPS", "60 FPS (experimental)"}, prefs.getString("fps", "30 FPS"));
        settings.addView(fps, new LinearLayout.LayoutParams(-1, dp(47)));
        fps.setOnItemSelectedListener(simpleSelection(() -> prefs.edit().putString("fps", fps.getSelectedItem().toString()).apply()));
        CheckBox shader = checkBox("Shader cache preference", prefs.getBoolean("shader_cache", true));
        CheckBox vsync = checkBox("VSync preference", prefs.getBoolean("vsync", true));
        CheckBox overlay = checkBox("Performance overlay preference", prefs.getBoolean("overlay", true));
        settings.addView(shader); settings.addView(vsync); settings.addView(overlay);
        shader.setOnCheckedChangeListener((b, checked) -> prefs.edit().putBoolean("shader_cache", checked).apply());
        vsync.setOnCheckedChangeListener((b, checked) -> prefs.edit().putBoolean("vsync", checked).apply());
        overlay.setOnCheckedChangeListener((b, checked) -> prefs.edit().putBoolean("overlay", checked).apply());
        host.addView(settings, matchWrap());

        Button reset = actionButton("RESTORE DEVICE SUGGESTIONS", PANEL_ALT, TEXT);
        reset.setOnClickListener(v -> {
            prefs.edit().putString("scale", suggestedScale()).putString("fps", "30 FPS")
                    .putBoolean("shader_cache", true).putBoolean("vsync", true).putBoolean("overlay", true).apply();
            renderApp();
            Toast.makeText(this, "Suggested preferences restored", Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams lp = matchWrap(); lp.setMargins(0, dp(12), 0, 0);
        host.addView(reset, lp);
    }

    private void renderControls(LinearLayout host) {
        addPageIntro(host, "CONTROLS", "The native runtime now draws a provisional Switch touch layout and forwards taps and stick movement to the game input bridge.");
        LinearLayout preview = verticalCard();
        preview.addView(label("TOUCH LAYOUT CONCEPT", 9, GOLD));
        LinearLayout stage = new LinearLayout(this);
        stage.setOrientation(LinearLayout.HORIZONTAL);
        stage.setGravity(Gravity.CENTER_VERTICAL);
        stage.setPadding(0, dp(17), 0, dp(17));
        TextView stick = label("◀    ▲\n▼    ▶", 16, TEXT);
        stick.setGravity(Gravity.CENTER);
        stick.setBackground(rounded(Color.rgb(47, 48, 58), 50));
        stage.addView(stick, new LinearLayout.LayoutParams(dp(105), dp(91)));
        View gap = new View(this);
        stage.addView(gap, new LinearLayout.LayoutParams(0, 1, 1f));
        TextView buttons = label("Y     X\nB     A", 16, TEXT);
        buttons.setGravity(Gravity.CENTER);
        buttons.setBackground(rounded(RED_DARK, 50));
        stage.addView(buttons, new LinearLayout.LayoutParams(dp(105), dp(91)));
        preview.addView(stage);
        preview.addView(label("Illustrative layout preview. The live in-game positions are currently fixed and will be adjusted after device testing.", 10, MUTED));
        host.addView(preview, matchWrap());

        LinearLayout options = verticalCard();
        CheckBox show = checkBox("Show touch controls by default", prefs.getBoolean("touch_controls", true));
        CheckBox haptics = checkBox("Haptic feedback preference (not yet connected)", prefs.getBoolean("haptics", false));
        options.addView(show); options.addView(haptics);
        show.setOnCheckedChangeListener((b, checked) -> {
            prefs.edit().putBoolean("touch_controls", checked).apply();
            writeRuntimeTouchConfig(checked);
        });
        haptics.setOnCheckedChangeListener((b, checked) -> prefs.edit().putBoolean("haptics", checked).apply());
        host.addView(options, matchWrap());
    }

    private void writeRuntimeTouchConfig(boolean enabled) {
        File base = getExternalFilesDir(null);
        if (base == null) return;
        if (!base.exists() && !base.mkdirs()) return;
        File config = new File(base, "config.txt");
        ArrayList<String> lines = new ArrayList<>();
        if (config.isFile()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(config))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (!line.startsWith("NX_TOUCH_SHOW=")) lines.add(line);
                }
            } catch (IOException ignored) {
                return;
            }
        }
        lines.add("NX_TOUCH_SHOW=" + (enabled ? "1" : "0"));
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(config, false))) {
            for (String line : lines) {
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException ignored) {
            // The runtime defaults to showing touch controls when no setting is available.
        }
    }

    private void renderDiagnostics(LinearLayout host) {
        addPageIntro(host, "DEVICE DIAGNOSTICS", "Run the native test to record actual Vulkan loader/device/queue results from this phone. Feature declarations alone are not proof of rendering compatibility.");
        LinearLayout device = verticalCard();
        device.addView(infoRow("DEVICE", Build.MANUFACTURER + " " + Build.MODEL));
        device.addView(infoRow("CODENAME", Build.DEVICE));
        device.addView(infoRow("ANDROID", Build.VERSION.RELEASE + " / API " + Build.VERSION.SDK_INT));
        device.addView(infoRow("SUPPORTED ABIS", join(Build.SUPPORTED_ABIS)));
        device.addView(infoRow("OPENGL RENDERER", gpuRenderer));
        device.addView(infoRow("VULKAN FEATURE", vulkanVersion));
        device.addView(infoRow("TOTAL RAM", formatRam()));
        device.addView(infoRow("APP VERSION", VERSION));
        host.addView(device, matchWrap());

        addSection(host, "RUNTIME COMPONENTS", "These are explicit integration gates, not inferred hardware capabilities.");
        LinearLayout runtime = verticalCard();
        runtime.addView(statusRow("Native ARM64 JNI library", "BUILD TARGET", GREEN));
        runtime.addView(statusRow("NSP / XCI + key decryption", "NATIVE TEST", GOLD));
        runtime.addView(statusRow("NSO main / SDK integrity", "NATIVE TEST", GOLD));
        runtime.addView(statusRow("Vulkan device + graphics queue", "NATIVE TEST", GOLD));
        runtime.addView(statusRow("MOD0 + relocation preflight", "v0.8 NATIVE TEST", GOLD));
        runtime.addView(statusRow("Relocation / Horizon services", "RUNTIME INTEGRATED · UNVERIFIED", GOLD));
        runtime.addView(statusRow("NVN / Maxwell shader pipeline", "RUNTIME INTEGRATED · UNVERIFIED", GOLD));
        runtime.addView(statusRow("Mali game rendering", "NOT VALIDATED", AMBER));
        host.addView(runtime, matchWrap());

        Button probe = actionButton("RUN EXEFS / LOADER / VULKAN TEST", RED_DARK, TEXT);
        probe.setOnClickListener(v -> runNativeProbe());
        LinearLayout.LayoutParams probeLp = matchWrap(); probeLp.setMargins(0, dp(12), 0, 0);
        host.addView(probe, probeLp);

        Button refresh = actionButton("REFRESH DEVICE QUERIES", PANEL_ALT, TEXT);
        refresh.setOnClickListener(v -> {
            gpuRenderer = detectGlRenderer();
            vulkanVersion = detectVulkanVersion();
            renderApp();
            Toast.makeText(this, "Device information refreshed", Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams lp = matchWrap(); lp.setMargins(0, dp(12), 0, 0);
        host.addView(refresh, lp);

        LinearLayout privacy = verticalCard();
        privacy.addView(label("LOCAL DATA / PRIVACY", 9, GOLD));
        privacy.addView(label("The native probe reads your selected game image and prod.keys through local file descriptors. It does not upload either file or log key material. No networking, camera, microphone, contacts, or location permission is declared.", 11, MUTED));
        LinearLayout.LayoutParams pp = matchWrap(); pp.setMargins(0, dp(10), 0, 0);
        host.addView(privacy, pp);
    }

    private View fileSummary(String title, String value, String status, Runnable click) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        TextView heading = label(title, 8, GOLD);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        TextView file = label(value, 11, TEXT);
        file.setMaxLines(1);
        file.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        left.addView(heading); left.addView(file);
        row.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView badge = chip(status, status.equals("ACCESS OK") ? GREEN : AMBER);
        row.addView(badge);
        row.setPadding(0, dp(5), 0, dp(5));
        row.setOnClickListener(v -> click.run());
        return row;
    }

    private View filePickerBlock(String title, String tag, String value, String description, Runnable click) {
        LinearLayout block = new LinearLayout(this);
        block.setOrientation(LinearLayout.VERTICAL);
        TextView top = label(title + "  /  " + tag, 9, GOLD);
        top.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        block.addView(top);
        TextView file = label(value, 14, TEXT);
        file.setPadding(0, dp(5), 0, dp(4));
        file.setMaxLines(2);
        file.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        block.addView(file);
        block.addView(label(description, 10, MUTED));
        Button choose = actionButton("CHOOSE FILE  ›", RED_DARK, TEXT);
        choose.setOnClickListener(v -> click.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(42));
        lp.setMargins(0, dp(10), 0, 0);
        block.addView(choose, lp);
        return block;
    }

    private View statusRow(String title, String value, int color) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(5), 0, dp(5));
        TextView left = label(title, 10, MUTED);
        TextView right = label(value, 8, color);
        right.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        right.setGravity(Gravity.END);
        row.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(right, new LinearLayout.LayoutParams(-2, -2));
        return row;
    }

    private void addPageIntro(LinearLayout host, String title, String desc) {
        TextView t = label(title, 20, TEXT);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(0, dp(6), 0, dp(5));
        host.addView(t);
        TextView d = label(desc, 11, MUTED);
        d.setLineSpacing(dp(2), 1f);
        d.setPadding(0, 0, 0, dp(14));
        host.addView(d);
    }

    private void addSection(LinearLayout host, String title, String subtitle) {
        TextView t = label(title, 9, GOLD);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setLetterSpacing(0.13f);
        t.setPadding(dp(2), dp(17), 0, dp(4));
        host.addView(t);
        TextView s = label(subtitle, 10, MUTED);
        s.setLineSpacing(dp(1), 1f);
        s.setPadding(dp(2), 0, 0, dp(8));
        host.addView(s);
    }

    private LinearLayout verticalCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        card.setBackground(rounded(PANEL, 16));
        return card;
    }

    private TextView chip(String text, int color) {
        TextView view = label(text, 8, color);
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setLetterSpacing(0.04f);
        view.setPadding(dp(9), dp(7), dp(9), dp(7));
        view.setBackground(rounded(Color.argb(35, Color.red(color), Color.green(color), Color.blue(color)), 18));
        return view;
    }

    private View infoRow(String key, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(6), 0, dp(6));
        TextView left = label(key, 8, MUTED);
        left.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        TextView right = label(value, 10, TEXT);
        right.setGravity(Gravity.END);
        right.setMaxWidth(dp(205));
        right.setMaxLines(3);
        row.addView(left, new LinearLayout.LayoutParams(0, -2, 0.8f));
        row.addView(right, new LinearLayout.LayoutParams(0, -2, 1.2f));
        return row;
    }

    private void addDivider(LinearLayout host) {
        View line = new View(this);
        line.setBackgroundColor(Color.rgb(48, 48, 59));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
        lp.setMargins(0, dp(8), 0, dp(8));
        host.addView(line, lp);
    }

    private TextView label(String text, int size, int color) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setIncludeFontPadding(true);
        return view;
    }

    private Button actionButton(String text, int background, int foreground) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(9);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setTextColor(foreground);
        button.setAllCaps(false);
        button.setMinHeight(dp(42));
        button.setPadding(dp(8), 0, dp(8), 0);
        button.setBackground(rounded(background, 11));
        return button;
    }

    private CheckBox checkBox(String text, boolean checked) {
        CheckBox box = new CheckBox(this);
        box.setText(text);
        box.setTextColor(TEXT);
        box.setTextSize(11);
        box.setButtonTintList(ColorStateList.valueOf(RED));
        box.setChecked(checked);
        return box;
    }

    private Spinner spinner(String[] choices, String selected) {
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, choices) {
            @Override public View getView(int position, View convertView, ViewGroup parent) {
                TextView view = (TextView) super.getView(position, convertView, parent);
                view.setTextColor(TEXT); view.setTextSize(12); view.setPadding(dp(8), dp(4), dp(8), dp(4));
                return view;
            }
            @Override public View getDropDownView(int position, View convertView, ViewGroup parent) {
                TextView view = (TextView) super.getDropDownView(position, convertView, parent);
                view.setTextColor(TEXT); view.setTextSize(12); view.setBackgroundColor(PANEL_ALT);
                view.setPadding(dp(12), dp(12), dp(12), dp(12));
                return view;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setBackground(rounded(PANEL_ALT, 10));
        int index = 0;
        for (int i = 0; i < choices.length; i++) if (choices[i].equals(selected)) index = i;
        spinner.setSelection(index);
        return spinner;
    }

    private AdapterView.OnItemSelectedListener simpleSelection(Runnable action) {
        return new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { action.run(); }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        };
    }

    private void chooseFile(int requestCode) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(intent, requestCode);
        } catch (Exception e) {
            Toast.makeText(this, "No Android document picker is available", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        Uri uri = data.getData();
        if (requestCode == REQ_SAVE_IMPORT) {
            if (uri == null) return;
            if (!queryDisplayName(uri).toLowerCase(Locale.ROOT).endsWith(".zip")) {
                showRuntimeNotice("Choose a ZIP save archive."); return;
            }
            persistReadPermission(uri, data.getFlags());
            importSaveArchive(uri);
            return;
        }
        if (requestCode == REQ_SAVE_EXPORT) {
            if (uri == null) return;
            exportSaveArchive(uri);
            return;
        }
        if (requestCode == REQ_DLC) {
            ArrayList<Uri> picked = new ArrayList<>();
            if (data.getClipData() != null) {
                for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                    Uri item = data.getClipData().getItemAt(i).getUri();
                    if (item != null) picked.add(item);
                }
            } else if (uri != null) picked.add(uri);
            ArrayList<String> refs = new ArrayList<>(getDlcRefs());
            int added = 0;
            for (Uri item : picked) {
                String name = queryDisplayName(item).toLowerCase(Locale.ROOT);
                if (!(name.endsWith(".nsp") || name.endsWith(".xci"))) continue;
                persistReadPermission(item, data.getFlags());
                if (!refs.contains(item.toString())) { refs.add(item.toString()); added++; }
            }
            if (added == 0) {
                showRuntimeNotice("No new .nsp/.xci DLC package was added. Make sure you selected a supported file.");
            } else {
                saveDlcRefs(refs);
                Toast.makeText(this, added + " DLC package reference(s) staged. Not installed or mounted yet.", Toast.LENGTH_LONG).show();
            }
            currentPage = "CONTENT"; renderApp();
            return;
        }
        if (uri == null) return;
        String displayName = queryDisplayName(uri);
        String lower = displayName.toLowerCase(Locale.ROOT);

        if (requestCode == REQ_GAME) {
            if (!(lower.endsWith(".nsp") || lower.endsWith(".xci"))) {
                showRuntimeNotice("Choose a file with an .nsp or .xci extension. The native probe supports a complete NSP/XCI image, not split XCI parts.");
                return;
            }
            persistReadPermission(uri, data.getFlags());
            gameUri = uri; gameName = displayName;
            prefs.edit().putString("game_uri", uri.toString()).putString("game_name", displayName).apply();
        } else if (requestCode == REQ_KEYS) {
            if (!lower.equals("prod.keys")) { showRuntimeNotice("Choose the file named prod.keys for the required key file."); return; }
            persistReadPermission(uri, data.getFlags());
            keysUri = uri; keysName = displayName;
            prefs.edit().putString("keys_uri", uri.toString()).putString("keys_name", displayName).apply();
        } else if (requestCode == REQ_TITLE_KEYS) {
            if (!lower.equals("title.keys")) { showRuntimeNotice("Choose the optional file named title.keys."); return; }
            persistReadPermission(uri, data.getFlags());
            titleKeysUri = uri; titleKeysName = displayName;
            prefs.edit().putString("title_keys_uri", uri.toString()).putString("title_keys_name", displayName).apply();
        } else return;

        currentPage = "LIBRARY"; renderApp();
        boolean readable = hasReadAccess(uri);
        Toast.makeText(this, readable ? "Document reference saved · read access confirmed" : "Reference saved · Android could not confirm read access", Toast.LENGTH_LONG).show();
    }

    private void launchNativeRuntime() {
        if (gameUri == null || keysUri == null || !hasReadAccess(gameUri) || !hasReadAccess(keysUri)) {
            showRuntimeNotice("Select a readable complete Ys IX NSP/XCI and prod.keys in Library first. title.keys is optional.");
            currentPage = "LIBRARY"; renderApp(); return;
        }
        new AlertDialog.Builder(this)
                .setTitle("YS IX · EXPERIMENTAL NATIVE BOOT")
                .setMessage("This is the first real runtime boot attempt, not a playable release. It loads the native ARM64 game modules and enters the Switch runtime startup path. Missing imports, Switch services, title-specific movie/video functions or NVN shader issues may stop startup, hang, or return you to the launcher. The game runtime runs in a separate Android process. Save data and DLC are not connected to the game runtime yet.\n\nYour NSP/XCI and key files are opened locally through Android file descriptors; they are not copied or uploaded.")
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("ATTEMPT BOOT", (dialog, which) -> {
                    Intent intent = new Intent(this, GameActivity.class);
                    intent.putExtra("ysix.game_uri", gameUri.toString());
                    intent.putExtra("ysix.game_name", gameName);
                    intent.putExtra("ysix.keys_uri", keysUri.toString());
                    if (titleKeysUri != null) intent.putExtra("ysix.title_keys_uri", titleKeysUri.toString());
                    ClipData grants = ClipData.newUri(getContentResolver(), "YS IX game image", gameUri);
                    grants.addItem(new ClipData.Item(keysUri));
                    if (titleKeysUri != null) grants.addItem(new ClipData.Item(titleKeysUri));
                    intent.setClipData(grants);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    try { startActivity(intent); }
                    catch (Exception e) { showRuntimeNotice("Could not start the native runtime: " + e.getMessage()); }
                }).show();
    }

    private void prepareCapturedShaders() {
        File dataRoot = getExternalFilesDir(null);
        if (dataRoot == null) {
            showRuntimeNotice("Android did not provide the app's external files folder.");
            return;
        }
        File misses = new File(dataRoot, "shader_misses");
        File[] captures = misses.listFiles((dir, name) -> name.startsWith("code_") && name.endsWith(".bin"));
        if (captures == null || captures.length == 0) {
            showRuntimeNotice("No shader captures found yet.\n\nFirst press TRY NATIVE BOOT, let the black-screen attempt run until it stalls, then return to the launcher and choose PREPARE CAPTURED SHADERS.");
            return;
        }

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(20), dp(12), dp(20), dp(6));
        TextView status = label("Preparing " + captures.length + " captured shader block(s)…", 11, TEXT);
        content.addView(status);
        ProgressBar bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        bar.setProgress(0);
        LinearLayout.LayoutParams barLp = matchWrap();
        barLp.setMargins(0, dp(14), 0, dp(8));
        content.addView(bar, barLp);

        AlertDialog progress = new AlertDialog.Builder(this)
                .setTitle("YS IX · SHADER TRANSLATION")
                .setView(content)
                .setCancelable(false)
                .create();
        progress.show();

        Handler handler = new Handler(Looper.getMainLooper());
        final String[] report = new String[1];
        final boolean[] finished = new boolean[1];
        final boolean[] shown = new boolean[1];

        Runnable update = new Runnable() {
            @Override public void run() {
                int[] values = NativeProbe.shaderProgress();
                if (values != null && values.length >= 2 && values[1] > 0) {
                    int done = Math.max(0, values[0]);
                    int total = Math.max(1, values[1]);
                    bar.setProgress(Math.min(100, done * 100 / total));
                    status.setText("Translating shaders: " + done + " / " + total);
                } else {
                    status.setText("Starting the native shader translator…");
                }
                if (finished[0] && !shown[0]) {
                    shown[0] = true;
                    handler.removeCallbacks(this);
                    progress.dismiss();
                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("YS IX · SHADER PREPARATION RESULT")
                            .setMessage(report[0] == null ? "Shader preparation ended without a report." : report[0])
                            .setPositiveButton("CLOSE", null)
                            .show();
                } else if (!finished[0]) {
                    handler.postDelayed(this, 500);
                }
            }
        };

        Thread worker = new Thread(() -> {
            try {
                // Two workers are intentionally used on the Galaxy A22 5G to limit RAM and thermal pressure.
                report[0] = NativeProbe.prepareShaders(dataRoot.getAbsolutePath(), 2);
            } catch (Throwable e) {
                report[0] = "Shader preparation failed: " + e.getClass().getSimpleName() + ": " + e.getMessage();
            } finally {
                finished[0] = true;
                handler.post(update);
            }
        }, "ysix-shader-prepare");
        worker.start();
        handler.post(update);
    }

    private void showLastNativeLog() {
        File base = getExternalFilesDir(null);
        File log = base == null ? null : new File(base, "nx.log");
        if (log == null || !log.isFile()) {
            showRuntimeNotice("No native boot log exists yet. Run TRY NATIVE BOOT first.");
            return;
        }
        try (RandomAccessFile in = new RandomAccessFile(log, "r")) {
            long length = in.length();
            long start = Math.max(0, length - 1024L * 1024L);
            in.seek(start);
            byte[] bytes = new byte[(int)(length - start)];
            in.readFully(bytes);
            String text = bytes.length > 0 ? new String(bytes, "UTF-8") : "(empty log)";
            TextView body = label(text, 9, TEXT);
            body.setTypeface(Typeface.MONOSPACE);
            body.setTextIsSelectable(true);
            body.setPadding(dp(12), dp(12), dp(12), dp(12));
            ScrollView scroll = new ScrollView(this);
            scroll.setBackground(rounded(PANEL, 12));
            scroll.addView(body, new ScrollView.LayoutParams(-1, -2));
            new AlertDialog.Builder(this).setTitle("LAST NATIVE BOOT LOG")
                    .setView(scroll).setPositiveButton("CLOSE", null).show();
        } catch (Exception e) {
            showRuntimeNotice("Could not read the native log: " + e.getMessage());
        }
    }

    private void runNativeProbe() {
        if (gameUri == null || keysUri == null) {
            showRuntimeNotice("Select a complete Ys IX .nsp or .xci and your own prod.keys first. title.keys is optional for NSP dumps that need it.");
            currentPage = "LIBRARY";
            renderApp();
            return;
        }
        AlertDialog progress = new AlertDialog.Builder(this)
                .setTitle("YS IX · PRE-BOOT DIAGNOSTIC")
                .setMessage("Opening the local game image, staging main/SDK together, applying safely resolved relocations to temporary memory and initializing Vulkan. Keep the app open…")
                .setCancelable(false)
                .create();
        progress.show();

        final Uri selectedGame = gameUri;
        final Uri selectedKeys = keysUri;
        final Uri selectedTitleKeys = titleKeysUri;
        final String selectedName = gameName;
        Thread worker = new Thread(() -> {
            String report;
            try (ParcelFileDescriptor game = getContentResolver().openFileDescriptor(selectedGame, "r");
                 ParcelFileDescriptor keys = getContentResolver().openFileDescriptor(selectedKeys, "r");
                 ParcelFileDescriptor titleKeys = selectedTitleKeys == null ? null :
                         getContentResolver().openFileDescriptor(selectedTitleKeys, "r")) {
                if (game == null) throw new IllegalStateException("Android could not open the selected game image.");
                if (keys == null) throw new IllegalStateException("Android could not open prod.keys.");
                if (selectedTitleKeys != null && titleKeys == null)
                    throw new IllegalStateException("Android could not open title.keys.");
                report = NativeProbe.inspect(game.getFd(), selectedName, keys.getFd(),
                        titleKeys == null ? -1 : titleKeys.getFd());
            } catch (Throwable error) {
                report = "YS IX v0.8 pre-boot diagnostic could not start.\n"
                        + error.getClass().getSimpleName() + ": " + String.valueOf(error.getMessage())
                        + "\n\nCheck that the game image is a complete, readable NSP/XCI and the key file is prod.keys.";
            }
            final String finalReport = report;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                progress.dismiss();
                TextView body = label(finalReport, 10, TEXT);
                body.setTypeface(Typeface.MONOSPACE);
                body.setTextIsSelectable(true);
                body.setPadding(dp(14), dp(12), dp(14), dp(12));
                ScrollView scroll = new ScrollView(this);
                scroll.setBackground(rounded(PANEL, 12));
                scroll.addView(body, new ScrollView.LayoutParams(-1, -2));
                new AlertDialog.Builder(this)
                        .setTitle("YS IX · NATIVE LOADER REPORT")
                        .setView(scroll)
                        .setPositiveButton("CLOSE", null)
                        .show();
            });
        }, "ysix-native-probe");
        worker.start();
    }

    private File saveRoot() {
        File root = new File(getFilesDir(), "ysix/save");
        if (!root.exists()) root.mkdirs();
        return root;
    }

    private void chooseSaveImport() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/zip");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, REQ_SAVE_IMPORT);
    }

    private void chooseSaveExport() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/zip");
        i.putExtra(Intent.EXTRA_TITLE, "ysix-save-" + new SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(new Date()) + ".zip");
        i.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        startActivityForResult(i, REQ_SAVE_EXPORT);
    }

    private void chooseDlcPackage() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(i, REQ_DLC);
    }

    private List<String> getDlcRefs() {
        ArrayList<String> result = new ArrayList<>();
        String raw = prefs.getString("dlc_refs", "");
        if (raw == null || raw.isEmpty()) return result;
        for (String item : raw.split("\n")) if (!item.trim().isEmpty() && !result.contains(item)) result.add(item);
        return result;
    }

    private void saveDlcRefs(List<String> refs) {
        StringBuilder b = new StringBuilder();
        for (String ref : refs) { if (b.length() > 0) b.append('\n'); b.append(ref); }
        prefs.edit().putString("dlc_refs", b.toString()).apply();
    }

    private void importSaveArchive(Uri archive) {
        AlertDialog progress = new AlertDialog.Builder(this).setTitle("IMPORT SAVE ARCHIVE")
                .setMessage("Checking the ZIP and importing files into the private save workspace…")
                .setCancelable(false).create();
        progress.show();
        new Thread(() -> {
            String result;
            File temp = new File(getCacheDir(), "ysix-save-import-" + System.nanoTime());
            try {
                extractSaveZip(archive, temp);
                mergeSaveTree(temp, saveRoot());
                deleteTree(temp);
                result = "Save archive imported into the YS IX workspace. The game runtime still needs filesystem/save HLE before it can load these files in-game.";
            } catch (Exception e) {
                deleteTree(temp);
                result = "Save import failed: " + e.getMessage();
            }
            final String message = result;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                progress.dismiss();
                new AlertDialog.Builder(this).setTitle("SAVE IMPORT").setMessage(message).setPositiveButton("OK", null).show();
                renderApp();
            });
        }, "ysix-save-import").start();
    }

    private void extractSaveZip(Uri archive, File temp) throws Exception {
        if (!temp.mkdirs() && !temp.isDirectory()) throw new IOException("cannot create temporary workspace");
        long total = 0; int entries = 0;
        InputStream raw = getContentResolver().openInputStream(archive);
        if (raw == null) throw new IOException("Android could not open the selected ZIP");
        try (ZipInputStream zin = new ZipInputStream(new BufferedInputStream(raw))) {
            ZipEntry entry;
            byte[] buffer = new byte[64 * 1024];
            String rootPath = temp.getCanonicalPath() + File.separator;
            while ((entry = zin.getNextEntry()) != null) {
                if (++entries > 50000) throw new IOException("archive contains too many entries");
                String name = entry.getName().replace('\\', '/');
                if (name.isEmpty() || name.startsWith("/") || name.contains(":") || name.indexOf('\0') >= 0)
                    throw new IOException("unsafe archive entry name");
                String[] parts = name.split("/");
                for (String part : parts) if (part.equals("..") || part.equals(".")) throw new IOException("unsafe archive path");
                File target = new File(temp, name);
                String canonical = target.getCanonicalPath();
                if (!canonical.startsWith(rootPath)) throw new IOException("archive entry escaped the workspace");
                if (entry.isDirectory()) {
                    if (!target.mkdirs() && !target.isDirectory()) throw new IOException("cannot create archive folder");
                } else {
                    File parent = target.getParentFile();
                    if (parent != null && !parent.mkdirs() && !parent.isDirectory()) throw new IOException("cannot create destination folder");
                    try (OutputStream out = new BufferedOutputStream(new FileOutputStream(target))) {
                        int n;
                        while ((n = zin.read(buffer)) != -1) {
                            total += n;
                            if (total > (1024L * 1024L * 1024L)) throw new IOException("archive expands beyond 1 GiB safety limit");
                            out.write(buffer, 0, n);
                        }
                    }
                }
                zin.closeEntry();
            }
        }
        if (entries == 0) throw new IOException("ZIP archive is empty or invalid");
    }

    private void mergeSaveTree(File from, File to) throws IOException {
        if (!to.exists() && !to.mkdirs()) throw new IOException("cannot create save workspace");
        File[] children = from.listFiles();
        if (children == null) return;
        for (File child : children) {
            File target = new File(to, child.getName());
            if (child.isDirectory()) mergeSaveTree(child, target);
            else {
                File parent = target.getParentFile();
                if (parent != null && !parent.mkdirs() && !parent.isDirectory()) throw new IOException("cannot create save folder");
                try (InputStream in = new BufferedInputStream(new FileInputStream(child));
                     OutputStream out = new BufferedOutputStream(new FileOutputStream(target))) {
                    byte[] buf = new byte[64 * 1024]; int n;
                    while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                }
            }
        }
    }

    private void exportSaveArchive(Uri destination) {
        AlertDialog progress = new AlertDialog.Builder(this).setTitle("EXPORT SAVE ARCHIVE")
                .setMessage("Creating a ZIP backup of the local YS IX save workspace…")
                .setCancelable(false).create();
        progress.show();
        new Thread(() -> {
            String result;
            try (OutputStream raw = getContentResolver().openOutputStream(destination)) {
                if (raw == null) throw new IOException("Android could not create the destination file");
                try (ZipOutputStream zout = new ZipOutputStream(new BufferedOutputStream(raw))) {
                    File root = saveRoot();
                    File[] files = root.listFiles();
                    if (files != null) for (File f : files) addToZip(root, f, zout);
                    if (files == null || files.length == 0) {
                        ZipEntry note = new ZipEntry("README.txt"); zout.putNextEntry(note);
                        zout.write("YS IX save workspace export. The native game runtime is not yet generating in-game saves.\n".getBytes("UTF-8"));
                        zout.closeEntry();
                    }
                }
                result = "Save archive exported. Keep this ZIP somewhere safe. The archive contains files from the launcher workspace, not game-generated saves unless the runtime has written them.";
            } catch (Exception e) { result = "Save export failed: " + e.getMessage(); }
            final String message = result;
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                progress.dismiss();
                new AlertDialog.Builder(this).setTitle("SAVE EXPORT").setMessage(message).setPositiveButton("OK", null).show();
            });
        }, "ysix-save-export").start();
    }

    private void addToZip(File root, File file, ZipOutputStream zout) throws IOException {
        File[] children = file.listFiles();
        if (file.isDirectory()) {
            if (children != null) for (File child : children) addToZip(root, child, zout);
            return;
        }
        String rel = file.getAbsolutePath().substring(root.getAbsolutePath().length() + 1).replace(File.separatorChar, '/');
        zout.putNextEntry(new ZipEntry(rel));
        try (InputStream in = new BufferedInputStream(new FileInputStream(file))) {
            byte[] buf = new byte[64 * 1024]; int n;
            while ((n = in.read(buf)) != -1) zout.write(buf, 0, n);
        }
        zout.closeEntry();
    }

    private void clearSaveWorkspace() {
        File root = saveRoot();
        File[] files = root.listFiles();
        if (files != null) for (File f : files) deleteTree(f);
        Toast.makeText(this, "Save workspace cleared", Toast.LENGTH_SHORT).show();
        renderApp();
    }

    private void deleteTree(File file) {
        if (file == null || !file.exists()) return;
        File[] children = file.listFiles();
        if (children != null) for (File child : children) deleteTree(child);
        file.delete();
    }

    private void persistReadPermission(Uri uri, int resultFlags) {
        int takeFlags = resultFlags & Intent.FLAG_GRANT_READ_URI_PERMISSION;
        if (takeFlags == 0) takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION;
        try {
            getContentResolver().takePersistableUriPermission(uri, takeFlags);
        } catch (SecurityException ignored) {
            // Some document providers grant temporary access only.
        }
    }

    private boolean hasReadAccess(Uri uri) {
        if (uri == null) return false;
        try (android.os.ParcelFileDescriptor ignored = getContentResolver().openFileDescriptor(uri, "r")) {
            return ignored != null;
        } catch (Exception e) {
            return false;
        }
    }

    private void releasePersistedPermission(Uri uri) {
        if (uri == null) return;
        try {
            getContentResolver().releasePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) { }
    }

    private String queryDisplayName(Uri uri) {
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) return cursor.getString(index);
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        String last = uri.getLastPathSegment();
        return last == null ? "Selected document" : last;
    }

    private void showRuntimeNotice(String message) {
        new AlertDialog.Builder(this)
                .setTitle("YS IX · RUNTIME STATUS")
                .setMessage(message)
                .setPositiveButton("GOT IT", null)
                .show();
    }

    private String detectGlRenderer() {
        EGL10 egl = null;
        EGLDisplay display = null;
        EGLSurface surface = null;
        EGLContext context = null;
        try {
            egl = (EGL10) EGLContext.getEGL();
            display = egl.eglGetDisplay(EGL10.EGL_DEFAULT_DISPLAY);
            int[] version = new int[2];
            if (display == EGL10.EGL_NO_DISPLAY || !egl.eglInitialize(display, version)) return "Not reported";
            int[] configAttrs = {0x3040, 4, 0x3024, 8, 0x3023, 8, 0x3022, 8, 0x3021, 8, 0x3038};
            EGLConfig[] configs = new EGLConfig[1];
            int[] count = new int[1];
            if (!egl.eglChooseConfig(display, configAttrs, configs, 1, count) || count[0] == 0) return "Not reported";
            int[] surfaceAttrs = {0x3057, 1, 0x3056, 1, 0x3038};
            surface = egl.eglCreatePbufferSurface(display, configs[0], surfaceAttrs);
            int[] contextAttrs = {0x3098, 2, 0x3038};
            context = egl.eglCreateContext(display, configs[0], EGL10.EGL_NO_CONTEXT, contextAttrs);
            if (surface == EGL10.EGL_NO_SURFACE || context == EGL10.EGL_NO_CONTEXT) return "Not reported";
            if (!egl.eglMakeCurrent(display, surface, surface, context)) return "Not reported";
            String renderer = GLES20.glGetString(GLES20.GL_RENDERER);
            return renderer == null ? "Not reported" : renderer;
        } catch (Throwable ignored) {
            return "Not reported";
        } finally {
            try {
                if (egl != null && display != null && display != EGL10.EGL_NO_DISPLAY) {
                    egl.eglMakeCurrent(display, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_CONTEXT);
                    if (context != null && context != EGL10.EGL_NO_CONTEXT) egl.eglDestroyContext(display, context);
                    if (surface != null && surface != EGL10.EGL_NO_SURFACE) egl.eglDestroySurface(display, surface);
                    egl.eglTerminate(display);
                }
            } catch (Throwable ignored) { }
        }
    }

    private String detectVulkanVersion() {
        try {
            PackageManager pm = getPackageManager();
            int version = 0;
            for (FeatureInfo feature : pm.getSystemAvailableFeatures()) {
                if ("android.hardware.vulkan.version".equals(feature.name)) {
                    version = feature.version;
                    break;
                }
            }
            if (version > 0) {
                int major = (version >> 22) & 0x7F;
                int minor = (version >> 12) & 0x3FF;
                return "Reported " + major + "." + minor;
            }
            return pm.hasSystemFeature("android.hardware.vulkan.level") ? "Level feature reported; version unknown" : "Not reported by Android";
        } catch (Exception e) {
            return "Could not query";
        }
    }

    private void applyDefaultsIfNeeded() {
        if (prefs.contains("scale")) return;
        prefs.edit().putString("scale", suggestedScale()).putString("fps", "30 FPS")
                .putBoolean("shader_cache", true).putBoolean("vsync", true).putBoolean("overlay", true)
                .putBoolean("touch_controls", true).putBoolean("haptics", false).apply();
    }

    private String suggestedScale() {
        String gpu = gpuRenderer.toLowerCase(Locale.ROOT);
        if (gpu.contains("g720")) return "1.0x";
        if (gpu.contains("g57")) return "0.5x";
        return "0.75x";
    }

    private String getSuggestedProfile() {
        String gpu = gpuRenderer.toLowerCase(Locale.ROOT);
        if (gpu.contains("g720")) return "Mali G720 · Balanced";
        if (gpu.contains("g57")) return "Mali G57 · Low-load";
        if (gpu.contains("mali")) return "Mali · Compatibility";
        return "Automatic · Compatibility";
    }

    private String formatRam() {
        try {
            ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo info = new ActivityManager.MemoryInfo();
            manager.getMemoryInfo(info);
            return String.format(Locale.US, "%.1f GB", info.totalMem / 1073741824.0);
        } catch (Exception e) {
            return "Not reported";
        }
    }

    private String join(String[] values) {
        if (values == null || values.length == 0) return "Not reported";
        StringBuilder out = new StringBuilder();
        for (String value : values) {
            if (out.length() > 0) out.append(", ");
            out.append(value);
        }
        return out.toString();
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        return drawable;
    }

    private GradientDrawable gradient(int[] colors, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
        drawable.setCornerRadius(dp(radiusDp));
        drawable.setStroke(dp(1), Color.rgb(87, 47, 56));
        return drawable;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
