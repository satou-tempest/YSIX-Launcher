package io.github.ysix.launcher;

/** JNI bridge for Ys IX NSP/ExeFS diagnostics and captured-shader translation. */
public final class NativeProbe {
    static { System.loadLibrary("ysixprobe"); }
    public static native String inspect(int gameFd, String gameName, int prodKeysFd, int titleKeysFd);
    /** Translate previously captured Ys IX Maxwell shader misses into the runtime SPIR-V cache. */
    public static String prepareShaders(String dataRoot, int jobs) {
        try {
            System.loadLibrary("spirvharness");
        } catch (UnsatisfiedLinkError e) {
            return "The bundled ARM64 shader translator could not be loaded: " + e.getMessage();
        }
        return nativePrepareShaders(dataRoot, jobs);
    }
    private static native String nativePrepareShaders(String dataRoot, int jobs);
    /** Current translator progress: [completed, total]. */
    public static native int[] shaderProgress();
    private NativeProbe() { }
}
