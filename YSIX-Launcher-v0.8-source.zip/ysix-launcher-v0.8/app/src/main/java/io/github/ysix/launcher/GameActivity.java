package io.github.ysix.launcher;

import android.app.NativeActivity;

/** Launches the generic ARM64 native execution runtime for a controlled Ys IX boot attempt. */
public final class GameActivity extends NativeActivity {
    // The native runtime reads the selected SAF URIs from this activity's Intent in ANativeActivity_onCreate.
}
