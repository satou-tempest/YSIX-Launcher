#include "native_loader.h"

#include <algorithm>
#include <cerrno>
#include <cstdint>
#include <cstring>
#include <iomanip>
#include <map>
#include <memory>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>

#include <sys/mman.h>
#include <unistd.h>

#include "nxgame.h"

#ifndef MAP_FIXED_NOREPLACE
#define MAP_FIXED_NOREPLACE 0x100000
#endif

namespace ysix {
namespace {
constexpr uint64_t kMainBase = 0x4000000000ull;
constexpr uint64_t kSdkBase = 0x4010000000ull;
constexpr uint64_t kModuleWindow = 0x10000000ull;
constexpr int64_t DT_NULL = 0;
constexpr int64_t DT_PLTRELSZ = 2;
constexpr int64_t DT_STRTAB = 5;
constexpr int64_t DT_SYMTAB = 6;
constexpr int64_t DT_RELA = 7;
constexpr int64_t DT_RELASZ = 8;
constexpr int64_t DT_STRSZ = 10;
constexpr int64_t DT_SYMENT = 11;
constexpr int64_t DT_JMPREL = 23;
constexpr int64_t DT_INIT_ARRAY = 25;
constexpr int64_t DT_FINI_ARRAY = 26;
constexpr int64_t DT_INIT_ARRAYSZ = 27;
constexpr int64_t DT_FINI_ARRAYSZ = 28;

// ELF64/AArch64 relocation numbers.
constexpr uint32_t R_AARCH64_ABS64 = 257;
constexpr uint32_t R_AARCH64_GLOB_DAT = 1025;
constexpr uint32_t R_AARCH64_JUMP_SLOT = 1026;
constexpr uint32_t R_AARCH64_RELATIVE = 1027;
constexpr uint16_t SHN_UNDEF = 0;
constexpr uint16_t SHN_ABS = 0xfff1;
constexpr uint16_t SHN_LORESERVE = 0xff00;
constexpr uint8_t STB_LOCAL = 0;
constexpr uint8_t STB_GLOBAL = 1;
constexpr uint8_t STB_WEAK = 2;
constexpr uint8_t STT_FUNC = 2;
constexpr uint8_t STT_TLS = 6;
constexpr uint8_t STT_GNU_IFUNC = 10;

uint32_t u32(const std::vector<uint8_t>& v, uint64_t at, bool& ok) {
    if (at > v.size() || v.size() - size_t(at) < 4) { ok = false; return 0; }
    uint32_t x = 0;
    std::memcpy(&x, v.data() + at, 4);
    return x;
}
uint64_t page_up(uint64_t x, uint64_t page) {
    if (!page || (page & (page - 1)) || x > UINT64_MAX - (page - 1)) return 0;
    return (x + page - 1) & ~(page - 1);
}

struct Mapping {
    void* p = MAP_FAILED;
    size_t n = 0;
    ~Mapping() { unmap(); }
    void unmap() {
        if (p != MAP_FAILED) munmap(p, n);
        p = MAP_FAILED;
        n = 0;
    }
    bool map_at(uint64_t address, size_t size, std::string& why) {
        p = mmap(reinterpret_cast<void*>(uintptr_t(address)), size, PROT_READ | PROT_WRITE,
                 MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED_NOREPLACE, -1, 0);
        if (p == MAP_FAILED) {
            std::ostringstream s;
            s << "mmap at 0x" << std::hex << address << " failed: " << std::strerror(errno);
            why = s.str();
            return false;
        }
        if (uintptr_t(p) != uintptr_t(address)) {
            munmap(p, size);
            p = MAP_FAILED;
            why = "kernel did not honor requested non-clobbering fixed mapping";
            return false;
        }
        n = size;
        return true;
    }
};

struct Symbol {
    std::string name;
    uint64_t value = 0;
    uint8_t info = 0;
    uint16_t section = SHN_UNDEF;
    uint8_t binding() const { return uint8_t(info >> 4); }
    uint8_t type() const { return uint8_t(info & 0x0f); }
    bool defined() const { return section != SHN_UNDEF && (section < SHN_LORESERVE || section == SHN_ABS); }
};

struct Relocation {
    uint64_t offset = 0;
    uint32_t type = 0;
    uint32_t symbol = 0;
    int64_t addend = 0;
};

struct Audit {
    std::string name;
    uint64_t base = 0;
    uint64_t imageSize = 0;
    uint64_t mapSize = 0;
    uint64_t mod0 = 0;
    uint64_t bssStart = 0;
    uint64_t bssEnd = 0;
    uint64_t strtab = 0;
    uint64_t symCount = 0;
    uint64_t importCount = 0;
    uint64_t relaCount = 0;
    uint64_t pltRelaCount = 0;
    uint64_t initCount = 0;
    uint64_t finiCount = 0;
    std::map<uint32_t, uint64_t> relocTypes;
    std::vector<std::string> importSamples;
    std::vector<uint8_t> image;
    std::vector<Symbol> symbols;
    std::vector<Relocation> relocations;
};

bool parse_module(const std::vector<uint8_t>& raw, const char* name, uint64_t base,
                  Audit& a, std::string& error) {
    a.name = name;
    a.base = base;
    if (!nxi::nso_to_flat_image(raw, a.image, error)) {
        error = std::string(name) + ": " + error;
        return false;
    }
    a.imageSize = a.image.size();
    bool ok = true;
    if (a.image.size() < 0x20) { error = std::string(name) + ": decompressed image is too small"; return false; }
    a.mod0 = u32(a.image, 4, ok);
    if (!ok || a.mod0 > a.image.size() || a.image.size() - size_t(a.mod0) < 0x1c ||
        std::memcmp(a.image.data() + a.mod0, "MOD0", 4) != 0) {
        error = std::string(name) + ": MOD0 header is missing or out of range";
        return false;
    }
    int32_t rel[5]{};
    for (int i = 0; i < 5; ++i) {
        uint32_t rawRel = u32(a.image, a.mod0 + 4 + uint64_t(i) * 4, ok);
        std::memcpy(&rel[i], &rawRel, sizeof(rawRel));
    }
    if (!ok) { error = std::string(name) + ": truncated MOD0 metadata"; return false; }
    const int64_t dynSigned = int64_t(a.mod0) + int64_t(rel[0]);
    const int64_t bssStartSigned = int64_t(a.mod0) + int64_t(rel[1]);
    const int64_t bssEndSigned = int64_t(a.mod0) + int64_t(rel[2]);
    if (dynSigned < 0 || bssStartSigned < 0 || bssEndSigned < bssStartSigned ||
        uint64_t(dynSigned) >= a.image.size() || uint64_t(bssEndSigned) > kModuleWindow) {
        error = std::string(name) + ": MOD0 dynamic/BSS offsets are invalid";
        return false;
    }
    a.bssStart = uint64_t(bssStartSigned);
    a.bssEnd = uint64_t(bssEndSigned);
    a.mapSize = std::max<uint64_t>(a.imageSize, a.bssEnd);

    std::map<int64_t, uint64_t> dyn;
    const uint64_t dynOff = uint64_t(dynSigned);
    bool terminated = false;
    for (uint64_t p = dynOff, n = 0; p <= a.image.size() && a.image.size() - size_t(p) >= 16 && n < 65536; p += 16, ++n) {
        int64_t tag = 0;
        uint64_t value = 0;
        std::memcpy(&tag, a.image.data() + p, 8);
        std::memcpy(&value, a.image.data() + p + 8, 8);
        if (tag == DT_NULL) { terminated = true; break; }
        dyn.emplace(tag, value);
    }
    if (!terminated) { error = std::string(name) + ": .dynamic has no bounded DT_NULL terminator"; return false; }
    if (!dyn.count(DT_STRTAB) || !dyn.count(DT_SYMTAB)) {
        error = std::string(name) + ": dynamic symbol/string table tags are missing";
        return false;
    }
    a.strtab = dyn[DT_STRTAB];
    const uint64_t symtab = dyn[DT_SYMTAB];
    const uint64_t syment = dyn.count(DT_SYMENT) ? dyn[DT_SYMENT] : 24;
    const uint64_t strsz = dyn.count(DT_STRSZ) ? dyn[DT_STRSZ] : (a.image.size() - std::min<uint64_t>(a.strtab, a.image.size()));
    if (syment < 24 || syment > 256 || a.strtab > a.image.size() || strsz > a.image.size() - a.strtab || symtab > a.strtab) {
        error = std::string(name) + ": symbol/string table bounds are invalid";
        return false;
    }
    a.symCount = (a.strtab - symtab) / syment;
    if (a.symCount > 2'000'000) { error = std::string(name) + ": implausible symbol count"; return false; }
    a.symbols.resize(size_t(a.symCount));
    for (uint64_t i = 0; i < a.symCount; ++i) {
        const uint64_t at = symtab + i * syment;
        if (at > a.image.size() || a.image.size() - size_t(at) < 24) {
            error = std::string(name) + ": symbol table exceeds module image";
            return false;
        }
        uint32_t stName = 0;
        uint8_t stInfo = 0;
        uint16_t stSection = 0;
        uint64_t stValue = 0;
        std::memcpy(&stName, a.image.data() + at, 4);
        std::memcpy(&stInfo, a.image.data() + at + 4, 1);
        std::memcpy(&stSection, a.image.data() + at + 6, 2);
        std::memcpy(&stValue, a.image.data() + at + 8, 8);
        Symbol& sym = a.symbols[size_t(i)];
        sym.info = stInfo;
        sym.section = stSection;
        sym.value = stValue;
        if (stName < strsz) {
            const char* nm = reinterpret_cast<const char*>(a.image.data() + a.strtab + stName);
            const size_t remaining = size_t(strsz - stName);
            const size_t len = strnlen(nm, remaining);
            if (len == remaining) {
                error = std::string(name) + ": unterminated symbol name";
                return false;
            }
            sym.name.assign(nm, len);
        } else if (stName != 0) {
            error = std::string(name) + ": symbol name offset is outside DT_STRSZ";
            return false;
        }
        if (!sym.defined()) {
            ++a.importCount;
            if (a.importSamples.size() < 8 && !sym.name.empty()) a.importSamples.push_back(sym.name);
        }
    }

    auto parseRelocs = [&](int64_t startTag, int64_t sizeTag, uint64_t& total) -> bool {
        if (!dyn.count(startTag)) return true;
        const uint64_t start = dyn[startTag];
        const uint64_t bytes = dyn.count(sizeTag) ? dyn[sizeTag] : 0;
        if (start > a.image.size() || bytes > a.image.size() - start || bytes % 24 != 0) return false;
        for (uint64_t p = start; p < start + bytes; p += 24) {
            Relocation r{};
            uint64_t info = 0;
            std::memcpy(&r.offset, a.image.data() + p, 8);
            std::memcpy(&info, a.image.data() + p + 8, 8);
            std::memcpy(&r.addend, a.image.data() + p + 16, 8);
            r.type = uint32_t(info);
            r.symbol = uint32_t(info >> 32);
            if (r.offset >= a.mapSize) return false;
            if ((r.type == R_AARCH64_RELATIVE || r.type == R_AARCH64_ABS64 ||
                 r.type == R_AARCH64_GLOB_DAT || r.type == R_AARCH64_JUMP_SLOT) &&
                (a.mapSize - r.offset < 8 || (r.offset & 7u) != 0)) return false;
            if (r.symbol != 0 && r.symbol >= a.symCount) return false;
            ++a.relocTypes[r.type];
            ++total;
            a.relocations.push_back(r);
        }
        return true;
    };
    if (!parseRelocs(DT_RELA, DT_RELASZ, a.relaCount) || !parseRelocs(DT_JMPREL, DT_PLTRELSZ, a.pltRelaCount)) {
        error = std::string(name) + ": relocation table is out of module bounds or has an invalid symbol index";
        return false;
    }
    auto arrayCount = [&](int64_t addrTag, int64_t sizeTag, uint64_t& count) -> bool {
        if (!dyn.count(addrTag) && !dyn.count(sizeTag)) return true;
        if (!dyn.count(addrTag) || !dyn.count(sizeTag)) return false;
        const uint64_t at = dyn[addrTag], bytes = dyn[sizeTag];
        if (at > a.image.size() || bytes > a.image.size() - at || bytes % 8 != 0) return false;
        count = bytes / 8;
        return true;
    };
    if (!arrayCount(DT_INIT_ARRAY, DT_INIT_ARRAYSZ, a.initCount) ||
        !arrayCount(DT_FINI_ARRAY, DT_FINI_ARRAYSZ, a.finiCount)) {
        error = std::string(name) + ": init/fini array bounds are invalid";
        return false;
    }
    if (a.mapSize == 0 || a.mapSize > kModuleWindow) {
        error = std::string(name) + ": image exceeds the reserved 256 MiB module window";
        return false;
    }
    return true;
}

struct Export {
    uint64_t address = 0;
    bool weak = false;
    std::string module;
};
using ExportMap = std::unordered_map<std::string, Export>;

ExportMap build_exports(const Audit& main, const Audit& sdk, uint64_t& count) {
    ExportMap exports;
    auto add = [&](const Audit& a) {
        for (const Symbol& s : a.symbols) {
            if (!s.defined() || s.binding() == STB_LOCAL || s.name.empty() ||
                s.type() == STT_TLS || s.type() == STT_GNU_IFUNC) continue;
            if (s.section != SHN_ABS && s.value >= a.mapSize) continue;
            const uint64_t address = s.section == SHN_ABS ? s.value : a.base + s.value;
            const bool weak = s.binding() == STB_WEAK;
            auto it = exports.find(s.name);
            if (it == exports.end()) {
                exports.emplace(s.name, Export{address, weak, a.name});
                ++count;
            } else if (it->second.weak && !weak) {
                it->second = Export{address, false, a.name};
            }
        }
    };
    add(main);  // Prefer strong over weak definitions; the first strong definition wins.
    add(sdk);
    return exports;
}

struct LinkStats {
    uint64_t total = 0;
    uint64_t relative = 0;
    uint64_t moduleDefined = 0;
    uint64_t moduleExports = 0;
    uint64_t weakZero = 0;
    uint64_t unresolved = 0;
    uint64_t unsupported = 0;
    uint64_t verified = 0;
    uint64_t functionUnresolved = 0;
    uint64_t dataUnresolved = 0;
    std::map<std::string, uint64_t> unresolvedNames;
    std::map<uint32_t, uint64_t> unsupportedTypes;
};

bool map_copy(const Audit& a, Mapping& mapping, std::string& error) {
    const long pageLong = sysconf(_SC_PAGESIZE);
    if (pageLong <= 0) { error = "cannot query Android page size"; return false; }
    const uint64_t size = page_up(a.mapSize, uint64_t(pageLong));
    if (!size || size > SIZE_MAX) { error = a.name + ": invalid mapping size"; return false; }
    if (!mapping.map_at(a.base, size_t(size), error)) { error = a.name + ": " + error; return false; }
    std::memcpy(mapping.p, a.image.data(), a.image.size());
    if (a.bssEnd > a.image.size()) {
        const uint8_t* b = static_cast<const uint8_t*>(mapping.p) + a.image.size();
        const size_t n = size_t(std::min<uint64_t>(a.bssEnd - a.image.size(), size - a.image.size()));
        for (size_t i = 0; i < n; ++i) {
            if (b[i] != 0) { error = a.name + ": anonymous BSS pages were not zero-filled"; return false; }
        }
    }
    return true;
}

bool relocate_to_temporary_mapping(const Audit& a, Mapping& mapping, const ExportMap& exports,
                                   LinkStats& stats, std::string& error) {
    auto* image = static_cast<uint8_t*>(mapping.p);
    for (const Relocation& r : a.relocations) {
        ++stats.total;
        uint64_t symbolAddress = 0;
        bool resolved = false;
        if (r.type == R_AARCH64_RELATIVE) {
            symbolAddress = a.base;
            resolved = true;
            ++stats.relative;
        } else if (r.type == R_AARCH64_ABS64 || r.type == R_AARCH64_GLOB_DAT || r.type == R_AARCH64_JUMP_SLOT) {
            if (r.symbol == 0) {
                // ELF symbol zero is the null symbol: S == 0.
                resolved = true;
            } else {
                const Symbol& sym = a.symbols[r.symbol];
                // TLS symbols need a guest TLS layout; IFUNC symbols need their resolver to run. Neither is
                // equivalent to a plain base+st_value address, so leave both unresolved at this stage.
                if (sym.type() == STT_TLS || sym.type() == STT_GNU_IFUNC) {
                    ++stats.unresolved;
                    if (sym.type() == STT_GNU_IFUNC || sym.type() == STT_FUNC) ++stats.functionUnresolved;
                    else ++stats.dataUnresolved;
                    stats.unresolvedNames[(sym.type() == STT_TLS ? "<TLS> " : "<IFUNC> ") +
                                          (sym.name.empty() ? "<unnamed>" : sym.name)]++;
                } else if (sym.defined()) {
                    if (sym.section == SHN_ABS || sym.value < a.mapSize) {
                        symbolAddress = sym.section == SHN_ABS ? sym.value : a.base + sym.value;
                        resolved = true;
                        ++stats.moduleDefined;
                    } else {
                        ++stats.unresolved;
                        if (sym.type() == STT_FUNC) ++stats.functionUnresolved;
                        else ++stats.dataUnresolved;
                        stats.unresolvedNames["<out-of-range> " + (sym.name.empty() ? "<unnamed>" : sym.name)]++;
                    }
                } else {
                    auto found = exports.find(sym.name);
                    if (!sym.name.empty() && found != exports.end()) {
                        symbolAddress = found->second.address;
                        resolved = true;
                        ++stats.moduleExports;
                    } else if (sym.binding() == STB_WEAK) {
                        symbolAddress = 0;
                        resolved = true;
                        ++stats.weakZero;
                    } else {
                        ++stats.unresolved;
                        if (sym.type() == STT_FUNC) ++stats.functionUnresolved;
                        else ++stats.dataUnresolved;
                        stats.unresolvedNames[sym.name.empty() ? "<unnamed>" : sym.name]++;
                    }
                }
            }
        } else {
            ++stats.unsupported;
            ++stats.unsupportedTypes[r.type];
            continue;
        }
        if (!resolved) continue;  // Keep unresolved strong imports untouched; never fake an HLE address.
        const uint64_t value = symbolAddress + uint64_t(r.addend);
        std::memcpy(image + r.offset, &value, sizeof(value));
        uint64_t check = 0;
        std::memcpy(&check, image + r.offset, sizeof(check));
        if (check != value) {
            error = a.name + ": temporary relocation verification failed at offset 0x";
            std::ostringstream s;
            s << std::hex << r.offset;
            error += s.str();
            return false;
        }
        ++stats.verified;
    }
    return true;
}

void emit_audit(std::ostringstream& out, const Audit& a) {
    out << "  " << a.name << " @ 0x" << std::hex << a.base << std::dec
        << ": image=" << a.imageSize << " bytes, mapped span=" << a.mapSize << " bytes\n";
    out << "    MOD0=" << a.mod0 << ", BSS=[" << a.bssStart << ", " << a.bssEnd << ")\n";
    out << "    symbols=" << a.symCount << ", imported symbols=" << a.importCount
        << ", RELA=" << a.relaCount << ", PLT RELA=" << a.pltRelaCount
        << ", init-array=" << a.initCount << ", fini-array=" << a.finiCount << "\n";
    out << "    relocation types:";
    for (const auto& p : a.relocTypes) out << " R_AARCH64(type=" << p.first << ")=" << p.second;
    if (a.relocTypes.empty()) out << " none";
    out << "\n";
    if (!a.importSamples.empty()) {
        out << "    imported symbol samples:";
        for (const auto& name : a.importSamples) out << " " << name;
        out << "\n";
    }
}

void emit_link_stats(std::ostringstream& out, const LinkStats& s, uint64_t exportCount) {
    out << "\n[SAFE RELOCATION / SYMBOL-RESOLUTION TEST]\n";
    out << "Global/weak exports indexed across main + sdk: " << exportCount << "\n";
    out << "Relocation records scanned: " << s.total << "\n";
    out << "  R_AARCH64_RELATIVE applied: " << s.relative << "\n";
    out << "  Defined module symbols applied: " << s.moduleDefined << "\n";
    out << "  Defined exports resolved from main/SDK table: " << s.moduleExports << "\n";
    out << "  Unresolved weak imports bound to zero: " << s.weakZero << "\n";
    out << "  Unresolved strong imports skipped: " << s.unresolved << " (functions=" << s.functionUnresolved
        << ", data/other=" << s.dataUnresolved << ")\n";
    out << "  Unsupported relocation records skipped: " << s.unsupported << "\n";
    out << "  Temporary writes verified: " << s.verified << "\n";
    if (!s.unsupportedTypes.empty()) {
        out << "Unsupported relocation types:";
        for (const auto& p : s.unsupportedTypes) out << " type=" << p.first << " count=" << p.second;
        out << "\n";
    }
    if (!s.unresolvedNames.empty()) {
        out << "Unresolved import names (highest reference count first, max 48):\n";
        std::vector<std::pair<std::string, uint64_t>> names(s.unresolvedNames.begin(), s.unresolvedNames.end());
        std::sort(names.begin(), names.end(), [](const auto& a, const auto& b) {
            if (a.second != b.second) return a.second > b.second;
            return a.first < b.first;
        });
        const size_t take = std::min<size_t>(48, names.size());
        for (size_t i = 0; i < take; ++i) out << "  " << names[i].first << " - " << names[i].second << " relocation(s)\n";
        if (names.size() > take) out << "  ... " << (names.size() - take) << " additional unique imports\n";
    }
    out << "Relocation target: temporary RW mappings only; all mappings are discarded after verification.\n";
}
} // namespace

bool native_loader_stage(const nxi::GameImage& game, std::ostringstream& report, std::string& error) {
    const auto& exefs = game.exefs();
    auto mainIt = exefs.find("main"), sdkIt = exefs.find("sdk");
    if (mainIt == exefs.end() || sdkIt == exefs.end()) { error = "ExeFS main/sdk pair is incomplete"; return false; }

    Audit mainAudit, sdkAudit;
    if (!parse_module(mainIt->second, "main", kMainBase, mainAudit, error)) return false;
    if (!parse_module(sdkIt->second, "sdk", kSdkBase, sdkAudit, error)) return false;
    if (mainAudit.mapSize >= kModuleWindow || sdkAudit.mapSize >= kModuleWindow) {
        error = "one or both modules exceed the 256 MiB spacing between their reserved guest bases";
        return false;
    }

    report << "\n[NATIVE MODULE LOADER STAGE]\n";
    report << "NSO decompression + segment SHA-256: PASS\n";
    report << "MOD0 + dynamic table parsing: PASS\n";
    emit_audit(report, mainAudit);
    emit_audit(report, sdkAudit);

    Mapping mainMap, sdkMap;
    std::string why;
    report << "Temporary fixed-address mapping (MAP_FIXED_NOREPLACE, both modules RW/non-executable):\n";
    if (!map_copy(mainAudit, mainMap, why)) { error = "main mapping: " + why; report << "  main mapping: FAIL - " << error << "\n"; return false; }
    report << "  main mapping: PASS\n";
    if (!map_copy(sdkAudit, sdkMap, why)) { error = "sdk mapping: " + why; report << "  sdk mapping: FAIL - " << error << "\n"; return false; }
    report << "  sdk mapping: PASS\n";
    report << "Gate B1 (simultaneous module staging): PASS\n";

    uint64_t exportCount = 0;
    const ExportMap exports = build_exports(mainAudit, sdkAudit, exportCount);
    LinkStats stats;
    const bool mainLinked = relocate_to_temporary_mapping(mainAudit, mainMap, exports, stats, why);
    const bool sdkLinked = mainLinked && relocate_to_temporary_mapping(sdkAudit, sdkMap, exports, stats, why);
    emit_link_stats(report, stats, exportCount);
    if (!mainLinked || !sdkLinked) {
        error = why;
        report << "Safe relocation test: FAIL - " << why << "\n";
        report << "Gate B2a (temporary relocation + symbol-resolution test): FAIL\n";
        report << "Relocation failure stopped the test before any guest code could execute.\n";
        mainMap.unmap();
        sdkMap.unmap();
        report << "Temporary module mappings: discarded after failure.\n";
        report << "Executable page permissions: NOT ENABLED\n";
        report << "Constructors / rtld / nnMain entry: NOT ATTEMPTED\n";
        return true;  // The native probe completed; its report contains the B2a failure.
    }
    report << "Safe relocation test: PASS\n";
    report << "Gate B2a (temporary relocation + symbol-resolution test): PASS\n";
    if (stats.unresolved || stats.unsupported) {
        report << "Link status: PARTIAL - unresolved external symbols or unsupported relocation types remain.\n";
    } else {
        report << "Link status: all observed relocation records resolved in this two-module scope.\n";
    }
    report << "Probe scope: this is the separate pre-boot diagnostic; the integrated NCE/Horizon runtime is in libysix.so.\n";
    report << "Import resolver/Horizon HLE in this probe: NOT EXERCISED\n";
    report << "Executable page permissions in this probe: NOT ENABLED\n";
    report << "Constructors / rtld / nnMain entry in this probe: NOT ATTEMPTED\n";
    report << "Gate B2b (full link + controlled entry) in this probe: NOT ATTEMPTED\n";
    report << "Gameplay: NOT TESTED BY THIS PROBE - use TRY NATIVE BOOT for the separate runtime attempt.\n";
    mainMap.unmap();
    sdkMap.unmap();
    report << "Temporary module mappings: discarded after verification.\n";
    return true;
}
} // namespace ysix
