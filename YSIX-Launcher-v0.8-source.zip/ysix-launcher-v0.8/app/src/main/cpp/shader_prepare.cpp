// Ys IX shader-miss preparation bridge.
//
// The runtime writes raw Maxwell code/control pairs to <data>/shader_misses when a shader
// is unavailable in <data>/spirv. This bridge builds the manifest expected by the generic
// Ryujinx SPIR-V harness, translates only uncached misses, then merges SPIR-V and resource
// metadata into the runtime cache. No game assets or shader binaries are bundled.
#include <jni.h>
#include <dlfcn.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <cerrno>
#include <cstdint>
#include <exception>
#include <atomic>
#include <cctype>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <mutex>
#include <set>
#include <sstream>
#include <string>
#include <vector>

namespace {

using HarnessMain = int (*)(int, const char**);
using HarnessProgress = void (*)(int*, int*);

std::mutex g_prepare_mutex;
std::atomic<int> g_done{0};
std::atomic<int> g_total{0};
std::atomic<bool> g_running{false};
void* g_harness_handle = nullptr;
HarnessMain g_harness_main = nullptr;
HarnessProgress g_harness_progress = nullptr;

uint32_t read_le32(const unsigned char* p) {
    return uint32_t(p[0]) | (uint32_t(p[1]) << 8) |
           (uint32_t(p[2]) << 16) | (uint32_t(p[3]) << 24);
}

bool is_directory(const std::string& p) {
    struct stat st{};
    return stat(p.c_str(), &st) == 0 && S_ISDIR(st.st_mode);
}

bool ensure_directory(const std::string& p) {
    if (is_directory(p)) return true;
    if (mkdir(p.c_str(), 0700) == 0) return true;
    return errno == EEXIST && is_directory(p);
}

bool remove_tree(const std::string& path) {
    DIR* dir = opendir(path.c_str());
    if (!dir) return errno == ENOENT;
    bool ok = true;
    while (dirent* entry = readdir(dir)) {
        const std::string name(entry->d_name);
        if (name == "." || name == "..") continue;
        const std::string child = path + "/" + name;
        struct stat st{};
        if (lstat(child.c_str(), &st) != 0) { ok = false; continue; }
        if (S_ISDIR(st.st_mode)) {
            if (!remove_tree(child)) ok = false;
        } else if (unlink(child.c_str()) != 0) {
            ok = false;
        }
    }
    closedir(dir);
    if (rmdir(path.c_str()) != 0 && errno != ENOENT) ok = false;
    return ok;
}

std::string jstring_utf8(JNIEnv* env, jstring value) {
    if (!value) return {};
    const char* chars = env->GetStringUTFChars(value, nullptr);
    if (!chars) return {};
    std::string result(chars);
    env->ReleaseStringUTFChars(value, chars);
    return result;
}

bool read_bytes(const std::string& path, std::vector<unsigned char>& out) {
    std::ifstream in(path, std::ios::binary);
    if (!in) return false;
    in.seekg(0, std::ios::end);
    const std::streamoff size = in.tellg();
    if (size < 0 || uint64_t(size) > (64ull << 20)) return false;
    in.seekg(0, std::ios::beg);
    out.resize(static_cast<size_t>(size));
    if (size && !in.read(reinterpret_cast<char*>(out.data()), size)) return false;
    return true;
}

bool write_text(const std::string& path, const std::string& value) {
    const std::string tmp = path + ".tmp";
    {
        std::ofstream out(tmp, std::ios::binary | std::ios::trunc);
        if (!out || !(out.write(value.data(), static_cast<std::streamsize>(value.size())))) return false;
    }
    if (rename(tmp.c_str(), path.c_str()) == 0) return true;
    unlink(tmp.c_str());
    return false;
}

bool copy_file(const std::string& from, const std::string& to) {
    std::ifstream in(from, std::ios::binary);
    if (!in) return false;
    const std::string tmp = to + ".tmp";
    std::ofstream out(tmp, std::ios::binary | std::ios::trunc);
    if (!out) return false;
    out << in.rdbuf();
    out.flush();
    if (in.bad()) { out.close(); unlink(tmp.c_str()); return false; }
    out.close();
    if (!out) { unlink(tmp.c_str()); return false; }
    if (rename(tmp.c_str(), to.c_str()) == 0) return true;
    // rename replaces an existing file on Android/Linux; this is a defensive fallback.
    unlink(to.c_str());
    const bool ok = rename(tmp.c_str(), to.c_str()) == 0;
    if (!ok) unlink(tmp.c_str());
    return ok;
}

bool valid_hash(const std::string& h) {
    if (h.size() != 16) return false;
    for (unsigned char c : h)
        if (!std::isxdigit(c)) return false;
    return true;
}

bool shader_is_cached(const std::string& cache, const std::string& hash) {
    struct stat st{};
    const std::string p = cache + "/" + hash + ".spv";
    return stat(p.c_str(), &st) == 0 && S_ISREG(st.st_mode) && st.st_size > 0 && (st.st_size % 4) == 0;
}

std::string stage_for(const std::vector<unsigned char>& code, const std::vector<unsigned char>& ctrl) {
    if (code.size() >= 4 && read_le32(code.data()) == 0x12345679u) return "compute";
    const uint32_t start = read_le32(ctrl.data() + 0x708);
    if (start == 0 && read_le32(ctrl.data() + 0x748) != 0) return "compute";
    if (uint64_t(start) + 0x34 <= code.size()) {
        const uint32_t type = (read_le32(code.data() + start + 0x30) >> 10) & 0xf;
        if (type == 1) return "vertex";
        if (type == 5) return "fragment";
    }
    return "unknown";
}

struct Miss {
    std::string hash;
    std::string code_name;
    std::string ctrl_name;
    std::string stage;
    size_t code_size = 0;
};

bool build_manifest(const std::string& misses_dir, const std::string& cache_dir,
                    std::vector<Miss>& pending, std::string& error) {
    DIR* dir = opendir(misses_dir.c_str());
    if (!dir) {
        error = "No shader_misses folder yet. Run TRY NATIVE BOOT once, then return here.";
        return false;
    }
    while (dirent* entry = readdir(dir)) {
        const std::string name(entry->d_name);
        if (name.size() != 25 || name.compare(0, 5, "code_") != 0 ||
            name.compare(name.size() - 4, 4, ".bin") != 0) continue;
        const std::string hash = name.substr(5, 16);
        if (!valid_hash(hash)) continue;
        const std::string code_path = misses_dir + "/" + name;
        const std::string ctrl_name = "ctrl_" + hash + ".bin";
        const std::string ctrl_path = misses_dir + "/" + ctrl_name;
        struct stat cs{}, ts{};
        if (stat(code_path.c_str(), &cs) != 0 || !S_ISREG(cs.st_mode) || cs.st_size <= 0 ||
            stat(ctrl_path.c_str(), &ts) != 0 || !S_ISREG(ts.st_mode) || ts.st_size < 0x880) continue;
        if (shader_is_cached(cache_dir, hash)) continue;

        std::vector<unsigned char> code, ctrl;
        if (!read_bytes(code_path, code) || !read_bytes(ctrl_path, ctrl) ||
            ctrl.size() < 0x880 || code.size() > (16u << 20)) continue;
        const uint32_t declared = read_le32(ctrl.data() + 0x704);
        if (declared != code.size()) continue;

        Miss miss;
        miss.hash = hash;
        miss.code_name = name;
        miss.ctrl_name = ctrl_name;
        miss.stage = stage_for(code, ctrl);
        miss.code_size = code.size();
        pending.push_back(std::move(miss));
    }
    closedir(dir);

    std::sort(pending.begin(), pending.end(), [](const Miss& a, const Miss& b) {
        return a.hash < b.hash;
    });
    if (pending.empty()) {
        error = "No untranslated shader misses found. The captured shaders are already cached, or you need to boot the game once to capture them.";
        return true;
    }

    std::ostringstream manifest;
    manifest << "id\tstage\tcode_off\tcode_size\tctrl_off\tctrl_size\tprogram_start\tprogram_bytes\tconst_off\tconst_size\tcode_sha1_16\tcode_file\tctrl_file\n";
    for (const Miss& m : pending) {
        std::vector<unsigned char> ctrl;
        if (!read_bytes(misses_dir + "/" + m.ctrl_name, ctrl) || ctrl.size() < 0x880) {
            error = "A captured shader control block became unreadable: " + m.hash;
            return false;
        }
        const uint32_t program_size = read_le32(ctrl.data() + 0x6f8);
        const uint32_t const_size = read_le32(ctrl.data() + 0x6fc);
        const uint32_t const_offset = read_le32(ctrl.data() + 0x700);
        const uint32_t program_start = read_le32(ctrl.data() + 0x708);
        manifest << "ysix/" << m.hash << "/" << m.stage << '\t' << m.stage
                 << "\t0x0\t0x" << std::hex << m.code_size
                 << "\t0x0\t0x880\t0x" << program_start
                 << "\t0x" << program_size << "\t0x" << const_offset
                 << "\t0x" << const_size << '\t' << m.hash
                 << '\t' << m.code_name << '\t' << m.ctrl_name << '\n';
    }
    if (!write_text(misses_dir + "/manifest.tsv", manifest.str())) {
        error = "Could not write shader_misses/manifest.tsv";
        return false;
    }
    return true;
}

bool merge_results(const std::string& pending_dir, const std::string& cache_dir,
                   size_t& merged_count, std::string& error) {
    const std::string fresh_path = pending_dir + "/results.tsv";
    const std::string old_path = cache_dir + "/results.tsv";
    std::ifstream fresh(fresh_path);
    if (!fresh) {
        error = "Translator did not produce results.tsv";
        return false;
    }
    std::string header;
    if (!std::getline(fresh, header) || header.find("resources") == std::string::npos) {
        error = "Translator results.tsv has an unexpected format";
        return false;
    }

    std::vector<std::string> rows;
    std::set<std::string> seen;
    std::string old_header;
    {
        std::ifstream old(old_path);
        if (old && std::getline(old, old_header) && old_header.find("resources") != std::string::npos) {
            header = old_header;
            std::string line;
            while (std::getline(old, line)) {
                std::vector<std::string> cols;
                size_t pos = 0;
                while (true) {
                    const size_t tab = line.find('\t', pos);
                    cols.push_back(line.substr(pos, tab == std::string::npos ? tab : tab - pos));
                    if (tab == std::string::npos) break;
                    pos = tab + 1;
                }
                // Keep only successful cache rows. A previous exception/timeout may have no SPIR-V;
                // retaining it would block a later successful retry for the same shader hash.
                if (cols.size() < 8 || !valid_hash(cols[0]) ||
                    (cols[4] != "ok" && cols[4] != "ok-retry") ||
                    cols[6].empty()) continue;
                char* endp = nullptr;
                const unsigned long bytes = std::strtoul(cols[6].c_str(), &endp, 10);
                if (!endp || *endp != '\0' || bytes == 0 || (bytes % 4) != 0 ||
                    !shader_is_cached(cache_dir, cols[0])) continue;
                if (seen.insert(cols[0]).second) rows.push_back(std::move(line));
            }
        }
    }

    std::string line;
    while (std::getline(fresh, line)) {
        const size_t tab = line.find('\t');
        if (tab == std::string::npos) continue;
        const std::string hash = line.substr(0, tab);
        if (hash.empty()) continue;
        const std::string spv = cache_dir + "/" + hash + ".spv";
        struct stat st{};
        if (stat(spv.c_str(), &st) != 0 || st.st_size <= 0 || (st.st_size % 4) != 0) continue;
        if (seen.insert(hash).second) rows.push_back(line);
        else {
            // Preserve the original cache row; its descriptor/resource metadata is already known-good.
        }
        merged_count++;
    }

    std::ostringstream merged;
    merged << header << '\n';
    for (const std::string& row : rows) merged << row << '\n';
    if (!write_text(old_path, merged.str())) {
        error = "Could not merge shader resource metadata into spirv/results.tsv";
        return false;
    }
    return true;
}

bool load_harness(std::string& error) {
    if (g_harness_main && g_harness_progress) return true;
    g_harness_handle = dlopen("libspirvharness.so", RTLD_NOW);
    if (!g_harness_handle) {
        const char* why = dlerror();
        error = std::string("Shader translator library is unavailable: ") + (why ? why : "unknown dlopen error");
        return false;
    }
    g_harness_main = reinterpret_cast<HarnessMain>(dlsym(g_harness_handle, "spirv_harness_main"));
    g_harness_progress = reinterpret_cast<HarnessProgress>(dlsym(g_harness_handle, "spirv_harness_progress"));
    if (!g_harness_main || !g_harness_progress) {
        error = "Shader translator library is missing the expected NativeAOT entry points";
        return false;
    }
    return true;
}

std::string prepare(const std::string& root, int jobs) {
    std::lock_guard<std::mutex> guard(g_prepare_mutex);
    g_done = 0;
    g_total = 0;
    g_running = true;
    struct RunningReset { ~RunningReset() { g_running = false; } } reset;

    const std::string misses = root + "/shader_misses";
    const std::string cache = root + "/spirv";
    const std::string pending_dir = root + "/spirv.pending";
    if (!ensure_directory(root) || !ensure_directory(cache)) {
        return "Cannot create the Ys IX shader cache folder in app storage.";
    }

    std::vector<Miss> pending;
    std::string error;
    if (!build_manifest(misses, cache, pending, error)) return error;
    if (pending.empty()) return error;

    if (!load_harness(error)) return error;
    remove_tree(pending_dir);
    if (!ensure_directory(pending_dir)) return "Cannot create temporary shader output folder.";

    std::string jobs_arg = std::to_string(std::max(1, std::min(jobs, 3)));
    const char* args[] = {
        "--batch", misses.c_str(),
        "--out", pending_dir.c_str(),
        "--jobs", jobs_arg.c_str(),
        "--no-val"
    };
    const int rc = g_harness_main(static_cast<int>(sizeof(args) / sizeof(args[0])), args);
    if (rc != 0) {
        remove_tree(pending_dir);
        return "Shader translation failed (translator exit code " + std::to_string(rc) +
               "). Keep the captured shader_misses folder and share the native log.";
    }

    size_t copied = 0;
    DIR* dir = opendir(pending_dir.c_str());
    if (!dir) {
        remove_tree(pending_dir);
        return "Translator output folder disappeared.";
    }
    while (dirent* entry = readdir(dir)) {
        const std::string name(entry->d_name);
        if (name.size() < 5 || name.substr(name.size() - 4) != ".spv") continue;
        const std::string from = pending_dir + "/" + name;
        const std::string to = cache + "/" + name;
        if (!copy_file(from, to)) {
            closedir(dir);
            remove_tree(pending_dir);
            return "Could not install translated shader " + name;
        }
        copied++;
    }
    closedir(dir);

    if (copied == 0) {
        remove_tree(pending_dir);
        return "The translator produced no usable SPIR-V files. Keep shader_misses and share the translation summary/log.";
    }

    size_t merged = 0;
    if (!merge_results(pending_dir, cache, merged, error)) {
        remove_tree(pending_dir);
        return error;
    }
    copy_file(pending_dir + "/summary.txt", cache + "/last-translation-summary.txt");
    remove_tree(pending_dir);

    std::ostringstream report;
    report << "Translation complete.\n"
           << "New SPIR-V shaders installed: " << copied << "\n"
           << "Captured misses in this batch: " << pending.size() << "\n"
           << "Resource metadata rows merged: " << merged << "\n"
           << "Shader cache: " << cache << "\n\n"
           << "The raw captures were kept. Boot Ys IX again; if it reaches new scenes, return here and prepare the newly captured misses.";
    return report.str();
}

}  // namespace

extern "C" JNIEXPORT jstring JNICALL
Java_io_github_ysix_launcher_NativeProbe_nativePrepareShaders(JNIEnv* env, jclass, jstring root, jint jobs) {
    const std::string data_root = jstring_utf8(env, root);
    if (data_root.empty()) return env->NewStringUTF("App storage path is unavailable.");
    try {
        const std::string report = prepare(data_root, jobs);
        return env->NewStringUTF(report.c_str());
    } catch (const std::exception& e) {
        const std::string report = std::string("Shader preparation failed: ") + e.what();
        return env->NewStringUTF(report.c_str());
    } catch (...) {
        return env->NewStringUTF("Shader preparation failed with an unknown native error.");
    }
}

extern "C" JNIEXPORT jintArray JNICALL
Java_io_github_ysix_launcher_NativeProbe_shaderProgress(JNIEnv* env, jclass) {
    int done = g_done.load();
    int total = g_total.load();
    if (g_harness_progress && g_running.load()) {
        int translated = 0, count = 0;
        g_harness_progress(&translated, &count);
        done = translated;
        total = count;
    }
    jint values[2] = {done, total};
    jintArray result = env->NewIntArray(2);
    if (result) env->SetIntArrayRegion(result, 0, 2, values);
    return result;
}
