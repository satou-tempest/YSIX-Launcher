#pragma once
#include <sstream>
#include <string>

namespace nxi { class GameImage; }

namespace ysix {
// Performs a bounded NSO/MOD0 audit, maps main + sdk simultaneously as RW/non-executable,
// and applies only safely resolved relocations to temporary mappings. It never enters guest code.
bool native_loader_stage(const nxi::GameImage& game, std::ostringstream& report, std::string& error);
}
