# Runtime integration notes

The v0.7 workflow fetches the pinned MIT-licensed reference repository into the GitHub Actions runner, copies `tools/runtime-bridge/ysix_game.cpp` to `games/ysix/game.cpp`, and executes `patch_p5r_runtime.py` before the NDK build.

The patch script is intentionally fail-closed: each textual precondition must occur exactly once. If the upstream runtime changes, the build should stop instead of silently producing an APK with a partial or incorrect patch.

Patched areas:
- `runtime/src/memory.cpp`: reserve space for four 256 MiB-spaced modules.
- `runtime/src/main.cpp`: load `main`, `sdk`, `subsdk0`, and `subsdk1`; validate the Ys IX title ID and main build ID; pass all four to the shared linker; attempt the extra modules' init arrays after SDK initialization and before main (provisional order).
- `runtime/src/platform_android.cpp`: open launcher-provided SAF URIs from NativeActivity's Intent, duplicate descriptors, and avoid an all-files permission prompt when the game is passed by fd.
- `runtime/src/game_image.cpp`: accept `NX_KEYS_FD` and `NX_TITLE_KEYS_FD` in addition to the reference runtime's path-based key options.

The upstream reference has a NativeActivity entry and a shared Horizon/NVN runtime. The project does not copy the P5R `game.cpp`, launcher or shader patches. The Ys IX `game.cpp` defines the title identity and leaves game-specific hooks empty until log evidence supports specific patches.
