# v0.6 device test plan

## Preparation
- Confirm the host-side synthetic relocation regression step passes in GitHub Actions.
- Build the v0.6 debug APK with GitHub Actions.
- Install on Redmi Turbo 4 and Galaxy A22 5G.
- Re-select the complete Ys IX base-game NSP/XCI and the owner's `prod.keys` (optional `title.keys` if needed).

## Native loader / relocation test
1. Run **Run Loader + GPU Test**.
2. Confirm AES/SHA/CRC self-test and Gate A.
3. Confirm MOD0/dynamic table parsing for both modules.
4. Confirm `main` and `sdk` map simultaneously at their fixed guest addresses. If either mapping fails, retain errno; do not try to force-map over the process.
5. Record export count and every relocation summary in `[SAFE RELOCATION / SYMBOL-RESOLUTION TEST]`.
6. Record temporary writes verified, unresolved strong imports, unresolved import names, unsupported relocation types and link status.
7. Confirm the report says mappings were discarded and no constructors/rtld/nnMain were attempted.
8. Record Vulkan device/API, ASTC/BC7 features and logical-device/graphics-queue result.

## Save archive test (retained from v0.5)
1. Export an archive from an empty workspace; it should contain the explanatory README.
2. Import a test ZIP with nested folders and ordinary files.
3. Export again and verify the archive contents.
4. Test a ZIP with `../` path traversal; import must reject it.
5. These are launcher workspace files, not yet live Ys IX save slots.

## DLC staging test (retained from v0.5)
1. Add one local `.nsp` or `.xci` to the queue.
2. Confirm its document name is shown as `STAGED · NOT INSTALLED`.
3. Restart the app; the persisted reference should remain accessible.
4. Remove staged references and confirm the source package remains untouched.

## Not testable in v0.6
- Full import resolution/Horizon HLE, executable code permissions, NCE entry or game constructors.
- Switch service calls, NVN/Maxwell translation or game rendering.
- Live in-game save/load or DLC activation/mount.
