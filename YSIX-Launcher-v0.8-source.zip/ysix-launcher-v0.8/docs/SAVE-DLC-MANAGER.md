# Save and DLC manager — v0.5 scope

## Save archive workflow

- Save workspace: app-private `files/ysix/save`.
- Import: select a ZIP via Android Storage Access Framework. Entries are extracted to a temporary folder, path-validated, limited to 50,000 entries and 1 GiB expanded data, then merged into the workspace. Files at matching relative paths are replaced; other files remain.
- Export: choose a destination ZIP through Android's create-document picker. The workspace is recursively archived. An empty workspace produces a README explaining that game-generated saves are not available yet.
- Clear: deletes only the app-private workspace after a confirmation dialog.

This is archive management only. The game itself cannot yet read/write the workspace because the title's Horizon filesystem and save-data services are not integrated. The expected future runtime mount must be aligned to this workspace or a migration routine must be added.

## DLC package staging

The user can select `.nsp` / `.xci` files and persist their document references. Multiple packages may be queued and later removed from the queue. The original documents are not copied or modified.

v0.5 does not verify that a selected package belongs to Ys IX, identify rights/content IDs, decrypt or extract NCAs, apply updates, activate DLC, or mount content. These steps must be implemented before the UI can honestly report **Installed**. A future installer should validate title-ID family/content metadata against the base title and keep the game data on-device.
