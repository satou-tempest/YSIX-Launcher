# Ys IX native Android runtime — technical port plan

## Scope

The target is a **game-specific native Android port**, not a general-purpose Nintendo Switch emulator. v0.7 adds the pinned generic ARM64 NCE/Horizon runtime as an experimental boot path. This is not a general-purpose emulator and is not yet a verified Ys IX port: title-specific service, video/movie, module and graphics compatibility still need to be established from real boot logs.

## P5R Android as an architectural reference

The public `p5r-android` project documents a native AArch64 loader, on-demand reading/decryption of NSP/XCI content, a Switch service/runtime layer, NVN-on-Vulkan, and Maxwell-to-SPIR-V shader translation. Its README identifies its upstream runtime as SwitchGamesRecomp / Super Mario Bros. Wonder Recomp and its shader translator as Ryujinx/Ryubing. It is MIT-licensed, but each upstream component and notice must still be reviewed at the exact commit being incorporated.

Reference: https://github.com/Brandon04Gonzalez/p5r-android

## Work packages before any gameplay claim

1. **Game identity / binary reconnaissance**
   - Identify the exact Ys IX Switch title/build ID from the owner's own dump.
   - Inspect ExeFS modules, imports, relocations, SDK version and required system libraries.
   - Build a symbol/import inventory and test small loader probes before attempting a full launch.
   - Do not assume P5R's game-specific patches, service list, shaders or title assumptions apply to Ys IX.

2. **Native execution and loader**
   - Establish ARM64 ABI compatibility and implement executable mapping, relocation, TLS, thread setup, svc traps/stubs and required instruction/system-register adaptations.
   - Verify main/sdk module loading with controlled tests before the game entry point.

3. **Switch service compatibility**
   - Capture the services actually requested by Ys IX and implement only the required subset.
   - Prioritize filesystem, settings, time, applet, input, audio, video, synchronization and display services as observed from the title.
   - Return explicit unsupported-service errors; do not silently fake successful service initialization.

4. **Graphics**
   - Establish the NVN command/resource path and the exact Maxwell shader translation requirements.
   - Implement Vulkan resource, descriptor, synchronization and presentation handling.
   - Validate required texture-compression formats and Vulkan extensions on Mali-G720 and Mali-G57 independently.
   - Do not treat Android's reported Vulkan feature version as proof that the renderer is compatible.

5. **Audio / input / video / saves**
   - Implement the required audio and controller/touch bridges, video decoding path if the title uses hardware video, and per-title save-data layout.

6. **Gameplay acceptance gates**
   - Gate A: title metadata and ExeFS modules can be read and validated from the user's dump.
   - Gate B: loader maps and enters the game's main module without a fatal exception.
   - Gate C: first stable rendered frame.
   - Gate D: title/menu responds to input and audio is initialized.
   - Gate E: a controllable in-game scene loads, runs for at least 10 minutes, and can be exited cleanly.
   - Gate F: save/load is validated.

A version should only be called a gameplay test build after Gate E passes on at least one named device. Compatibility on the second device must be reported separately.

## Known hardware risk

The P5R Android README currently documents successful testing on an Adreno 610 and explicitly says other GPU families, including Mali, are untested. Both project target phones use Mali GPUs. The Redmi Turbo 4 / Mali-G720 is the preferred first hardware target because it has more memory and a newer GPU, but that is a testing priority, not a compatibility guarantee.

## v0.4 / v0.5 / v0.6 status

v0.4 was device-tested on the Galaxy A22 5G (Mali-G57 MC2) and Redmi Turbo 4 (Mali-G720 MC7): both reports showed successful NSP/XCI open/decryption, `main`/`sdk` NSO hash validation, and Vulkan logical-device/graphics-queue initialization. This confirms the diagnostic path and Vulkan device creation only, not real Ys IX rendering.

v0.5 was also tested on both devices. Both passed MOD0/dynamic metadata parsing and temporary fixed-address module staging (Gate B1). The reports show 351 undefined symbols in `main`, 14 in `sdk`, and 59,534 total relocation records across the two modules. These are inventory counts; they do not by themselves mean all imports are unresolved.

v0.6 advances to a safe temporary relocation test. It maps `main` and `sdk` simultaneously as RW/non-executable memory, indexes defined symbols from both modules, applies supported relocation records when a target is known, verifies each temporary write, and discards both mappings. Unresolved strong imports are listed; no fake function addresses are supplied. v0.6 passed B2a on both test phones: 35,880 relative relocations, 22,978 defined-module symbols and 642 cross-module exports were verified; 22 strong movie imports remained unresolved. v0.7 uses those results to attempt the actual generic NCE runtime path. It does not claim that a title screen or gameplay will appear.

The next milestone is to collect the first v0.7 `nx.log` from each device. Verify whether `subsdk0`/`subsdk1` resolve the `movie::*` imports, whether the SDK startup entry is found, and which Horizon service or native instruction fails first. Fix the first concrete blocker before adding more HLE shims. The runtime includes a generic NVN/Vulkan path, but Ys IX-specific rendering and shaders are still unverified.


## v0.7 status — first native boot attempt

The Android app now packages the generic NCE runtime and launches it through NativeActivity. The selected NSP/XCI and keys are passed using duplicated SAF descriptors. The runtime attempts to load `main`, `sdk`, `subsdk0` and `subsdk1`, link them through its Horizon/HLE registry, initialize the guest thread and enter the `nn::init::Start` path. The first `nx.log` is the next source of truth. The 22 previously unresolved `movie::*` references may resolve from the added modules, but this must be confirmed by the actual link summary.

The NVN-to-Vulkan implementation is now present in the binary, but has not been validated with Ys IX's shader format or either Mali device. Save archives are still a private workspace, and DLC references are still only queued.
