# Development roadmap

## v0.1 — Launcher foundation
Completed: Java-only UI, document pickers and saved preferences.

## v0.2 — Visual identity
Completed: gothic adaptive launcher icon patch.

## v0.3 — Launcher frontend
Completed: navigation, library selection, graphics/control preferences and device diagnostics.

## v0.4 — Native bring-up probe
Device-tested on Galaxy A22 5G (Mali-G57 MC2) and Redmi Turbo 4 (Mali-G720 MC7): local Ys IX image open/decryption, ExeFS `main`/`sdk` NSO hash checks, Vulkan instance/device/graphics queue initialization all reported PASS on both devices.

## v0.5 — Native loader staging + content tools
Device-tested on both target phones: MOD0/dynamic/symbol/relocation metadata inspection and temporary `MAP_FIXED_NOREPLACE` staging maps for `main` and `sdk` passed Gate B1. ZIP save archive import/export and a DLC package reference queue were added. Live in-game save-data and DLC mounting remain unimplemented.

## v0.6 — Temporary relocation and symbol-resolution test
Adds simultaneous RW/non-executable mappings for both modules, a defined-symbol export index, application of supported relocations when resolvable inside the `main`/`sdk` scope, and read-back verification. Unresolved strong imports and unsupported relocation types are reported; unresolved addresses are never faked. Both phones later passed Gate B2a.

## v0.7 — Horizon import resolver and NCE bootstrap
Attempts the actual generic NCE runtime startup path, with four Ys IX ExeFS modules loaded and the reference Horizon/HLE + NVN runtime integrated. The Galaxy A22 test showed the runtime reaching NVN frame presentation but failing to execute shader draws because translated SPIR-V programs were absent. The same log showed a later video/movie stall.

## v0.8 — Runtime shader preparation and touch overlay
Adds lazy capture of shaders actually requested by Ys IX, generic Ryujinx Maxwell-to-SPIR-V translation, persistent shader cache and a provisional on-screen Switch layout. This version must be tested on Galaxy A22 5G. The MP4/movie path remains an open blocker.

## Next gates
1. Verify captured shader pairs, translator output and cache hits on the A22.
2. Verify the first NVN draws execute and an actual title/menu appears.
3. Diagnose and fix the observed MP4/movie extraction wait.
4. Verify touch mappings and real menu/game input.
5. Implement remaining Ys IX service imports, file/save behavior, audio, resource formats, and synchronization.
6. Validate a stable playable scene and a clean 10-minute run before claiming gameplay readiness.
