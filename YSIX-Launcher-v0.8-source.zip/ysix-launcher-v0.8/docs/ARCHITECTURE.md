# Architecture notes — v0.6.0

## Current application

- Java UI: Home, Library, Content, Graphics, Controls and Diagnostics.
- JNI bridge: `NativeProbe.java` calls `libysixprobe.so`.
- Android NDK/CMake: `arm64-v8a`, Android API 29+.
- Game image layer: MIT-licensed generic PFS0/HFS0/NCA/NSO importer and crypto from pinned upstream source.
- ExeFS validation: `main` and `sdk` NSO images are decompressed and SHA-256 checked.
- Native loader: bounded MOD0/dynamic/symbol/RELA parsing; simultaneous RW/non-executable fixed-address maps; safe application of supported relocations resolved from the two-module symbol table; read-back verification; mappings discarded.
- GPU probe: Vulkan physical devices, extensions, formats, memory heaps, queue families and logical-device/queue initialization.
- Save manager: ZIP import/export into app-private `files/ysix/save` workspace.
- DLC manager: stores persistent SAF references to selected NSP/XCI files; packages are staged only.

## Native call path

`MainActivity.runNativeProbe()` opens the selected SAF URIs as `ParcelFileDescriptor`s and keeps them alive through the JNI call. C++ runs crypto self-tests, opens the image, validates `main` and `sdk`, parses MOD0 and `.dynamic`, builds an export index, maps both images simultaneously with `MAP_FIXED_NOREPLACE` and `PROT_READ | PROT_WRITE`, applies only supported relocations with a known symbol target, verifies each temporary write, unmaps both images, and probes Vulkan.

## Relocation policy

Supported types in v0.6 are `R_AARCH64_RELATIVE`, `R_AARCH64_ABS64`, `R_AARCH64_GLOB_DAT` and `R_AARCH64_JUMP_SLOT`. Definitions within the current module resolve directly; undefined symbols may resolve through defined exports in `main` or `sdk`; undefined weak symbols resolve to zero. Unresolved strong symbols are recorded with reference counts and left untouched. Unsupported relocation types are counted and skipped. This is a partial two-module link test, not a complete Horizon dynamic linker.

All mapped memory is RW and non-executable. No constructors, rtld functions, `nn::init::Start`, `nnMain` or game code are called.

## Explicitly not implemented

No Horizon/HLE import registry, executable page permissions, guest TLS/thread bootstrap, NCE execution bridge, Switch service compatibility, title-specific SDK hooks, NVN-to-Vulkan command execution, Maxwell shader translation, surface/swapchain or rendering is integrated. Save archives are not live in-game saves until filesystem/save HLE is added. DLC references are not installed content until package verification, extraction, activation and mount logic is added.

## Next technical gates

1. Implement the Ys IX-required unresolved imports as a reviewed HLE/runtime registry.
2. Add the AArch64 NCE entry/return bridge, guest CPU state, TLS, thread setup and abortable bootstrap.
3. Implement observed Ys IX Horizon services.
4. Build the title-specific NVN/resource/shader/presentation path and verify Mali behavior.
5. Connect filesystem/save services to the save workspace and implement verified DLC/update mounting.
6. Validate first frame, controls/audio and stable gameplay.
