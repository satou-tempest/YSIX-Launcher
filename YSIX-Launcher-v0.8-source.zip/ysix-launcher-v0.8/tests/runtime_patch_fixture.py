#!/usr/bin/env python3
"""Exercise every fail-closed upstream-runtime patch against a synthetic pinned-source fixture."""
from __future__ import annotations
import ast
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
PATCHER = ROOT / "tools/runtime-bridge/patch_p5r_runtime.py"


def main() -> None:
    tree = ast.parse(PATCHER.read_text(encoding="utf-8"), filename=str(PATCHER))
    assignments = {target.id: node.value for node in ast.walk(tree)
                   if isinstance(node, ast.Assign)
                   for target in node.targets if isinstance(target, ast.Name)}

    def literal(node):
        if isinstance(node, ast.Name) and node.id in assignments:
            return literal(assignments[node.id])
        return ast.literal_eval(node)

    calls = [n for n in ast.walk(tree) if isinstance(n, ast.Call)
             and isinstance(n.func, ast.Name) and n.func.id == "replace_once"]
    anchors: dict[str, list[str]] = {}
    for call in calls:
        if len(call.args) != 3:
            continue
        path_node = call.args[0]
        if isinstance(path_node, ast.Name) and path_node.id in assignments:
            path_node = assignments[path_node.id]
        dest = ast.unparse(path_node)
        if "runtime/src/" not in dest:
            continue
        old = literal(call.args[1])
        if "runtime/src/memory.cpp" in dest:
            key = "runtime/src/memory.cpp"
        elif "runtime/src/main.cpp" in dest:
            key = "runtime/src/main.cpp"
        elif "runtime/src/platform_android.cpp" in dest:
            key = "runtime/src/platform_android.cpp"
        elif "runtime/src/game_image.cpp" in dest:
            key = "runtime/src/game_image.cpp"
        elif "runtime/src/touch_layout.cpp" in dest:
            key = "runtime/src/touch_layout.cpp"
        else:
            continue
        anchors.setdefault(key, []).append(old)

    if set(anchors) != {
        "runtime/src/memory.cpp", "runtime/src/main.cpp",
        "runtime/src/platform_android.cpp", "runtime/src/game_image.cpp",
        "runtime/src/touch_layout.cpp"
    }:
        raise SystemExit(f"fixture missing patch groups: {sorted(anchors)}")

    with tempfile.TemporaryDirectory(prefix="ysix-runtime-patch-") as temp:
        root = Path(temp) / "p5r"
        for rel, fragments in anchors.items():
            path = root / rel
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text("\n".join(fragments), encoding="utf-8")
        game_source = ROOT / "tools/runtime-bridge/ysix_game.cpp"
        subprocess.run([sys.executable, str(PATCHER), "--root", str(root),
                        "--game-source", str(game_source)], check=True)
        main_cpp = (root / "runtime/src/main.cpp").read_text(encoding="utf-8")
        memory_cpp = (root / "runtime/src/memory.cpp").read_text(encoding="utf-8")
        platform_cpp = (root / "runtime/src/platform_android.cpp").read_text(encoding="utf-8")
        image_cpp = (root / "runtime/src/game_image.cpp").read_text(encoding="utf-8")
        touch_cpp = (root / "runtime/src/touch_layout.cpp").read_text(encoding="utf-8")
        game_cpp = (root / "games/ysix/game.cpp").read_text(encoding="utf-8")
        required = [
            '"subsdk0", "subsdk1"', 'load_modules(mods, 4, "", images)',
            'if (g_subsdk0) init_module(c, *g_subsdk0);',
            'if (g_subsdk1) init_module(c, *g_subsdk1);',
            'Ys IX boot requires the selected NSP/XCI handoff',
        ]
        for item in required:
            assert item in main_cpp, f"main.cpp missing patched feature: {item}"
        assert '0x40000000' in memory_cpp
        assert 'ysix_read_launcher_intent(activity);' in platform_cpp
        assert 'unsetenv("NX_GAME_FD");' in platform_cpp
        assert 'unsetenv("NX_KEYS_FD");' in platform_cpp
        assert 'NX_DUMP_SHADER_MISSES' in platform_cpp
        assert 'const Named kYsIX[]' in touch_cpp
        assert '{"ysix", kYsIX, std::size(kYsIX), true' in touch_cpp
        assert 'NX_KEYS_FD/NX_KEYS' in image_cpp
        assert '0x0100E390124D8000ull' in game_cpp
    print("P5R→Ys IX runtime patch fixture: PASS (four modules, init-array hooks, SAF fd handoff, shader capture, touch layout, title identity)")


if __name__ == "__main__":
    main()
