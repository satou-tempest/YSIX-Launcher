#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
CXX_BIN="${CXX:-c++}"
"$CXX_BIN" -std=c++17 -O2 -Wall -Wextra -Werror \
  -I"$ROOT/tests/support" -I"$ROOT/app/src/main/cpp" \
  "$ROOT/tests/native_loader_test.cpp" \
  "$ROOT/app/src/main/cpp/native_loader.cpp" \
  -o "$TMP/native_loader_test"
"$TMP/native_loader_test"
