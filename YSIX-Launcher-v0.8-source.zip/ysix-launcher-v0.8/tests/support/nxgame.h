#pragma once
#include <cstdint>
#include <map>
#include <string>
#include <vector>
namespace nxi {
class GameImage {
public:
  const std::map<std::string, std::vector<uint8_t>>& exefs() const { return files; }
  std::map<std::string, std::vector<uint8_t>> files;
};
bool nso_to_flat_image(const std::vector<uint8_t>& raw, std::vector<uint8_t>& flat, std::string& error);
}
