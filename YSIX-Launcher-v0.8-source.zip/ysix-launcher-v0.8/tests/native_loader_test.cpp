#include "native_loader.h"
#include "nxgame.h"
#include <cstdint>
#include <cstring>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

namespace nxi {
bool nso_to_flat_image(const std::vector<uint8_t>& raw, std::vector<uint8_t>& flat, std::string&) { flat = raw; return true; }
}

static void w32(std::vector<uint8_t>& v, size_t at, uint32_t x) { std::memcpy(v.data()+at,&x,4); }
static void w64(std::vector<uint8_t>& v, size_t at, uint64_t x) { std::memcpy(v.data()+at,&x,8); }
static void dyn(std::vector<uint8_t>& v, size_t& p, int64_t tag, uint64_t val) { w64(v,p,uint64_t(tag)); w64(v,p+8,val); p+=16; }
static void sym(std::vector<uint8_t>& v, size_t p, uint32_t name, uint8_t info, uint16_t shndx, uint64_t value) {
  w32(v,p,name); std::memcpy(v.data()+p+4,&info,1); std::memcpy(v.data()+p+6,&shndx,2); w64(v,p+8,value); w64(v,p+16,0);
}
static void rela(std::vector<uint8_t>& v, size_t p, uint64_t off, uint32_t type, uint32_t symbol, int64_t addend) {
  w64(v,p,off); w64(v,p+8,(uint64_t(symbol)<<32)|type); w64(v,p+16,uint64_t(addend));
}
static std::vector<uint8_t> make_main() {
  std::vector<uint8_t> v(0x800,0);
  const uint32_t mod0=0x100; w32(v,4,mod0); std::memcpy(v.data()+mod0,"MOD0",4);
  w32(v,mod0+4,0x100); w32(v,mod0+8,0x700); w32(v,mod0+12,0xf00);
  size_t d=0x200;
  dyn(v,d,5,0x398); dyn(v,d,6,0x320); dyn(v,d,10,50); dyn(v,d,11,24);
  dyn(v,d,7,0x500); dyn(v,d,8,120); dyn(v,d,23,0x578); dyn(v,d,2,24); dyn(v,d,0,0);
  // Five symbols: null, a local definition, one SDK import, one missing strong import, one missing weak import.
  sym(v,0x320,0,0,0,0); sym(v,0x338,1,0x12,1,0x600);
  sym(v,0x350,10,0x12,0,0); sym(v,0x368,21,0x12,0,0); sym(v,0x380,32,0x21,0,0);
  const char strings[]="\0local_fn\0sdk_export\0missing_fn\0weak_data\0";
  std::memcpy(v.data()+0x398,strings,sizeof(strings));
  rela(v,0x500,0x700,1027,0,0x600);
  rela(v,0x518,0x708,257,1,8);
  rela(v,0x530,0x710,1025,4,0); // weak import -> zero
  rela(v,0x548,0x718,1026,2,0); // SDK export
  rela(v,0x560,0x728,999,0,0); // unsupported type
  rela(v,0x578,0x720,1026,3,0); // missing strong function
  return v;
}
static std::vector<uint8_t> make_sdk() {
  std::vector<uint8_t> v(0x800,0);
  const uint32_t mod0=0x100; w32(v,4,mod0); std::memcpy(v.data()+mod0,"MOD0",4);
  w32(v,mod0+4,0x100); w32(v,mod0+8,0x700); w32(v,mod0+12,0xf00);
  size_t d=0x200;
  dyn(v,d,5,0x350); dyn(v,d,6,0x320); dyn(v,d,10,16); dyn(v,d,11,24);
  dyn(v,d,7,0x500); dyn(v,d,8,24); dyn(v,d,0,0);
  sym(v,0x320,0,0,0,0); sym(v,0x338,1,0x12,1,0x600);
  const char strings[]="\0sdk_export\0"; std::memcpy(v.data()+0x350,strings,sizeof(strings));
  rela(v,0x500,0x700,1027,0,0x600);
  return v;
}
int main() {
  nxi::GameImage game; game.files["main"]=make_main(); game.files["sdk"]=make_sdk();
  std::ostringstream report; std::string error;
  if (!ysix::native_loader_stage(game,report,error)) { std::cerr<<error<<"\n"<<report.str(); return 1; }
  const std::string r=report.str();
  std::cout<<r;
  if (r.find("Gate B1 (simultaneous module staging): PASS")==std::string::npos) return 2;
  if (r.find("Gate B2a (temporary relocation + symbol-resolution test): PASS")==std::string::npos) return 3;
  if (r.find("Unresolved strong imports skipped: 1 (functions=1, data/other=0)")==std::string::npos) return 4;
  if (r.find("Temporary writes verified: 5")==std::string::npos) return 5;
  if (r.find("missing_fn - 1 relocation(s)")==std::string::npos) return 6;
  if (r.find("Unsupported relocation records skipped: 1")==std::string::npos) return 7;
  return 0;
}
