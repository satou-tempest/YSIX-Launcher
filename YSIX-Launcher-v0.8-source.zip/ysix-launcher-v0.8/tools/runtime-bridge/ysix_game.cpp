// Ys IX: Monstrum Nox game identity for the generic SwitchGamesRecomp runtime.
// This file intentionally contains no Persona 5 Royal-specific hooks or patches.
#include <nx/game.h>

namespace nx::game {

const Info kInfo = {
    "ysix",
    "Ys IX: Monstrum Nox",
    0x0100E390124D8000ull,
    "io.github.ysix.launcher",
    "private/ysix",
    0,
    "E4C423C70D6CCA76F44094710FDE38D4AF1B4F23000000000000000000000000"
};

// Game-specific hooks are deliberately empty in v0.7. The runtime boot is a first-attempt diagnostic;
// game-specific service shims and renderer fixes will be added only after real startup logs identify them.
void after_init() {}
void renderer_start() {}
void first_frame() {}

}  // namespace nx::game
