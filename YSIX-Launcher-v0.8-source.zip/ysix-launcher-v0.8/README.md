# YS IX: Monstrum Nox — Android native runtime experiment v0.8.0

An unofficial, game-specific Android native-port attempt for **Ys IX: Monstrum Nox**. This is not a general-purpose Switch emulator.

> **Status:** v0.8 adds runtime shader-miss capture, an offline Maxwell-to-SPIR-V preparation workflow, and a provisional on-screen Switch control layout. It is still an experimental bring-up build, not a verified playable release.

## What changed in v0.8

- Enables the runtime's existing NVN shader-miss dumper. When a requested shader is absent from the cache, the runtime writes its Maxwell code and NVN control block to the app's private external-files directory.
- Builds the generic Ryujinx/Ryubing Maxwell-to-SPIR-V harness as `libspirvharness.so` with .NET NativeAOT for Android ARM64.
- Adds **PREPARE CAPTURED SHADERS** to the launcher. It scans the runtime's shader captures, generates the generic harness manifest, translates only uncached shader blocks, and merges SPIR-V plus resource-binding metadata into the runtime cache.
- Keeps raw shader captures so the preparation step can be repeated after the game reaches new scenes and discovers more shaders.
- Registers a provisional landscape Switch touch layout for Ys IX: left analogue stick, right-side camera stick, face buttons, shoulder buttons, d-pad, and +/-.
- Fixes the workflow's Vulkan header input by pinning Vulkan-Headers 1.4.357, matching the generated NVN/Vulkan bridge.
- Keeps the v0.7 native runtime, NSP/XCI file-descriptor handoff, device probe, and diagnostics.

## Shader preparation workflow

This is an iterative first-run process, not a prebuilt list of every Ys IX shader:

1. Install v0.8 and select your own complete Ys IX NSP/XCI and `prod.keys` in **Library**.
2. Press **TRY NATIVE BOOT** once. It may still show a black screen; its purpose at this stage is to let the runtime record shader programs that are missing from the SPIR-V cache.
3. Return to the launcher and press **PREPARE CAPTURED SHADERS**. The native Ryujinx shader harness translates the captured Maxwell blocks to SPIR-V and stores them in the runtime cache.
4. Press **TRY NATIVE BOOT** again. If Ys IX reaches new scenes and discovers additional shader programs, return to the launcher and prepare the new captures again.

The runtime cache is stored in the app's external-files directory:
- `shader_misses/` — raw code/control captures, retained for subsequent rounds.
- `spirv/` — translated `.spv` files and the `results.tsv` resource-binding table consumed by NVN.

Only two translation workers are used by default to reduce memory and thermal pressure on the Galaxy A22 5G. The number of Ys IX shaders has not yet been measured; do not assume it will match Persona 5 Royal's roughly 30,000.

## What this build does not promise

- **Playable gameplay is not verified.** A successful APK build or NativeActivity launch is not proof of a rendered title screen.
- The video/movie path observed in the v0.7 Samsung log stalled while waiting for an MP4 stream. v0.8 does not yet implement the missing Ys IX-specific movie/video behavior. Even after shaders translate, that may still block startup.
- The touch layout is a provisional standard Switch layout, not a tested or game-customized control map. The controls are connected to the generic runtime's input bridge, but the game may need mapping adjustments.
- Other Switch services, unresolved imports, NVN features, GPU formats, synchronization, audio, and game-specific initialization may still stop the game.
- Save ZIP import/export remains a local workspace only. It is not connected to live Ys IX save services. The DLC queue still stages references only; it does not install or mount DLC.

## Build with GitHub Actions

Upload these two files to your repository:
- `YSIX-Launcher-v0.8-source.zip` at the repository root.
- `.github/workflows/ysix-v0.8-shader-pipeline.yml` at that exact path.

Then open **Actions → Build YS IX v0.8 Shader Preparation → Run workflow**.

The workflow runs the host-side loader and runtime-patch regression tests, fetches the pinned generic runtime and importer, downloads the Ryubing source at the version used by the reference project's Android harness build, builds the ARM64 NativeAOT shader translator in Docker, builds `libysix.so`, and packages the APK with `libspirvharness.so` and the launcher JNI library.

The expected artifact is `ysix-v0.8-shader-pipeline-debug-apk`.

## Test device and reporting

Use the **Samsung Galaxy A22 5G** as the primary test device for this milestone. The Redmi Turbo 4 is not needed yet.

After installing v0.8:
1. Select the game and keys, if your file references were not retained from v0.7.
2. Run **TRY NATIVE BOOT** once to capture shader misses. Let the screen sit until it stalls, then return to the launcher.
3. Run **PREPARE CAPTURED SHADERS** and wait for the translation report.
4. Try the native boot again. If it reaches farther, repeat shader preparation after new areas expose more missing shaders.
5. Use **VIEW LAST NATIVE BOOT LOG** after each attempt. Share `nx.log` and the shader preparation report if it still fails.

Do not upload your NSP/XCI, keys, decrypted modules, raw shader captures, saves, or DLC files to GitHub or issue reports.

## Third-party source and licenses

The generic runtime/importer is fetched at build time from `Brandon04Gonzalez/p5r-android`, pinned to commit `645c717afbc0610f9da38b0cc1d6834820ffa76a`, under its MIT license.

The Maxwell shader translator is fetched from Ryubing at revision `a82350bb77`, following the build instructions in the reference project. It is compiled into an Android ARM64 NativeAOT library; its MIT license and third-party notices are copied into the APK's `THIRD_PARTY_LICENSES` assets.

Ys IX uses its own game identity and touch layout. The P5R-specific GSC/CPK shader extractor is not reused: v0.8 translates only the shader blocks captured by the generic runtime while Ys IX runs.
