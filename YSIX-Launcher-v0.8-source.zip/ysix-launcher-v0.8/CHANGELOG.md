# Changelog

## 0.8.0 — Shader capture, translation and touch layout
- Enabled capture of missing runtime NVN shaders as raw Maxwell code/control pairs.
- Added the Android ARM64 Ryujinx/Ryubing SPIR-V harness, built with .NET NativeAOT.
- Added iterative shader preparation: build a generic manifest from runtime captures, translate uncached blocks, and merge SPIR-V plus binding metadata into the NVN cache.
- Added a provisional Ys IX Switch touch layout using the runtime's existing overlay/input system.
- Pinned Vulkan-Headers 1.4.357 in the GitHub Actions build to match the generated Vulkan bridge.
- Explicitly documents that the earlier observed MP4/movie stall remains unresolved and gameplay is not yet verified.

## 0.7.0 — Experimental native runtime boot attempt
- Added a NativeActivity entry point backed by a separately built `libysix.so`.
- Integrated the pinned generic ARM64 NCE/Horizon runtime as a build-time dependency; no P5R-specific game patches are used.
- Added SAF URI-to-file-descriptor handoff for the NSP/XCI and keys.
- Extended the runtime to load Ys IX `main`, `sdk`, `subsdk0`, and `subsdk1` at fixed guest bases and try their init arrays in a documented provisional order.
- Added an experimental native boot action and last `nx.log` viewer.
- Kept the v0.6 diagnostic, save workspace, and DLC queue.
- Explicitly marked save and DLC integration as not connected to live game services.

## 0.6.0 — Temporary relocation and symbol-resolution test
- Parsed bounded MOD0 dynamic metadata, symbols, and AArch64 relocation records.
- Tested simultaneous fixed-address staging of main and SDK.
- Applied and verified only safely resolved relocations in disposable RW mappings.
- Added a synthetic relocation regression test.
- Kept save ZIP workspace and DLC reference queue (not live-game integration).
