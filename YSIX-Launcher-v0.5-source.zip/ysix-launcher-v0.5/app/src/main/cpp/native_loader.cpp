#include "native_loader.h"
#include <algorithm>

#include <sys/mman.h>
#include <unistd.h>
#include <cerrno>
#include <cstdint>
#include <cstring>
#include <iomanip>
#include <map>
#include <memory>
#include <sstream>
#include <string>
#include <vector>

#include "nxgame.h"

#ifndef MAP_FIXED_NOREPLACE
// Linux uapi value; supported by modern Android kernels. Unlike MAP_FIXED this never clobbers an existing mapping.
#define MAP_FIXED_NOREPLACE 0x100000
#endif

namespace ysix {
namespace {
constexpr uint64_t kMainBase = 0x4000000000ull;
constexpr uint64_t kSdkBase  = 0x4010000000ull;
constexpr uint64_t kModuleWindow = 0x10000000ull;
constexpr int64_t DT_NULL = 0;
constexpr int64_t DT_PLTRELSZ = 2;
constexpr int64_t DT_STRTAB = 5;
constexpr int64_t DT_SYMTAB = 6;
constexpr int64_t DT_RELA = 7;
constexpr int64_t DT_RELASZ = 8;
constexpr int64_t DT_SYMENT = 11;
constexpr int64_t DT_JMPREL = 23;
constexpr int64_t DT_INIT_ARRAY = 25;
constexpr int64_t DT_FINI_ARRAY = 26;
constexpr int64_t DT_INIT_ARRAYSZ = 27;
constexpr int64_t DT_FINI_ARRAYSZ = 28;

uint32_t u32(const std::vector<uint8_t>& v, uint64_t at, bool& ok) {
    if (at > v.size() || v.size() - size_t(at) < 4) { ok = false; return 0; }
    uint32_t x; std::memcpy(&x, v.data() + at, 4); return x;
}
uint64_t page_up(uint64_t x, uint64_t page) {
    if (x > UINT64_MAX - (page - 1)) return 0;
    return (x + page - 1) & ~(page - 1);
}

struct Mapping {
    void* p = MAP_FAILED;
    size_t n = 0;
    ~Mapping() { if (p != MAP_FAILED) munmap(p, n); }
    bool map_at(uint64_t address, size_t size, std::string& why) {
        p = mmap(reinterpret_cast<void*>(uintptr_t(address)), size, PROT_READ | PROT_WRITE,
                 MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED_NOREPLACE, -1, 0);
        if (p == MAP_FAILED) {
            why = std::string("mmap at 0x") + [&] { std::ostringstream s; s << std::hex << address; return s.str(); }()
                  + " failed: " + std::strerror(errno);
            return false;
        }
        if (uintptr_t(p) != uintptr_t(address)) {
            munmap(p, size); p = MAP_FAILED;
            why = "kernel did not honor the requested non-clobbering fixed mapping";
            return false;
        }
        n = size;
        return true;
    }
};

struct Audit {
    std::string name;
    uint64_t base = 0;
    uint64_t imageSize = 0;
    uint64_t mapSize = 0;
    uint64_t mod0 = 0;
    uint64_t bssStart = 0;
    uint64_t bssEnd = 0;
    uint64_t symCount = 0;
    uint64_t importCount = 0;
    uint64_t relaCount = 0;
    uint64_t pltRelaCount = 0;
    uint64_t initCount = 0;
    uint64_t finiCount = 0;
    std::map<uint32_t, uint64_t> relocTypes;
    std::vector<std::string> importSamples;
    std::vector<uint8_t> image;
};

bool parse_module(const std::vector<uint8_t>& raw, const char* name, uint64_t base,
                  Audit& a, std::string& error) {
    a.name = name; a.base = base;
    if (!nxi::nso_to_flat_image(raw, a.image, error)) {
        error = std::string(name) + ": " + error;
        return false;
    }
    a.imageSize = a.image.size();
    bool ok = true;
    if (a.image.size() < 0x20) { error = std::string(name) + ": decompressed image is too small"; return false; }
    a.mod0 = u32(a.image, 4, ok);
    if (!ok || a.mod0 > a.image.size() || a.image.size() - size_t(a.mod0) < 0x1c ||
        std::memcmp(a.image.data() + a.mod0, "MOD0", 4) != 0) {
        error = std::string(name) + ": MOD0 header is missing or out of range"; return false;
    }
    int32_t rel[5]{};
    for (int i=0; i<5; ++i) {
        uint32_t rawRel = u32(a.image, a.mod0 + 4 + uint64_t(i)*4, ok);
        std::memcpy(&rel[i], &rawRel, sizeof(rawRel));
    }
    if (!ok) { error = std::string(name) + ": truncated MOD0 metadata"; return false; }
    const int64_t dynSigned = int64_t(a.mod0) + int64_t(rel[0]);
    const int64_t bssStartSigned = int64_t(a.mod0) + int64_t(rel[1]);
    const int64_t bssEndSigned = int64_t(a.mod0) + int64_t(rel[2]);
    if (dynSigned < 0 || bssStartSigned < 0 || bssEndSigned < bssStartSigned ||
        uint64_t(dynSigned) >= a.image.size() || uint64_t(bssEndSigned) > kModuleWindow) {
        error = std::string(name) + ": MOD0 dynamic/BSS offsets are invalid"; return false;
    }
    a.bssStart = uint64_t(bssStartSigned); a.bssEnd = uint64_t(bssEndSigned);
    a.mapSize = std::max<uint64_t>(a.imageSize, a.bssEnd);

    std::map<int64_t,uint64_t> dyn;
    const uint64_t dynOff = uint64_t(dynSigned);
    bool terminated = false;
    for (uint64_t p=dynOff, n=0; p <= a.image.size() && a.image.size()-size_t(p) >= 16 && n < 65536; p+=16,++n) {
        int64_t tag; uint64_t value;
        std::memcpy(&tag, a.image.data()+p, 8);
        std::memcpy(&value, a.image.data()+p+8, 8);
        if (tag == DT_NULL) { terminated = true; break; }
        dyn.emplace(tag,value); // preserve first instance, matching the reference loader
    }
    if (!terminated) { error = std::string(name) + ": .dynamic has no bounded DT_NULL terminator"; return false; }
    if (!dyn.count(DT_STRTAB) || !dyn.count(DT_SYMTAB)) {
        error = std::string(name) + ": dynamic symbol/string table tags are missing"; return false;
    }
    const uint64_t strtab=dyn[DT_STRTAB], symtab=dyn[DT_SYMTAB];
    const uint64_t syment=dyn.count(DT_SYMENT) ? dyn[DT_SYMENT] : 24;
    if (syment < 24 || syment > 256 || strtab < symtab || strtab > a.image.size() || symtab > a.image.size()) {
        error = std::string(name) + ": symbol table bounds are invalid"; return false;
    }
    a.symCount=(strtab-symtab)/syment;
    if (a.symCount > 2'000'000) { error = std::string(name) + ": implausible symbol count"; return false; }
    std::vector<std::string> importSamples;
    for (uint64_t i=0;i<a.symCount;i++) {
        uint32_t stName=0; uint16_t shndx=0;
        if (symtab+i*syment+8 > a.image.size()) { error=std::string(name)+": symbol table exceeds module image"; return false; }
        std::memcpy(&stName,a.image.data()+symtab+i*syment,4);
        std::memcpy(&shndx,a.image.data()+symtab+i*syment+6,2);
        if (shndx==0) {
            ++a.importCount;
            if (importSamples.size()<8 && stName < a.image.size()-strtab) {
                const char* nm=reinterpret_cast<const char*>(a.image.data()+strtab+stName);
                size_t remaining=a.image.size()-size_t(strtab+stName);
                size_t len=strnlen(nm,remaining);
                if (len>0 && len<256) importSamples.emplace_back(nm,len);
            }
        }
    }
    auto countRelocs = [&](int64_t startTag, int64_t sizeTag, uint64_t& total)->bool {
        if (!dyn.count(startTag)) return true;
        const uint64_t start=dyn[startTag], bytes=dyn.count(sizeTag)?dyn[sizeTag]:0;
        if (start > a.image.size() || bytes > a.image.size()-start || bytes%24 != 0) return false;
        for (uint64_t p=start;p<start+bytes;p+=24) {
            uint64_t target=0, info=0;
            std::memcpy(&target,a.image.data()+p,8);
            std::memcpy(&info,a.image.data()+p+8,8);
            const uint32_t symbolIndex=uint32_t(info>>32);
            if (target >= kModuleWindow || (symbolIndex != 0 && symbolIndex >= a.symCount)) return false;
            ++a.relocTypes[uint32_t(info)]; ++total;
        }
        return true;
    };
    if (!countRelocs(DT_RELA,DT_RELASZ,a.relaCount) || !countRelocs(DT_JMPREL,DT_PLTRELSZ,a.pltRelaCount)) {
        error = std::string(name) + ": relocation table is out of module bounds"; return false;
    }
    auto arrayCount = [&](int64_t addrTag, int64_t sizeTag, uint64_t& count)->bool {
        if (!dyn.count(addrTag) && !dyn.count(sizeTag)) return true;
        if (!dyn.count(addrTag) || !dyn.count(sizeTag)) return false;
        const uint64_t at=dyn[addrTag], bytes=dyn[sizeTag];
        if (at > a.image.size() || bytes > a.image.size()-at || bytes%8 != 0) return false;
        count=bytes/8; return true;
    };
    if (!arrayCount(DT_INIT_ARRAY,DT_INIT_ARRAYSZ,a.initCount) || !arrayCount(DT_FINI_ARRAY,DT_FINI_ARRAYSZ,a.finiCount)) {
        error = std::string(name) + ": init/fini array bounds are invalid"; return false;
    }
    a.importSamples = std::move(importSamples);
    if (a.mapSize == 0 || a.mapSize > kModuleWindow) { error=std::string(name)+": image exceeds the reserved 256 MiB module window"; return false; }
    return true;
}

bool stage_mapping(const Audit& a, std::string& error) {
    const long pageLong = sysconf(_SC_PAGESIZE);
    if (pageLong <= 0) { error="cannot query Android page size"; return false; }
    const uint64_t page=uint64_t(pageLong);
    const uint64_t size=page_up(a.mapSize,page);
    if (!size || size > SIZE_MAX) { error=a.name+": invalid mapping size"; return false; }
    Mapping m;
    if (!m.map_at(a.base,size_t(size),error)) { error=a.name+": "+error; return false; }
    std::memcpy(m.p,a.image.data(),a.image.size());
    // mmap supplies zero-filled pages; explicitly verify the newly-zero BSS tail before unmapping.
    if (a.bssEnd > a.image.size()) {
        const uint8_t* b=static_cast<const uint8_t*>(m.p)+a.image.size();
        const size_t n=size_t(std::min<uint64_t>(a.bssEnd-a.image.size(),size-a.image.size()));
        for (size_t i=0;i<n;i++) if (b[i]!=0) { error=a.name+": anonymous BSS pages were not zero-filled"; return false; }
    }
    // This is a writable staging map only. No guest instruction is executable in this diagnostic stage.
    return true;
}

void emit_audit(std::ostringstream& out,const Audit& a) {
    out << "  " << a.name << " @ 0x" << std::hex << a.base << std::dec
        << ": image=" << a.imageSize << " bytes, mapped span=" << a.mapSize << " bytes\n";
    out << "    MOD0=" << a.mod0 << ", BSS=[" << a.bssStart << ", " << a.bssEnd << ")\n";
    out << "    symbols=" << a.symCount << ", imported symbols=" << a.importCount
        << ", RELA=" << a.relaCount << ", PLT RELA=" << a.pltRelaCount
        << ", init-array=" << a.initCount << ", fini-array=" << a.finiCount << "\n";
    out << "    relocation types:";
    for (const auto& p:a.relocTypes) out << " R_AARCH64(type=" << p.first << ")=" << p.second;
    if (a.relocTypes.empty()) out << " none";
    out << "\n";
    if (!a.importSamples.empty()) {
        out << "    imported symbol samples:";
        for (const auto& name:a.importSamples) out << " " << name;
        out << "\n";
    }
}
}

bool native_loader_stage(const nxi::GameImage& game, std::ostringstream& report, std::string& error) {
    const auto& exefs=game.exefs();
    auto mainIt=exefs.find("main"), sdkIt=exefs.find("sdk");
    if (mainIt==exefs.end() || sdkIt==exefs.end()) { error="ExeFS main/sdk pair is incomplete"; return false; }
    Audit mainAudit, sdkAudit;
    if (!parse_module(mainIt->second,"main",kMainBase,mainAudit,error)) return false;
    if (!parse_module(sdkIt->second,"sdk",kSdkBase,sdkAudit,error)) return false;
    if (mainAudit.mapSize >= kModuleWindow || sdkAudit.mapSize >= kModuleWindow) {
        error="one or both modules exceed the 256 MiB spacing between their reserved guest bases"; return false;
    }
    report << "\n[NATIVE MODULE LOADER STAGE]\n";
    report << "NSO decompression + segment SHA-256: PASS\n";
    report << "MOD0 + dynamic table parsing: PASS\n";
    emit_audit(report,mainAudit); emit_audit(report,sdkAudit);
    report << "Temporary fixed-address mapping (MAP_FIXED_NOREPLACE, RW staging only):\n";
    std::string why;
    if (!stage_mapping(mainAudit,why)) { report << "  main mapping: FAIL - " << why << "\n"; return false; }
    report << "  main mapping: PASS (copied and unmapped safely)\n";
    if (!stage_mapping(sdkAudit,why)) { report << "  sdk mapping: FAIL - " << why << "\n"; return false; }
    report << "  sdk mapping: PASS (copied and unmapped safely)\n";
    report << "Gate B1 (module metadata + temporary address mapping): PASS\n";
    report << "Relocations applied: NO - import resolver/Horizon HLE not integrated\n";
    report << "Executable page permissions: NOT ENABLED\n";
    report << "Constructors / rtld / nnMain entry: NOT ATTEMPTED\n";
    report << "Gate B2 (link + controlled entry): NOT ATTEMPTED\n";
    report << "Gameplay: NOT BOOTABLE - services and NVN renderer remain unimplemented\n";
    return true;
}
} // namespace ysix
