#pragma once
#include <cstdint>
#include <sstream>
#include <string>
#include <vector>

namespace nxi { class GameImage; }

namespace ysix {
// Audits NSO loader metadata and performs a temporary, non-executable fixed-address mapping.
// It deliberately does not apply relocations or enter game code.
bool native_loader_stage(const nxi::GameImage& game, std::ostringstream& report, std::string& error);
}
