package io.github.ysix.launcher;

/** JNI bridge for v0.5 NSP/ExeFS, native module-loader staging and Vulkan diagnostics. */
public final class NativeProbe {
    static { System.loadLibrary("ysixprobe"); }
    public static native String inspect(int gameFd, String gameName, int prodKeysFd, int titleKeysFd);
    private NativeProbe() { }
}
