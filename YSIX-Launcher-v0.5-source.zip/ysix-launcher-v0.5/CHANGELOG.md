## v0.5.0 — Native loader staging + save/DLC tools
- Added bounded MOD0 and `.dynamic` parsing for ExeFS `main` and `sdk`.
- Added symbol/import and AArch64 RELA/PLT-RELA metadata counts.
- Added temporary `MAP_FIXED_NOREPLACE` staging maps at the runtime reference module bases; maps are RW, never executed, and always unmapped after the test.
- Added ZIP save archive import/export with path traversal and expanded-size limits, using an app-private save workspace.
- Added a persistent DLC NSP/XCI reference queue. It stages only; title matching, install, activation and mounting are not implemented.
- Retained Vulkan device and graphics queue diagnostics.

## v0.4.0 — Native bring-up test
- Added Android NDK/CMake build for an ARM64 JNI shared library (`libysixprobe.so`).
- Integrated the MIT-licensed generic NSP/XCI importer and AES/SHA/CRC self-tests from the pinned P5R Android source.
- Added local package open/decrypt and ExeFS `main`/`sdk` NSO integrity checks.
- Added Vulkan physical-device, feature, format, memory, queue-family, logical-device and queue-idle diagnostics.
- Added an on-device report and logcat output (`YSIX-NATIVE`).
- Explicitly does not attempt game boot, Switch service execution, NVN shader/command translation or gameplay.

## v0.3.0
- Launcher, file references, settings and Java-side diagnostics.
