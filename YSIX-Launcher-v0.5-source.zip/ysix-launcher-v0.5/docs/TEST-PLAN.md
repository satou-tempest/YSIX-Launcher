# v0.5 device test plan

## Preparation
- Build the v0.5 debug APK with GitHub Actions.
- Install on Redmi Turbo 4 and Galaxy A22 5G.
- Re-select the complete Ys IX base-game NSP/XCI and the owner's `prod.keys` (optional `title.keys` if needed).

## Native loader test
1. Run **Run Loader + GPU Test**.
2. Confirm AES/SHA/CRC self-test and Gate A.
3. Record `main`/`sdk` MOD0, BSS, symbol/import counts and RELA/PLT-RELA counts.
4. Record temporary mapping result for each module. If it fails, retain errno and full report; do not attempt to force-map over the process.
5. Record Vulkan device/API, ASTC/BC7 features and logical device/graphics queue result.

## Save archive test
1. Export an archive from an empty workspace; it should contain the explanatory README.
2. Import a test ZIP with nested folders and ordinary files.
3. Export again and verify the archive contents.
4. Test a ZIP with `../` path traversal; import must reject it.
5. Keep in mind these are launcher workspace files, not yet live Ys IX save slots.

## DLC staging test
1. Add one local `.nsp` or `.xci` to the queue.
2. Confirm its document name is shown as `STAGED · NOT INSTALLED`.
3. Restart the app; the persisted reference should remain accessible.
4. Remove staged references and confirm the source package remains untouched.

## Not testable in v0.5
- Relocation/linking and guest code execution.
- Switch service calls, NVN/Maxwell translation or game rendering.
- Live in-game save/load or DLC activation/mount.
