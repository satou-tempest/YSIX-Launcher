# Development roadmap

## v0.1 — Launcher foundation
Completed: Java-only UI, document pickers and saved preferences.

## v0.2 — Visual identity
Completed: gothic adaptive launcher icon patch.

## v0.3 — Launcher frontend
Completed: navigation, library selection, graphics/control preferences and device diagnostics.

## v0.4 — Native bring-up probe
Device-tested on Galaxy A22 5G (Mali-G57 MC2) and Redmi Turbo 4 (Mali-G720 MC7): local Ys IX image open/decryption, ExeFS `main`/`sdk` NSO hash checks, Vulkan instance/device/graphics queue initialization all reported PASS on both devices.

## v0.5 — Native loader staging + content tools
Adds MOD0/dynamic/symbol/relocation metadata inspection and temporary non-clobbering fixed-address `main`/`sdk` mappings. Adds ZIP save archive import/export and a DLC package reference queue. Relocations and game entry remain disabled; save/DLC tools are not yet connected to live in-game storage/content mounting.

## v0.6 — Linker and controlled NCE entry
Next: resolve local/module symbols, inventory unresolved imports by name, apply supported relocations, add HLE thunk framework, guest memory protections, TLS/thread setup and an abortable entry/return harness. Do not invoke `nnMain` until prerequisites are implemented and reviewed.

## v0.7+ — Switch services and graphics
Implement services requested by Ys IX based on logs, then NVN resource/command behavior and Maxwell shader translation. Verify Mali-specific texture format fallbacks, memory usage, synchronization and presentation.

## Gameplay acceptance
First frame, interactive menu, input/audio, stable playable scene, save/load and a clean 10-minute run are separate gates. Do not claim playability until the stable-scene gate passes on at least one named device.
