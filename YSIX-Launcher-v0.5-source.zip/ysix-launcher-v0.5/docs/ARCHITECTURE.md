# Architecture notes — v0.5.0

## Current application

- Java UI: Home, Library, Content, Graphics, Controls and Diagnostics.
- JNI bridge: `NativeProbe.java` calls `libysixprobe.so`.
- Android NDK/CMake: `arm64-v8a`, Android API 29+.
- Game image layer: MIT-licensed generic PFS0/HFS0/NCA/NSO importer and crypto from pinned upstream source.
- ExeFS validation: `main` and `sdk` NSO images are decompressed and SHA-256 checked.
- Native loader stage: MOD0/dynamic/symbol/relocation metadata audit + temporary fixed-address non-clobbering mappings; no relocation or execution.
- GPU probe: Vulkan physical devices, extensions, formats, memory heaps, queue families and logical-device/queue initialization.
- Save manager: ZIP import/export into app-private `files/ysix/save` workspace.
- DLC manager: stores persistent SAF references to selected NSP/XCI files; packages are staged only.

## Native call path

`MainActivity.runNativeProbe()` opens the selected SAF URIs as `ParcelFileDescriptor`s and keeps them alive through the JNI call. C++ runs crypto self-tests, opens the image, validates `main` and `sdk`, parses MOD0 and `.dynamic`, counts symbols/relocations, attempts temporary mappings at `0x4000000000` and `0x4010000000` with `MAP_FIXED_NOREPLACE`, unmaps, then probes Vulkan.

## Explicitly not implemented

No relocation application, import resolver/HLE thunks, executable page permissions, TLS/thread bootstrap, AArch64 NCE entry, Horizon service compatibility, title-specific SDK hooks, NVN-to-Vulkan execution, shader translation, surface/swapchain or rendering is integrated. Save archives are not live in-game saves until filesystem/save HLE is added. DLC references are not installed content until package verification, extraction, activation and mount logic is added.

## Next technical gates

1. Build an import/export symbol report and implement a safe dynamic linker/HLE registry.
2. Add NCE entry/return traps, guest CPU state, TLS, thread setup and minimal kernel behavior.
3. Implement observed Ys IX Horizon services.
4. Build the title-specific NVN/resource/shader/presentation path and verify Mali behavior.
5. Connect filesystem/save services to the save workspace and implement verified DLC/update mounting.
6. Validate first frame, controls/audio and stable gameplay.
