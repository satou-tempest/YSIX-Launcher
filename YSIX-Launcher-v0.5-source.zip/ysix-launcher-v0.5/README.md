# YS IX: Monstrum Nox — Android native bring-up v0.5.0

An unofficial, game-specific Android native-port development project for **Ys IX: Monstrum Nox**. This is not a general-purpose Switch emulator.

> **Status:** v0.5 is a native loader-staging and device-test build, not a playable release. It opens the owner's local game dump, validates NSO images, parses MOD0/dynamic metadata, inventories symbols and relocations, temporarily maps the decompressed `main` and `sdk` images at reserved addresses without clobbering existing mappings, and probes Vulkan. It does not apply relocations, resolve imports, enable executable pages, invoke constructors, enter `nnMain`, render NVN, or boot gameplay.

## v0.5 changes

### Native loader bring-up
- Continues to build `libysixprobe.so` for Android `arm64-v8a` with NDK + CMake.
- Opens the local NSP/XCI and validates the ExeFS `main` and `sdk` NSO segment hashes.
- Parses each module's MOD0 header, `.dynamic` table, symbol table boundaries, imported-symbol count, RELA/PLT-RELA record counts, relocation types, BSS bounds, and init/fini array sizes.
- Attempts temporary non-clobbering mappings at the runtime reference bases (`main` `0x4000000000`, `sdk` `0x4010000000`) using `MAP_FIXED_NOREPLACE`; copies decompressed images, checks zero-filled BSS pages, then unmaps them.
- Does **not** apply relocations or execute guest instructions. A successful mapping is not a successful game load.
- Retains native Vulkan device/graphics-queue diagnostics from v0.4.

### Save manager
- Imports and exports ZIP save archives using Android's document picker.
- Uses a private app workspace at `files/ysix/save`; imports merge into that workspace and replace files with matching paths.
- Rejects unsafe archive paths and enforces archive entry/expanded-size limits.
- **The game runtime does not yet implement Switch filesystem/save services.** This workspace does not become a live in-game save until that integration exists.

### DLC package queue
- Allows selecting one or more local `.nsp` / `.xci` packages and stores persistent Android document references.
- The action is explicitly **staging**, not installation. v0.5 does not validate DLC title-ID relationships, decrypt/extract DLC content, activate content, or mount DLC into Ys IX.
- Source package files are never copied or modified by the queue.

## Target devices

| Device | SoC | GPU | RAM |
|---|---|---|---:|
| Redmi Turbo 4 | MediaTek Dimensity 8400-Ultra | Mali-G720 MC7 | 12 GB |
| Samsung Galaxy A22 5G | MediaTek Dimensity 700 | Mali-G57 MC2 | 8 GB |

The project has received v0.4 device reports from both devices showing successful game-image/NSO validation and Vulkan logical-device initialization. v0.5 must be built and tested separately on each device; module mapping may fail if the target address range is unavailable or conflicts with the process layout.

## Build with GitHub Actions

Upload the following to the repository:
- `YSIX-Launcher-v0.5-source.zip` at the repository root.
- `.github/workflows/ysix-v0.5-native.yml` at that exact path.

Then open **Actions → Build YS IX v0.5 Native Loader → Run workflow**. The workflow fetches the generic importer from the pinned MIT-licensed upstream commit, installs JDK/Android SDK/NDK/CMake, and builds the debug APK. It uploads `ysix-v0.5-native-loader-debug-apk`.

Build requirements: JDK 17, Android Platform 35, Build Tools 35.0.0, NDK `28.2.13676358`, CMake `3.22.1`, Gradle `8.9`, Android Gradle Plugin `8.7.3`.

## Run it

1. Install the v0.5 debug APK from the Actions artifact.
2. In **Library**, select your own complete Ys IX `.nsp` or `.xci`, `prod.keys`, and optional `title.keys` if your NSP requires it.
3. Run **Run Loader + GPU Test** on Home or Diagnostics.
4. Save/copy the complete native loader report. The new section is `[NATIVE MODULE LOADER STAGE]`.
5. Open **Content** to import/export save ZIPs or stage DLC package references.

Do not upload your game image, keys, decrypted modules, save data, or DLC packages to GitHub or issue reports.

## Reading the v0.5 report

- `Gate A PASS`: the native importer opened the game image and the checked `main`/`sdk` NSO segment hashes passed.
- `MOD0 + dynamic table parsing PASS`: structural loader metadata could be read within bounds.
- `Gate B1 PASS`: both decompressed module images were temporarily copied into the reserved address ranges and safely unmapped.
- `Relocations applied: NO`: imports and relocations are only inventoried; the dynamic linker/Horizon HLE registry is not integrated.
- `Gate B2 NOT ATTEMPTED`: there is no guest code entry or constructor invocation in this version.

A B1 failure is still useful diagnostic evidence. Capture the full report from both phones. Do not interpret a successful temporary mapping as proof that the module is ready to execute.

## Remaining work

1. Implement relocation application and an explicit unresolved-import report/registry.
2. Add the ARM64 NCE execution bridge, guest TLS, thread/bootstrap state and controlled entry/return traps.
3. Implement only the Horizon services requested by Ys IX, based on observed calls.
4. Implement the title-specific NVN command/resource path and Maxwell-to-SPIR-V shader translation, then surface/swapchain presentation.
5. Integrate real save-data services and install/activate/mount verified update/DLC content.
6. Validate first frame, input, audio, save/load, and a stable playable scene on target hardware.

## Third-party source

v0.5 uses only the generic content importer/crypto code from the MIT-licensed `Brandon04Gonzalez/p5r-android` repository, pinned to commit `645c717afbc0610f9da38b0cc1d6834820ffa76a`. P5R-specific runtime/game patches are not treated as Ys IX compatibility. See `THIRD_PARTY_NOTICES.md`.
