#!/usr/bin/env python3
"""Patch the pinned, MIT-licensed P5R generic runtime for a first Ys IX NCE boot attempt.

This does not copy or enable Persona 5 Royal game-specific hooks. It adapts the generic runtime's
input handoff, game identity, module list and Android module reservation for Ys IX.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import shutil


def replace_once(path: Path, old: str, new: str) -> None:
    text = path.read_text(encoding="utf-8")
    count = text.count(old)
    if count != 1:
        raise SystemExit(f"patch precondition failed in {path}: expected exactly one occurrence, found {count}: {old[:100]!r}")
    path.write_text(text.replace(old, new), encoding="utf-8")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, type=Path)
    ap.add_argument("--game-source", required=True, type=Path)
    args = ap.parse_args()
    root = args.root.resolve()
    game_dir = root / "games" / "ysix"
    game_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(args.game_source, game_dir / "game.cpp")

    # The generic runtime only draws its touch overlay for games with a registered layout.
    # Add a conventional Switch layout for Ys IX: left stick, right-side camera stick,
    # face buttons, shoulder buttons, d-pad and +/-.
    touch_layout = root / "runtime/src/touch_layout.cpp"
    replace_once(touch_layout,
                 "const Layout kLayouts[] = {",
                 """const Named kYsIX[] = {
    {"A", {0.940f, 0.66f, 0.068f, kA, touch_label(kGlyphA)}},
    {"B", {0.875f, 0.80f, 0.068f, kB, touch_label(kGlyphB)}},
    {"X", {0.875f, 0.52f, 0.068f, kX, touch_label(kGlyphX)}},
    {"Y", {0.810f, 0.66f, 0.068f, kY, touch_label(kGlyphY)}},
    {"R", {0.945f, 0.08f, 0.052f, kR, touch_label(kGlyphR)}},
    {"ZR", {0.945f, 0.24f, 0.052f, kZR, touch_label(kGlyphZ, kGlyphR)}},
    {"L", {0.055f, 0.08f, 0.052f, kL, touch_label(kGlyphL)}},
    {"ZL", {0.055f, 0.24f, 0.052f, kZL, touch_label(kGlyphZ, kGlyphL)}},
    {"MINUS", {0.440f, 0.07f, 0.045f, kMinus, touch_label(kGlyphMinus)}},
    {"PLUS", {0.560f, 0.07f, 0.045f, kPlus, touch_label(kGlyphPlus)}},
    {"UP", {0.135f, 0.31f, 0.048f, kUp, touch_label(kGlyphUp)}},
    {"DOWN", {0.135f, 0.49f, 0.048f, kDown, touch_label(kGlyphDown)}},
    {"LEFT", {0.085f, 0.40f, 0.048f, kLeft, touch_label(kGlyphLeft)}},
    {"RIGHT", {0.185f, 0.40f, 0.048f, kRight, touch_label(kGlyphRight)}},
};

const Layout kLayouts[] = {
    {"ysix", kYsIX, std::size(kYsIX), true, 0, 0.15f, 0.76f},""")

    # Reserve room for main + sdk + subsdk0 + subsdk1, each at a 256 MiB guest stride.
    replace_once(root / "runtime/src/memory.cpp",
                 'reserve(kModuleBase, 0x20000000, "modules");',
                 'reserve(kModuleBase, 0x40000000, "main, sdk, subsdk0 and subsdk1 modules");')

    # Track the extra NSO modules so their init arrays can run after the SDK and before main.
    replace_once(root / "runtime/src/main.cpp",
                 'static const ModuleInfo* g_sdk = nullptr;\n',
                 'static const ModuleInfo* g_sdk = nullptr;\nstatic const ModuleInfo* g_subsdk0 = nullptr;\nstatic const ModuleInfo* g_subsdk1 = nullptr;\n')
    replace_once(root / "runtime/src/main.cpp",
                 '    init_module(c, *g_sdk);\n    init_module(c, *g_main);\n    game::after_init();',
                 '    game::after_init();  // install title-specific hooks before any game-module constructors start workers\n    init_module(c, *g_sdk);\n    if (g_subsdk0) init_module(c, *g_subsdk0);\n    if (g_subsdk1) init_module(c, *g_subsdk1);\n    init_module(c, *g_main);')

    # Main/SDK code, NCE bridge and HLE loader already live in this runtime. Extend its NCE input
    # set to the two title-specific dynamic modules present in the Ys IX ExeFS.
    old_boot = '''    // The player's own ExeFS (main and sdk as they are on the cartridge or in the eShop download): from the game file
    // read in place (game_image.h), else from the data folder's exefs/.
    nce::init();
    static std::unique_ptr<nce::NsoModule> nso[2];
    const std::string exefs = plat::data_root() + "/exefs";
    const char* names[2] = {"main", "sdk"};
    const nxi::GameImage* image = game_image();
    for (int i = 0; i < 2; i++) {
        std::string error;
        const uint64_t base = kModuleBase + uint64_t(i) * 0x10000000;
        if (image) {
            auto it = image->exefs().find(names[i]);
            if (it == image->exefs().end()) fatal("the game file's ExeFS has no %s", names[i]);
            nso[i] = nce::load_nso_bytes(it->second, std::string("ExeFS/") + names[i], names[i], base, error);
        } else {
            nso[i] = nce::load_nso(exefs + "/" + names[i], names[i], base, error);
        }
        if (!nso[i]) fatal("%s (copy the exefs folder of your own dump of the game there)", error.c_str());
    }
    if (const char* want = game::kInfo.main_build_id) {
        std::string have;
        for (uint8_t b : nso[0]->build_id) {
            char hex[3];
            std::snprintf(hex, sizeof hex, "%02X", b);
            have += hex;
        }
        if (have.compare(0, std::strlen(want), want) != 0)
            fatal("exefs/main is build %s, not %s: this port is made for one version of the game (%s)", have.c_str(), want,
                  "copy the exefs of the base game, without the update");
    }
    g_main = &nso[0]->info, g_sdk = &nso[1]->info;
    const ModuleInfo* mods[] = {g_main, g_sdk};
    const uint8_t* images[] = {nso[0]->image.data(), nso[1]->image.data()};
    load_modules(mods, 2, "", images);'''
    new_boot = '''    // Ys IX's own ExeFS: main + sdk + subsdk0 + subsdk1. rtld is replaced by the runtime's
    // nn::init::Start/rtld callbacks; all four actual program modules are loaded and indexed together.
    nce::init();
    static std::unique_ptr<nce::NsoModule> nso[4];
    const std::string exefs = plat::data_root() + "/exefs";
    const char* names[4] = {"main", "sdk", "subsdk0", "subsdk1"};
    const nxi::GameImage* image = game_image();
    if (!image) fatal("Ys IX boot requires the selected NSP/XCI handoff (NX_GAME_FD is missing)");
    if (image->title_id() != game::kInfo.program_id)
        fatal("wrong title ID %016llx (expected %016llx)",
              (unsigned long long)image->title_id(), (unsigned long long)game::kInfo.program_id);
    for (int i = 0; i < 4; i++) {
        std::string error;
        const uint64_t base = kModuleBase + uint64_t(i) * 0x10000000;
        auto it = image->exefs().find(names[i]);
        if (it == image->exefs().end()) fatal("Ys IX ExeFS is missing required module %s", names[i]);
        nso[i] = nce::load_nso_bytes(it->second, std::string("ExeFS/") + names[i], names[i], base, error);
        if (!nso[i]) fatal("cannot parse Ys IX module %s: %s", names[i], error.c_str());
        log("Ys IX module %s parsed: %zu bytes, base %llx", names[i], nso[i]->image.size(),
            (unsigned long long)base);
    }
    if (const char* want = game::kInfo.main_build_id) {
        std::string have;
        for (uint8_t b : nso[0]->build_id) {
            char hex[3];
            std::snprintf(hex, sizeof hex, "%02X", b);
            have += hex;
        }
        if (have.compare(0, std::strlen(want), want) != 0)
            fatal("Ys IX main build ID %s does not match supported base build %s", have.c_str(), want);
    }
    g_main = &nso[0]->info, g_sdk = &nso[1]->info;
    g_subsdk0 = &nso[2]->info, g_subsdk1 = &nso[3]->info;
    const ModuleInfo* mods[4] = {&nso[0]->info, &nso[1]->info, &nso[2]->info, &nso[3]->info};
    const uint8_t* images[4] = {nso[0]->image.data(), nso[1]->image.data(), nso[2]->image.data(), nso[3]->image.data()};
    load_modules(mods, 4, "", images);'''
    replace_once(root / "runtime/src/main.cpp", old_boot, new_boot)
    replace_once(root / "runtime/src/main.cpp",
                 '#include <string>\n',
                 '#include <string>\n#include <vector>\n')

    # v0.9 input diagnostics: distinguish a visible overlay from actual Android event delivery
    # and from the pad state consumed by the guest HID layer.
    input_cpp = root / "runtime/src/platform_android_input.cpp"
    replace_once(input_cpp,
                 "std::mutex g_in;\n",
                 """std::mutex g_in;

bool trace_input_events() {
    static const bool enabled = [] {
        const char* e = std::getenv("NX_TRACE_INPUT");
        return e && e[0] == '1';
    }();
    return enabled;
}
""")
    replace_once(input_cpp,
                 """        uint64_t b = key_to_button(AKeyEvent_getKeyCode(e));
        if (!b) return 0;
""",
                 """        const int32_t key = AKeyEvent_getKeyCode(e);
        uint64_t b = key_to_button(key);
        if (trace_input_events())
            log("input: key action=%d code=%d mapped=%016llx", AKeyEvent_getAction(e), key,
                (unsigned long long)b);
        if (!b) return 0;
""")
    replace_once(input_cpp,
                 """    if (!touch_enabled()) return 0;  // NX_TOUCH_SHOW=0
    int32_t action = AMotionEvent_getAction(e);
    int32_t kind = action & AMOTION_EVENT_ACTION_MASK;
    size_t index = size_t((action & AMOTION_EVENT_ACTION_POINTER_INDEX_MASK) >> AMOTION_EVENT_ACTION_POINTER_INDEX_SHIFT);
""",
                 """    if (!touch_enabled()) {
        if (trace_input_events()) log("input: touchscreen event ignored because NX_TOUCH_SHOW=0");
        return 0;
    }
    int32_t action = AMotionEvent_getAction(e);
    int32_t kind = action & AMOTION_EVENT_ACTION_MASK;
    size_t index = size_t((action & AMOTION_EVENT_ACTION_POINTER_INDEX_MASK) >> AMOTION_EVENT_ACTION_POINTER_INDEX_SHIFT);
    if (trace_input_events() && (kind == AMOTION_EVENT_ACTION_DOWN ||
                                 kind == AMOTION_EVENT_ACTION_POINTER_DOWN ||
                                 kind == AMOTION_EVENT_ACTION_UP ||
                                 kind == AMOTION_EVENT_ACTION_POINTER_UP ||
                                 kind == AMOTION_EVENT_ACTION_CANCEL)) {
        const size_t count = size_t(AMotionEvent_getPointerCount(e));
        const size_t safe_index = count ? std::min(index, count - 1) : 0;
        const float x = count ? AMotionEvent_getX(e, safe_index) : 0.0f;
        const float y = count ? AMotionEvent_getY(e, safe_index) : 0.0f;
        log("input: touch kind=%d pointer=%zu/%zu at %.1f,%.1f", kind, index, count, x, y);
    }
""")
    replace_once(input_cpp,
                 """    input_script(p);  // NX_INPUT_SCRIPT (config.txt): scripted runs on the phone, as on the Mac
""",
                 """    input_script(p);  // NX_INPUT_SCRIPT (config.txt): scripted runs on the phone, as on the Mac
    if (trace_input_events()) {
        static uint64_t last_buttons = ~uint64_t(0);
        static int32_t last_lx = 0x7fffffff, last_ly = 0x7fffffff;
        static int32_t last_rx = 0x7fffffff, last_ry = 0x7fffffff;
        if (p.buttons != last_buttons || p.lx != last_lx || p.ly != last_ly || p.rx != last_rx || p.ry != last_ry) {
            log("input: guest pad buttons=%016llx left=%d,%d right=%d,%d",
                (unsigned long long)p.buttons, p.lx, p.ly, p.rx, p.ry);
            last_buttons = p.buttons, last_lx = p.lx, last_ly = p.ly, last_rx = p.rx, last_ry = p.ry;
        }
    }
""")

    # Rate-limit unresolved-import messages. Keep the first event, but do not let a hot path such as
    # the unresolved WorkBufferBase TLS initializer bury the movie/input diagnostics in nx.log.
    loader = root / "runtime/src/loader.cpp"
    replace_once(loader,
                 "#include <unordered_map>\n#include <vector>\n",
                 "#include <unordered_map>\n#include <unordered_set>\n#include <vector>\n")
    replace_once(loader,
                 """static void missing_stub(CPU& c) {
    // Name comes from the thunk that dispatched here.
    log("missing import called: %s (lr %s) -> 0", t_missing_name, describe(c.x[30]).c_str());
    c.x[0] = 0;
}
""",
                 """static void missing_stub(CPU& c) {
    // Preserve one diagnostic per unresolved function without flooding logs on a hot call path.
    static std::mutex warning_lock;
    static std::unordered_set<std::string> warned;
    const char* name = t_missing_name ? t_missing_name : "<unknown>";
    bool first = false;
    {
        std::lock_guard lk(warning_lock);
        first = warned.insert(name).second;
    }
    if (first) log("missing import first called: %s (lr %s) -> 0", name, describe(c.x[30]).c_str());
    c.x[0] = 0;
}
""")

    # Android NativeActivity opens the SAF URIs handed off by the Java launcher, duplicates their
    # file descriptors and passes only descriptor numbers to the generic game-image reader.
    platform = root / "runtime/src/platform_android.cpp"
    replace_once(platform,
                 'static bool has_data(const std::string& root) { return access((root + kDataProbe).c_str(), R_OK) == 0; }',
                 '''static bool has_data(const std::string& root) {
    const char* game_fd = std::getenv("NX_GAME_FD");
    if (game_fd && *game_fd) return true;  // SAF-backed NSP/XCI is read by descriptor, no all-files permission needed.
    if (std::getenv("NX_BOOT_ERROR")) return true;  // surface a handoff error instead of opening the storage settings page.
    return access((root + kDataProbe).c_str(), R_OK) == 0;
}''')
    activity_old = '''extern "C" JNIEXPORT void ANativeActivity_onCreate(ANativeActivity* activity, void* saved, size_t size) {
    g_activity = activity;
    if (g_ui_pipe[0] < 0 && pipe2(g_ui_pipe, O_NONBLOCK | O_CLOEXEC) == 0)
        ALooper_addFd(ALooper_forThread(), g_ui_pipe[0], ALOOPER_POLL_CALLBACK, ALOOPER_EVENT_INPUT, on_ui_request, nullptr);
    glue_ANativeActivity_onCreate(activity, saved, size);
}'''
    activity_new = '''namespace {
jstring ysix_intent_string(JNIEnv* env, jobject intent, const char* key) {
    jclass cls = env->GetObjectClass(intent);
    jmethodID method = env->GetMethodID(cls, "getStringExtra", "(Ljava/lang/String;)Ljava/lang/String;");
    jstring jkey = env->NewStringUTF(key);
    auto value = method ? static_cast<jstring>(env->CallObjectMethod(intent, method, jkey)) : nullptr;
    env->DeleteLocalRef(jkey);
    if (env->ExceptionCheck()) { env->ExceptionClear(); return nullptr; }
    return value;
}

int ysix_open_uri_fd(JNIEnv* env, jobject resolver, jstring uri_text) {
    if (!uri_text) return -1;
    jclass uri_cls = env->FindClass("android/net/Uri");
    jmethodID parse = env->GetStaticMethodID(uri_cls, "parse", "(Ljava/lang/String;)Landroid/net/Uri;");
    jobject uri = parse ? env->CallStaticObjectMethod(uri_cls, parse, uri_text) : nullptr;
    if (env->ExceptionCheck() || !uri) { env->ExceptionClear(); return -1; }
    jclass resolver_cls = env->GetObjectClass(resolver);
    jmethodID open = env->GetMethodID(resolver_cls, "openFileDescriptor",
            "(Landroid/net/Uri;Ljava/lang/String;)Landroid/os/ParcelFileDescriptor;");
    jstring mode = env->NewStringUTF("r");
    jobject pfd = open ? env->CallObjectMethod(resolver, open, uri, mode) : nullptr;
    env->DeleteLocalRef(mode);
    if (env->ExceptionCheck() || !pfd) { env->ExceptionClear(); return -1; }
    jclass pfd_cls = env->GetObjectClass(pfd);
    jmethodID get_fd = env->GetMethodID(pfd_cls, "getFd", "()I");
    jint raw_fd = get_fd ? env->CallIntMethod(pfd, get_fd) : -1;
    int owned_fd = raw_fd >= 0 ? fcntl(raw_fd, F_DUPFD_CLOEXEC, 0) : -1;
    jmethodID close = env->GetMethodID(pfd_cls, "close", "()V");
    if (close) env->CallVoidMethod(pfd, close);
    if (env->ExceptionCheck()) env->ExceptionClear();
    env->DeleteLocalRef(pfd);
    env->DeleteLocalRef(uri);
    return owned_fd;
}

void ysix_read_launcher_intent(ANativeActivity* activity) {
    // A repeated NativeActivity launch in a reused process must not inherit stale descriptor numbers.
    unsetenv("NX_BOOT_ERROR");
    unsetenv("NX_GAME_FD");
    unsetenv("NX_KEYS_FD");
    unsetenv("NX_TITLE_KEYS_FD");
    unsetenv("NX_GAME_NAME");
    JNIEnv* env = activity->env;
    if (!env) return;
    jclass activity_cls = env->GetObjectClass(activity->clazz);
    jmethodID get_intent = env->GetMethodID(activity_cls, "getIntent", "()Landroid/content/Intent;");
    jobject intent = get_intent ? env->CallObjectMethod(activity->clazz, get_intent) : nullptr;
    if (env->ExceptionCheck() || !intent) { env->ExceptionClear(); setenv("NX_BOOT_ERROR", "NativeActivity has no launch intent", 1); return; }
    jmethodID get_resolver = env->GetMethodID(activity_cls, "getContentResolver", "()Landroid/content/ContentResolver;");
    jobject resolver = get_resolver ? env->CallObjectMethod(activity->clazz, get_resolver) : nullptr;
    if (env->ExceptionCheck() || !resolver) { env->ExceptionClear(); setenv("NX_BOOT_ERROR", "cannot access Android ContentResolver", 1); return; }

    jstring game_uri = ysix_intent_string(env, intent, "ysix.game_uri");
    jstring keys_uri = ysix_intent_string(env, intent, "ysix.keys_uri");
    jstring title_uri = ysix_intent_string(env, intent, "ysix.title_keys_uri");
    jstring game_name = ysix_intent_string(env, intent, "ysix.game_name");
    int game_fd = ysix_open_uri_fd(env, resolver, game_uri);
    int keys_fd = ysix_open_uri_fd(env, resolver, keys_uri);
    int title_fd = ysix_open_uri_fd(env, resolver, title_uri);
    if (game_uri) env->DeleteLocalRef(game_uri);
    if (keys_uri) env->DeleteLocalRef(keys_uri);
    if (title_uri) env->DeleteLocalRef(title_uri);
    if (game_fd < 0 || keys_fd < 0) {
        if (game_fd >= 0) close(game_fd);
        if (keys_fd >= 0) close(keys_fd);
        if (title_fd >= 0) close(title_fd);
        setenv("NX_BOOT_ERROR", "could not open the selected game NSP/XCI or prod.keys URI", 1);
    } else {
        setenv("NX_GAME_FD", std::to_string(game_fd).c_str(), 1);
        setenv("NX_KEYS_FD", std::to_string(keys_fd).c_str(), 1);
        if (title_fd >= 0) setenv("NX_TITLE_KEYS_FD", std::to_string(title_fd).c_str(), 1);
        if (game_name) {
            const char* chars = env->GetStringUTFChars(game_name, nullptr);
            if (chars) { setenv("NX_GAME_NAME", chars, 1); env->ReleaseStringUTFChars(game_name, chars); }
            env->DeleteLocalRef(game_name);
        }
        __android_log_print(ANDROID_LOG_INFO, "ysix", "launcher file descriptors opened; game/key bytes are not logged");
    }
}
}  // namespace

extern "C" JNIEXPORT void ANativeActivity_onCreate(ANativeActivity* activity, void* saved, size_t size) {
    g_activity = activity;
    ysix_read_launcher_intent(activity);
    if (g_ui_pipe[0] < 0 && pipe2(g_ui_pipe, O_NONBLOCK | O_CLOEXEC) == 0)
        ALooper_addFd(ALooper_forThread(), g_ui_pipe[0], ALOOPER_POLL_CALLBACK, ALOOPER_EVENT_INPUT, on_ui_request, nullptr);
    glue_ANativeActivity_onCreate(activity, saved, size);
}'''
    replace_once(platform, activity_old, activity_new)
    replace_once(platform,
                 '''        else
            setenv("NX_HANDHELD", "1", 0);
    }
    // The heap (scudo) zero-fills every allocation''',
                 '''        else
            setenv("NX_HANDHELD", "1", 0);
    }
    // Capture Maxwell code/control blocks whenever a program requests an unavailable shader.
    setenv("NX_DUMP_SHADER_MISSES", "1", 1);
    // The heap (scudo) zero-fills every allocation''')

    # Add a fatal, explicit launch-handoff error before the importer runs.
    game_image = root / "runtime/src/game_image.cpp"
    replace_once(game_image,
                 'void open_image() {\n    const char* fd = std::getenv("NX_GAME_FD");',
                 'void open_image() {\n    if (const char* launch_error = std::getenv("NX_BOOT_ERROR")) fatal("launcher handoff: %s", launch_error);\n    const char* fd = std::getenv("NX_GAME_FD");')
    old_keys = '''    std::vector<int> keys;  // read while opening, then closed
    const char* k = std::getenv("NX_KEYS");
    if (!k || !*k) fatal("game: NX_KEYS (the prod.keys file) is not set");
    if ((keys.emplace_back(open_read(k))) < 0) fatal("game: cannot open the keys file");
    in.push_back({"prod.keys", keys.back()});
    if (const char* t = std::getenv("NX_TITLE_KEYS"); t && *t) {
        int f = open_read(t);
        if (f >= 0) keys.push_back(f), in.push_back({"title.keys", f});
    }'''
    new_keys = '''    std::vector<int> keys;  // read while opening, then closed
    const char* keys_fd = std::getenv("NX_KEYS_FD");
    const char* k = std::getenv("NX_KEYS");
    if (keys_fd && *keys_fd) {
        int f = std::atoi(keys_fd);
        if (f < 0) fatal("game: invalid prod.keys descriptor");
        keys.push_back(f);
    } else {
        if (!k || !*k) fatal("game: NX_KEYS_FD/NX_KEYS (prod.keys) is not set");
        int f = open_read(k);
        if (f < 0) fatal("game: cannot open the keys file");
        keys.push_back(f);
    }
    in.push_back({"prod.keys", keys.back()});
    const char* title_fd = std::getenv("NX_TITLE_KEYS_FD");
    if (title_fd && *title_fd) {
        int f = std::atoi(title_fd);
        if (f >= 0) keys.push_back(f), in.push_back({"title.keys", f});
    } else if (const char* t = std::getenv("NX_TITLE_KEYS"); t && *t) {
        int f = open_read(t);
        if (f >= 0) keys.push_back(f), in.push_back({"title.keys", f});
    }'''
    replace_once(game_image, old_keys, new_keys)

    print("Patched P5R generic runtime for Ys IX native bring-up (NCE, 4 ExeFS modules, SAF FD handoff).")

if __name__ == "__main__":
    main()
