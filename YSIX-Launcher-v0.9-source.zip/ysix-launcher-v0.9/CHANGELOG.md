# Changelog

## v0.9.0 — startup compatibility and input diagnostics

- Adds an opt-in, launcher-controlled movie-source bypass for the specific Ys IX `movie::Extractor::SetDataSource` / `NnExtractor::SetDataSource` path implicated by the Galaxy A22 trace. The hook returns `-ENOSYS` before Android Stagefright attempts to sniff a stream that previously blocked in `NuCachedSource2::readAt`. The bypass is enabled by default for the startup test and may skip startup films or in-game cutscenes; this is not native video playback support.
- Adds an input trace mode that records Android touch/key events and changes in the guest pad state, allowing the next `nx.log` to distinguish visible controls from input actually delivered to the game.
- Rate-limits repeated unresolved-import logs to the first call per symbol. The missing `WorkBufferBase::inUse` TLS initializer remains unresolved; the change only prevents repeated messages from drowning out useful diagnostics.
- Keeps the v0.8 shader-miss capture, Ryujinx SPIR-V preparation, four-module NCE loader and provisional Switch overlay.
- Main-menu boot with responsive input remains unverified.

## v0.8.0 — shader preparation pipeline

- Captures missing Ys IX Maxwell shader blocks at runtime.
- Adds the Ryujinx/Ryubing ARM64 NativeAOT SPIR-V harness and launcher-side shader-cache preparation.
- Adds the initial in-game Switch touch overlay.

## Earlier versions

- v0.7: first NCE runtime bring-up attempt.
- v0.6: temporary native relocation validation.
- v0.5: NSO/MOD0 and module-link inspection.
- v0.4: NSP/ExeFS and Vulkan device probe.
