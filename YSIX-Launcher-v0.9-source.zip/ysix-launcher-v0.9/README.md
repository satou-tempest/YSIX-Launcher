# YS IX: Monstrum Nox — Android native runtime experiment v0.9.0

An unofficial, game-specific Android native-port attempt for **Ys IX: Monstrum Nox**. This is not a general-purpose Switch emulator.

> **Status:** v0.9 adds an experimental bypass for the blocked startup movie-source path observed on the Samsung Galaxy A22 5G, plus input-event diagnostics. The required acceptance milestone is the **Ys IX main menu (New Game / Load Game) with responsive touch input**. That milestone has not yet been verified. A black screen, logo or loading screen does not count as a successful boot.

## What changed in v0.9

- Adds an opt-in hook at the `movie::Extractor::SetDataSource` entry implicated by the v0.8 Samsung trace. If that entry cannot be hooked, the runtime tries the lower `movie::NnExtractor::SetDataSource` entry. The hook returns `-ENOSYS` before Android Stagefright can block while sniffing the MP4 stream.
- The launcher enables the movie bypass by default for this test. It can be disabled under **Controls** to retry the native movie path. The bypass may skip startup films and in-game cutscenes; it is a temporary compatibility experiment, not video decoding support.
- Adds `NX_TRACE_INPUT` diagnostics: raw Android touch/key events and changed guest pad button/stick state are logged to `nx.log`. This lets us determine whether a tap reaches the Android input callback and whether it becomes guest input.
- Rate-limits repeated unresolved-import messages to one per symbol. In particular, the `WorkBufferBase::inUse` TLS initializer is still unresolved; this change does not implement it.
- Retains v0.8 shader-miss capture and the Ryujinx/Ryubing Maxwell-to-SPIR-V preparation process.

## v0.9 test procedure

1. Build and install the v0.9 debug APK on the **Samsung Galaxy A22 5G**. The Redmi Turbo 4 is not required for this milestone.
2. Keep **Bypass blocked movie streams during startup test** enabled under **Controls**.
3. Press **TRY NATIVE BOOT** and give the startup path time to progress. The bypass only works if the runtime successfully installs one of the two known hooks; the log explicitly reports whether that happened.
4. When the game reaches a menu, tap **New Game** or **Load Game**. If taps do not respond, try one face button and the left stick while `NX_TRACE_INPUT` is enabled.
5. Return to the launcher and open **VIEW LAST NATIVE BOOT LOG**. Share the fresh `nx.log`, especially the `ysix/movie:` and `input:` lines.

## How to interpret results

| Observation | Meaning |
|---|---|
| Movie bypass hook installed | The runtime patched one of the two source-opening functions; it has not yet proved the game handles the returned error. |
| `input: touch ...` appears | Android delivered the touchscreen event to the NativeActivity callback. |
| `input: guest pad ...` changes | The generic input layer translated that event into guest button/stick state. |
| Main menu visible and responds to A/B or directional input | **Successful boot milestone achieved.** |

## Known limitations

- **Main-menu boot is not verified.** The movie bypass may be rejected by a different game path, may not be hookable on the tested build, or may cause a game-side error.
- Movie playback is not implemented for this Ys IX path. With the bypass enabled, some videos/cutscenes may be skipped or unavailable. Disable the option to retry native media loading.
- `WorkBufferBase::inUse` still appears as an unresolved function import. Repeated warnings are rate-limited, not resolved.
- The provisional Switch touch layout still needs real-game validation. The new input trace is diagnostic evidence, not proof that every button maps to the game's expectations.
- Additional services, imports, graphics features, shader coverage, synchronization, audio, save and DLC integration may still block startup or gameplay. Save ZIP import/export remains a local workspace; DLC handling stages references only.

## Build with GitHub Actions

Upload these two files to your repository:
- `YSIX-Launcher-v0.9-source.zip` at the repository root.
- `.github/workflows/ysix-v0.9-startup-compatibility.yml` at that exact path.

Then open **Actions → Build YS IX v0.9 Startup Compatibility → Run workflow**. The workflow runs host-side regression/patch-fixture tests, fetches the pinned MIT-licensed generic runtime/importer, builds the Android ARM64 shader harness, patches the runtime for Ys IX, builds `libysix.so`, and assembles the APK. A successful workflow only proves compilation/package success; it does not prove the main-menu milestone.

Expected artifact: `ysix-v0.9-startup-compatibility-debug-apk`.

## Test device and reporting

Use the **Samsung Galaxy A22 5G** for the first v0.9 test. The Redmi Turbo 4 can remain in use by your brother.

Please share the fresh `nx.log` after each attempt. Do not upload your NSP/XCI, keys, decrypted modules, raw shader captures, saves or DLC files to GitHub or issue reports.

## Third-party source and licenses

The generic runtime/importer is fetched at build time from `Brandon04Gonzalez/p5r-android`, pinned to commit `645c717afbc0610f9da38b0cc1d6834820ffa76a`, under its MIT license. The Maxwell shader translator is fetched from Ryubing at revision `a82350bb77` and built as an Android ARM64 NativeAOT library under its MIT license. No game code, game assets, shaders or keys are included in this repository.
