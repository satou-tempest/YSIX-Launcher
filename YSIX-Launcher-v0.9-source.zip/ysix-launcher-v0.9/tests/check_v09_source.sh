#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
python3 -m py_compile "$ROOT/tools/runtime-bridge/patch_p5r_runtime.py" "$ROOT/tests/runtime_patch_fixture.py"
python3 "$ROOT/tests/runtime_patch_fixture.py"
if command -v c++ >/dev/null 2>&1; then
  c++ -std=c++17 -Wall -Wextra -Werror -I"$ROOT/tests/support" -fsyntax-only \
    "$ROOT/tools/runtime-bridge/ysix_game.cpp"
fi
bash "$ROOT/tests/run_native_loader_test.sh"
echo "YS IX v0.9 host-side source checks: PASS"
