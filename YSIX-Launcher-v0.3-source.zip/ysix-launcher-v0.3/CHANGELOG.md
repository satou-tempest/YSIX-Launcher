# Changelog

## 0.3.0-dev — Runtime bring-up frontend

- Reworked navigation into Home, Library, Graphics, Controls and Diagnostics.
- Added gothic adaptive / round / monochrome launcher icon resources.
- Updated application name and version to YS IX: Monstrum Nox / 0.3.0.
- Replaced all v0.1 wording in the UI with current v0.3 runtime status.
- Added game/key document URI reopen checks and clearer access status.
- Added explicit runtime component status indicators.
- Clarified that graphics/control values are saved preferences only until a game runtime is integrated.
- Added native runtime port plan and device test plan.

This is not a playable Ys IX runtime build.
