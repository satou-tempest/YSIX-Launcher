# YS IX: Monstrum Nox — Android project v0.3.0

An unofficial, fan-made Android launcher and runtime bring-up prototype for Ys IX: Monstrum Nox. It includes the gothic launcher icon, redesigned navigation, game/key document selection, persistent URI access checks, saved graphics/control preferences, and local device diagnostics.

> **Important: v0.3.0 is not playable.** This source does not include a Nintendo Switch game runtime, native ARM64 loader, NSP/XCI decryption/parser, Switch service implementation, NVN command translation, Maxwell shader translation, or Ys IX game compatibility layer. `Prepare Game` and `Start Game` provide explicit status explanations rather than claiming to perform those operations.

## Included

- Five-section UI: Home, Library, Graphics, Controls, and Diagnostics.
- Original community-made gothic app icon (adaptive, round, legacy density and monochrome resources).
- Android Storage Access Framework selection for `.nsp` / `.xci` game images and `.keys` files.
- Persistence of document URIs and read-permission grants where supported by the document provider.
- Reopen checks to verify that the selected document reference is still readable; no game/key data is parsed or copied.
- Device diagnostics: model, Android version, ABIs, OpenGL renderer, Android-reported Vulkan feature version, and total RAM.
- Saved graphics and touch-control preferences, clearly marked as preferences not yet connected to a runtime.
- No broad storage or network permission.

## Target devices

| Device | SoC | GPU | RAM |
|---|---|---|---:|
| Redmi Turbo 4 | MediaTek Dimensity 8400-Ultra | Mali-G720 MC7 | 12 GB |
| Samsung Galaxy A22 5G | MediaTek Dimensity 700 | Mali-G57 MC2 | 8 GB |

Both devices are ARM64 Android devices, but that alone does not establish native-port compatibility. Mali Vulkan behavior, compressed texture formats, shader translation and game-specific Switch services still need native runtime work and device testing.

## Build

- JDK 17
- Android SDK Platform 35 and Build Tools 35.0.0
- Android Gradle Plugin 8.7.3
- Gradle 8.9

From the project root, run:

```bash
gradle --no-daemon :app:assembleDebug
```

The debug APK is generated at `app/build/outputs/apk/debug/app-debug.apk`. The debug application ID remains `io.github.ysix.launcher.debug` so it can update an existing debug install made from the same signing key.

## Runtime direction

The intended direction is a game-specific native Android port, not a general-purpose Switch emulator. A P5R-style architecture is a research reference: native AArch64 execution, game-file reading/decryption, Switch service compatibility, NVN-on-Vulkan, and Maxwell shader translation. Those components are not present in this repository. Each must be reviewed, adapted, implemented and tested for Ys IX before gameplay can work. See `docs/RUNTIME-PORT-PLAN.md`.

## Legal / content boundary

This repository contains no Ys IX game files, game code, firmware, encryption keys, save data, shaders or copyrighted assets from the game. Select only game data and keys that you are legally entitled to use. The generated emblem is original fan-made artwork and is not an official Falcom logo.
