# v0.3 device test plan

## What v0.3 is intended to test

- App installs and launches on Android 10+.
- New gothic adaptive launcher icon renders correctly.
- Five-section navigation and scrolling layout behave at different screen sizes.
- NSP/XCI and `.keys` document pickers save URI references.
- Persisted URI grants survive app restarts when the selected document provider supports persistable grants.
- Library screen can reopen the selected document and report read access.
- Graphics and touch preferences persist after app restart.
- Device diagnostics report model, ABI, OpenGL renderer, Android-reported Vulkan feature version and RAM.

## Suggested tests

### Redmi Turbo 4

1. Open Diagnostics and capture the full device/GPU/ABI/Vulkan readout.
2. Select your own Ys IX `.nsp` or `.xci` from internal storage.
3. Select your own `.keys` file.
4. Force-stop and reopen the app; confirm references still show `ACCESS OK`.
5. Change render scale, FPS and touch options; restart and confirm settings persist.
6. Tap Prepare Game and Start Game; verify both explain that the runtime is not integrated. Neither should claim to prepare or launch the game.

### Galaxy A22 5G

Repeat the same steps. Compare renderer, reported Vulkan feature, file access and app stability. Do not assume a setting suitable for the G720 is suitable for the G57.

## Not testable in this build

Game decryption, title metadata parsing, ExeFS loading, CPU execution, Switch services, NVN command processing, shader translation, game rendering, audio, saves and gameplay. Those require the native runtime work described in `RUNTIME-PORT-PLAN.md`.
