# Ys IX native Android runtime — technical port plan

## Scope

The target is a **game-specific native Android port**, not a general-purpose Nintendo Switch emulator. The v0.3 app in this repository is only the frontend and device/file diagnostics. It is not a runtime implementation.

## P5R Android as an architectural reference

The public `p5r-android` project documents a native AArch64 loader, on-demand reading/decryption of NSP/XCI content, a Switch service/runtime layer, NVN-on-Vulkan, and Maxwell-to-SPIR-V shader translation. Its README identifies its upstream runtime as SwitchGamesRecomp / Super Mario Bros. Wonder Recomp and its shader translator as Ryujinx/Ryubing. It is MIT-licensed, but each upstream component and notice must still be reviewed at the exact commit being incorporated.

Reference: https://github.com/Brandon04Gonzalez/p5r-android

## Work packages before any gameplay claim

1. **Game identity / binary reconnaissance**
   - Identify the exact Ys IX Switch title/build ID from the owner's own dump.
   - Inspect ExeFS modules, imports, relocations, SDK version and required system libraries.
   - Build a symbol/import inventory and test small loader probes before attempting a full launch.
   - Do not assume P5R's game-specific patches, service list, shaders or title assumptions apply to Ys IX.

2. **Native execution and loader**
   - Establish ARM64 ABI compatibility and implement executable mapping, relocation, TLS, thread setup, svc traps/stubs and required instruction/system-register adaptations.
   - Verify main/sdk module loading with controlled tests before the game entry point.

3. **Switch service compatibility**
   - Capture the services actually requested by Ys IX and implement only the required subset.
   - Prioritize filesystem, settings, time, applet, input, audio, video, synchronization and display services as observed from the title.
   - Return explicit unsupported-service errors; do not silently fake successful service initialization.

4. **Graphics**
   - Establish the NVN command/resource path and the exact Maxwell shader translation requirements.
   - Implement Vulkan resource, descriptor, synchronization and presentation handling.
   - Validate required texture-compression formats and Vulkan extensions on Mali-G720 and Mali-G57 independently.
   - Do not treat Android's reported Vulkan feature version as proof that the renderer is compatible.

5. **Audio / input / video / saves**
   - Implement the required audio and controller/touch bridges, video decoding path if the title uses hardware video, and per-title save-data layout.

6. **Gameplay acceptance gates**
   - Gate A: title metadata and ExeFS modules can be read and validated from the user's dump.
   - Gate B: loader maps and enters the game's main module without a fatal exception.
   - Gate C: first stable rendered frame.
   - Gate D: title/menu responds to input and audio is initialized.
   - Gate E: a controllable in-game scene loads, runs for at least 10 minutes, and can be exited cleanly.
   - Gate F: save/load is validated.

A version should only be called a gameplay test build after Gate E passes on at least one named device. Compatibility on the second device must be reported separately.

## Known hardware risk

The P5R Android README currently documents successful testing on an Adreno 610 and explicitly says other GPU families, including Mali, are untested. Both project target phones use Mali GPUs. The Redmi Turbo 4 / Mali-G720 is the preferred first hardware target because it has more memory and a newer GPU, but that is a testing priority, not a compatibility guarantee.

## v0.3 status

This repository does not yet contain C/C++ runtime source, an Android NDK/CMake build, a native executable loader, Switch service implementations, NVN translation, or a shader translator. The v0.3 UI therefore keeps Prepare/Start as explanatory actions and labels all runtime subsystems as not integrated.
