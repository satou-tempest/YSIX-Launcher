# Architecture notes — v0.3.0-dev

## Current application

The app is a Java Android frontend with these layers:

- **UI:** Home, Library, Graphics, Controls and Diagnostics pages.
- **Document references:** Android Storage Access Framework URI selection and persisted read grants where supported by the provider.
- **Preferences:** local SharedPreferences for selected URIs and user settings. The preference namespace is intentionally retained from v0.1 so existing selections survive an update.
- **Device queries:** EGL/OpenGL renderer detection, Android-reported Vulkan feature query, ABI/model/OS/RAM reporting.

## Not implemented

There is currently no C/C++ runtime module, Android NDK/CMake build, Switch executable loader, NSP/XCI parser/decryptor, NCE instruction patcher, Switch IPC/service layer, NVN translation, Maxwell shader translator, audio bridge, video bridge, save-data layer or game loop. The UI's Prepare and Start actions are explanatory only.

## Intended native-port boundary

The intended architecture is a game-specific native Android port, not a general-purpose Switch emulator. A future native module should have clearly separated responsibilities:

1. Game image provider and cryptographic/key handling.
2. ExeFS metadata inspection and ARM64 module loader.
3. CPU execution compatibility (NCE) and required trap/stub handling.
4. Switch service compatibility selected from Ys IX's observed imports and runtime requests.
5. NVN command/resource translation into Vulkan.
6. Maxwell shader translation, cache and GPU format capability checks.
7. Android input, audio, video, presentation and save adapters.

No module should be marked implemented until its behavior is exercised with a valid test case. See `RUNTIME-PORT-PLAN.md`.
