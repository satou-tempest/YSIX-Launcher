# Development roadmap

## v0.1 — Launcher foundation

Completed: initial Java-only launcher, Android document pickers, saved settings, basic hardware diagnostics.

## v0.2 — Visual identity

Completed: custom gothic adaptive launcher icon and versioned build workflow. The first v0.2 workflow only overlaid icons and did not replace the old Java placeholder copy; v0.3 corrects that.

## v0.3 — Runtime bring-up frontend

Current release: redesigned Home / Library / Graphics / Controls / Diagnostics UI, explicit runtime status, document URI access rechecks, updated icon and v0.3 copy. This release is not playable.

## v0.4 — Native runtime prototype

Target: establish the native C/C++ Android build, document the exact Ys IX title/build metadata from a lawful user dump, implement loader prototypes and identify the service/import surface. Do not advertise gameplay until the runtime reaches an interactive scene.

## v0.5+ — Game compatibility

Target: implement required Switch services and the NVN/Vulkan + shader path; add Mali-specific compatibility work; validate audio, input, video, saves and sustained gameplay. Milestones should be adjusted based on actual loader and device test results.

See `RUNTIME-PORT-PLAN.md` for implementation gates and `TEST-PLAN.md` for v0.3 device checks.
