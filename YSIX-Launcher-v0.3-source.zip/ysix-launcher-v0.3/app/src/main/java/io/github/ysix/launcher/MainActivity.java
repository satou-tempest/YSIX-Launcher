package io.github.ysix.launcher;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.FeatureInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.opengl.GLES20;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;
import javax.microedition.khronos.egl.EGLSurface;

/**
 * YS IX: Monstrum Nox — v0.3.0 runtime bring-up build.
 *
 * This release improves the launcher, file-reference checks, graphics preferences,
 * and device diagnostics. It does NOT contain the native Switch runtime yet.
 */
public final class MainActivity extends Activity {
    private static final int REQ_GAME = 301;
    private static final int REQ_KEYS = 302;
    private static final String PREFS = "ysix_launcher_v01"; // Preserve existing v0.1/v0.2 selections and preferences.
    private static final String VERSION = "0.3.0-dev";

    private static final int BG = Color.rgb(9, 10, 14);
    private static final int BAR = Color.rgb(13, 14, 20);
    private static final int PANEL = Color.rgb(21, 22, 29);
    private static final int PANEL_ALT = Color.rgb(31, 31, 41);
    private static final int TEXT = Color.rgb(244, 240, 239);
    private static final int MUTED = Color.rgb(163, 160, 169);
    private static final int RED = Color.rgb(190, 49, 61);
    private static final int RED_DARK = Color.rgb(91, 25, 36);
    private static final int GOLD = Color.rgb(211, 174, 113);
    private static final int GREEN = Color.rgb(121, 185, 145);
    private static final int AMBER = Color.rgb(218, 164, 91);

    private SharedPreferences prefs;
    private LinearLayout pageHost;
    private String currentPage = "HOME";
    private String gpuRenderer = "Not reported";
    private String vulkanVersion = "Not reported by Android";
    private String gameName = "No game selected";
    private String keysName = "No key file selected";
    private Uri gameUri;
    private Uri keysUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(BG);
        window.setNavigationBarColor(BG);
        window.getDecorView().setSystemUiVisibility(0);

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        gameName = prefs.getString("game_name", gameName);
        keysName = prefs.getString("keys_name", keysName);
        String savedGame = prefs.getString("game_uri", null);
        String savedKeys = prefs.getString("keys_uri", null);
        if (savedGame != null) gameUri = Uri.parse(savedGame);
        if (savedKeys != null) keysUri = Uri.parse(savedKeys);

        gpuRenderer = detectGlRenderer();
        vulkanVersion = detectVulkanVersion();
        applyDefaultsIfNeeded();
        renderApp();
    }

    private void renderApp() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        if (Build.VERSION.SDK_INT >= 35) {
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                view.setPadding(0, bars.top, 0, bars.bottom);
                return insets;
            });
        }

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setPadding(dp(16), dp(9), dp(16), dp(14));
        pageHost = new LinearLayout(this);
        pageHost.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(pageHost, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(buildNavigation(), new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
        renderPage();
    }

    private View buildNavigation() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER);
        bar.setPadding(dp(6), dp(7), dp(6), dp(8));
        bar.setBackgroundColor(BAR);
        String[][] tabs = {
                {"HOME", "⌂"}, {"LIBRARY", "▤"}, {"GRAPHICS", "◈"},
                {"CONTROLS", "⌘"}, {"DIAGNOSTICS", "⌁"}
        };
        for (String[] tab : tabs) {
            boolean selected = currentPage.equals(tab[0]);
            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.VERTICAL);
            item.setGravity(Gravity.CENTER);
            item.setPadding(dp(2), dp(5), dp(2), dp(5));
            item.setBackground(selected ? rounded(RED_DARK, 12) : rounded(Color.TRANSPARENT, 12));
            TextView glyph = label(tab[1], 17, selected ? TEXT : MUTED);
            glyph.setGravity(Gravity.CENTER);
            TextView name = label(tab[0], 8, selected ? TEXT : MUTED);
            name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            name.setGravity(Gravity.CENTER);
            item.addView(glyph);
            item.addView(name);
            bar.addView(item, new LinearLayout.LayoutParams(0, dp(48), 1f));
            item.setOnClickListener(v -> {
                currentPage = tab[0];
                renderApp();
            });
        }
        return bar;
    }

    private void renderPage() {
        pageHost.removeAllViews();
        addHeader(pageHost);
        switch (currentPage) {
            case "LIBRARY": renderLibrary(pageHost); break;
            case "GRAPHICS": renderGraphics(pageHost); break;
            case "CONTROLS": renderControls(pageHost); break;
            case "DIAGNOSTICS": renderDiagnostics(pageHost); break;
            default: renderHome(pageHost); break;
        }
        TextView footer = label("UNOFFICIAL FAN PROJECT  •  VERSION " + VERSION.toUpperCase(Locale.ROOT), 8, MUTED);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(22), 0, dp(9));
        pageHost.addView(footer);
    }

    private void addHeader(LinearLayout host) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(2), 0, dp(13));

        ImageView emblem = new ImageView(this);
        emblem.setImageResource(R.drawable.ic_launcher_foreground);
        emblem.setScaleType(ImageView.ScaleType.FIT_CENTER);
        row.addView(emblem, new LinearLayout.LayoutParams(dp(45), dp(45)));

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        brand.setPadding(dp(8), 0, 0, 0);
        TextView name = label("YS IX", 20, TEXT);
        name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        TextView sub = label("MONSTRUM NOX  /  ANDROID", 8, MUTED);
        sub.setLetterSpacing(0.12f);
        brand.addView(name);
        brand.addView(sub);
        row.addView(brand, new LinearLayout.LayoutParams(0, -2, 1f));

        TextView version = label("V0.3  •  DEV", 9, GOLD);
        version.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        version.setPadding(dp(10), dp(7), dp(10), dp(7));
        version.setBackground(rounded(Color.rgb(48, 37, 27), 18));
        row.addView(version);
        host.addView(row);
    }

    private void renderHome(LinearLayout host) {
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(18), dp(18), dp(18), dp(18));
        hero.setBackground(gradient(new int[]{Color.rgb(65, 20, 31), Color.rgb(31, 18, 27), Color.rgb(17, 18, 25)}, 20));
        TextView eyebrow = label("THE CITY IS WAITING", 9, GOLD);
        eyebrow.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        eyebrow.setLetterSpacing(0.18f);
        hero.addView(eyebrow);
        TextView title = label("MONSTRUM\nNOX", 31, TEXT);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setLineSpacing(0, 0.98f);
        title.setPadding(0, dp(7), 0, dp(5));
        hero.addView(title);
        hero.addView(label("A dedicated Android project for Ys IX: Monstrum Nox.", 12, Color.rgb(220, 207, 210)));
        TextView state = chip("NATIVE RUNTIME NOT CONNECTED", AMBER);
        LinearLayout.LayoutParams stateLp = new LinearLayout.LayoutParams(-2, -2);
        stateLp.setMargins(0, dp(13), 0, 0);
        hero.addView(state, stateLp);
        host.addView(hero, matchWrap());

        addSection(host, "YOUR GAME", "Your selected files stay on this device. This build only records and checks access to their document references.");
        LinearLayout files = verticalCard();
        files.addView(fileSummary("GAME IMAGE", gameName, gameUri != null && hasReadAccess(gameUri) ? "ACCESS OK" : "NOT READY", () -> { currentPage = "LIBRARY"; renderApp(); }));
        addDivider(files);
        files.addView(fileSummary("PROD.KEYS", keysName, keysUri != null && hasReadAccess(keysUri) ? "ACCESS OK" : "NOT READY", () -> { currentPage = "LIBRARY"; renderApp(); }));
        host.addView(files, matchWrap());

        addSection(host, "RUNTIME", "The app now reports what is and is not available instead of presenting placeholder operations as working features.");
        LinearLayout runtime = verticalCard();
        runtime.addView(statusRow("Game file selection", gameUri != null ? "SELECTED" : "NEEDED", gameUri != null ? GREEN : AMBER));
        runtime.addView(statusRow("Key file selection", keysUri != null ? "SELECTED" : "NEEDED", keysUri != null ? GREEN : AMBER));
        runtime.addView(statusRow("Native ARM64 loader", "NOT INTEGRATED", AMBER));
        runtime.addView(statusRow("Switch system services", "NOT INTEGRATED", AMBER));
        runtime.addView(statusRow("NVN → Vulkan backend", "NOT INTEGRATED", AMBER));
        runtime.addView(statusRow("Ys IX gameplay", "NOT AVAILABLE", AMBER));
        host.addView(runtime, matchWrap());

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button prepare = actionButton("PREPARE GAME", RED_DARK, TEXT);
        Button start = actionButton("START GAME", PANEL_ALT, MUTED);
        prepare.setOnClickListener(v -> showRuntimeNotice("Preparation is not available in v0.3. This build does not decrypt or parse the NSP/XCI, unpack ExeFS, translate shaders, or build the runtime cache. No game data has been modified."));
        start.setOnClickListener(v -> showRuntimeNotice("Ys IX cannot start yet. The native ARM64 loader, required Switch services, game-specific compatibility layer, and NVN-to-Vulkan renderer have not been integrated. This button will be enabled only after a real runtime is included."));
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, dp(48), 1f);
        half.setMargins(0, dp(12), dp(5), 0);
        actions.addView(prepare, half);
        LinearLayout.LayoutParams half2 = new LinearLayout.LayoutParams(0, dp(48), 1f);
        half2.setMargins(dp(5), dp(12), 0, 0);
        actions.addView(start, half2);
        host.addView(actions);

        Button diagnostics = actionButton("OPEN DEVICE DIAGNOSTICS  ›", PANEL, TEXT);
        diagnostics.setOnClickListener(v -> { currentPage = "DIAGNOSTICS"; renderApp(); });
        LinearLayout.LayoutParams dlp = matchWrap();
        dlp.setMargins(0, dp(9), 0, 0);
        host.addView(diagnostics, dlp);

        TextView disclaimer = label("v0.3 is a launcher and runtime bring-up build, not a playable game release. No emulator or game runtime is bundled.", 10, MUTED);
        disclaimer.setPadding(dp(3), dp(13), dp(3), 0);
        host.addView(disclaimer);
    }

    private void renderLibrary(LinearLayout host) {
        addPageIntro(host, "GAME LIBRARY", "Select your own game image and key file. v0.3 checks whether Android can reopen each selected document; it does not read or decrypt their contents.");
        LinearLayout game = verticalCard();
        game.addView(filePickerBlock("GAME IMAGE", "NSP / XCI", gameName, "Choose the Ys IX game image from your device.", () -> chooseFile(REQ_GAME)));
        addDivider(game);
        game.addView(filePickerBlock("PROD.KEYS", "KEY FILE", keysName, "Choose your own prod.keys file. Key contents are not inspected or copied by this build.", () -> chooseFile(REQ_KEYS)));
        host.addView(game, matchWrap());

        addSection(host, "FILE ACCESS", "These checks only confirm that the saved Android document URI can be opened.");
        LinearLayout access = verticalCard();
        access.addView(infoRow("GAME REFERENCE", gameUri == null ? "Not selected" : "Saved"));
        access.addView(infoRow("GAME READ ACCESS", gameUri == null ? "Not checked" : (hasReadAccess(gameUri) ? "Available" : "Unavailable")));
        access.addView(infoRow("KEY REFERENCE", keysUri == null ? "Not selected" : "Saved"));
        access.addView(infoRow("KEY READ ACCESS", keysUri == null ? "Not checked" : (hasReadAccess(keysUri) ? "Available" : "Unavailable")));
        host.addView(access, matchWrap());

        Button recheck = actionButton("RECHECK FILE ACCESS", PANEL_ALT, TEXT);
        recheck.setOnClickListener(v -> {
            boolean gameOk = gameUri != null && hasReadAccess(gameUri);
            boolean keysOk = keysUri != null && hasReadAccess(keysUri);
            Toast.makeText(this, "Game: " + (gameOk ? "accessible" : "not accessible") + " · Keys: " + (keysOk ? "accessible" : "not accessible"), Toast.LENGTH_LONG).show();
            renderApp();
        });
        LinearLayout.LayoutParams rlp = matchWrap(); rlp.setMargins(0, dp(12), 0, 0);
        host.addView(recheck, rlp);

        Button clear = actionButton("CLEAR SELECTED FILE REFERENCES", PANEL, MUTED);
        clear.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Clear file references?")
                .setMessage("This removes the saved document selections from the launcher. It does not delete your game image or key file.")
                .setNegativeButton("CANCEL", null)
                .setPositiveButton("CLEAR", (dialog, which) -> {
                    releasePersistedPermission(gameUri);
                    releasePersistedPermission(keysUri);
                    gameUri = null; keysUri = null;
                    gameName = "No game selected"; keysName = "No key file selected";
                    prefs.edit().remove("game_uri").remove("keys_uri").remove("game_name").remove("keys_name").apply();
                    renderApp();
                }).show());
        LinearLayout.LayoutParams clp = matchWrap(); clp.setMargins(0, dp(8), 0, 0);
        host.addView(clear, clp);
    }

    private void renderGraphics(LinearLayout host) {
        addPageIntro(host, "GRAPHICS", "Saved preferences for future runtime integration. These values do not currently affect Ys IX rendering.");
        LinearLayout profile = verticalCard();
        profile.addView(label("DETECTED GPU PROFILE", 9, GOLD));
        TextView profileName = label(getSuggestedProfile(), 19, TEXT);
        profileName.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        profileName.setPadding(0, dp(5), 0, dp(3));
        profile.addView(profileName);
        profile.addView(label(gpuRenderer, 10, MUTED));
        host.addView(profile, matchWrap());

        LinearLayout settings = verticalCard();
        settings.addView(label("RENDER SCALE", 9, GOLD));
        Spinner scale = spinner(new String[]{"0.5x", "0.75x", "1.0x", "1.25x"}, prefs.getString("scale", suggestedScale()));
        settings.addView(scale, new LinearLayout.LayoutParams(-1, dp(47)));
        scale.setOnItemSelectedListener(simpleSelection(() -> prefs.edit().putString("scale", scale.getSelectedItem().toString()).apply()));
        settings.addView(label("FRAME-RATE TARGET", 9, GOLD));
        Spinner fps = spinner(new String[]{"30 FPS", "60 FPS (experimental)"}, prefs.getString("fps", "30 FPS"));
        settings.addView(fps, new LinearLayout.LayoutParams(-1, dp(47)));
        fps.setOnItemSelectedListener(simpleSelection(() -> prefs.edit().putString("fps", fps.getSelectedItem().toString()).apply()));
        CheckBox shader = checkBox("Shader cache preference", prefs.getBoolean("shader_cache", true));
        CheckBox vsync = checkBox("VSync preference", prefs.getBoolean("vsync", true));
        CheckBox overlay = checkBox("Performance overlay preference", prefs.getBoolean("overlay", true));
        settings.addView(shader); settings.addView(vsync); settings.addView(overlay);
        shader.setOnCheckedChangeListener((b, checked) -> prefs.edit().putBoolean("shader_cache", checked).apply());
        vsync.setOnCheckedChangeListener((b, checked) -> prefs.edit().putBoolean("vsync", checked).apply());
        overlay.setOnCheckedChangeListener((b, checked) -> prefs.edit().putBoolean("overlay", checked).apply());
        host.addView(settings, matchWrap());

        Button reset = actionButton("RESTORE DEVICE SUGGESTIONS", PANEL_ALT, TEXT);
        reset.setOnClickListener(v -> {
            prefs.edit().putString("scale", suggestedScale()).putString("fps", "30 FPS")
                    .putBoolean("shader_cache", true).putBoolean("vsync", true).putBoolean("overlay", true).apply();
            renderApp();
            Toast.makeText(this, "Suggested preferences restored", Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams lp = matchWrap(); lp.setMargins(0, dp(12), 0, 0);
        host.addView(reset, lp);
    }

    private void renderControls(LinearLayout host) {
        addPageIntro(host, "CONTROLS", "Configure the intended touch-control experience. The preview is illustrative until the game input bridge exists.");
        LinearLayout preview = verticalCard();
        preview.addView(label("TOUCH LAYOUT CONCEPT", 9, GOLD));
        LinearLayout stage = new LinearLayout(this);
        stage.setOrientation(LinearLayout.HORIZONTAL);
        stage.setGravity(Gravity.CENTER_VERTICAL);
        stage.setPadding(0, dp(17), 0, dp(17));
        TextView stick = label("◀    ▲\n▼    ▶", 16, TEXT);
        stick.setGravity(Gravity.CENTER);
        stick.setBackground(rounded(Color.rgb(47, 48, 58), 50));
        stage.addView(stick, new LinearLayout.LayoutParams(dp(105), dp(91)));
        View gap = new View(this);
        stage.addView(gap, new LinearLayout.LayoutParams(0, 1, 1f));
        TextView buttons = label("Y     X\nB     A", 16, TEXT);
        buttons.setGravity(Gravity.CENTER);
        buttons.setBackground(rounded(RED_DARK, 50));
        stage.addView(buttons, new LinearLayout.LayoutParams(dp(105), dp(91)));
        preview.addView(stage);
        preview.addView(label("Concept only — no input events are sent to a game in this release.", 10, MUTED));
        host.addView(preview, matchWrap());

        LinearLayout options = verticalCard();
        CheckBox show = checkBox("Show touch controls by default", prefs.getBoolean("touch_controls", true));
        CheckBox haptics = checkBox("Haptic feedback preference", prefs.getBoolean("haptics", false));
        options.addView(show); options.addView(haptics);
        show.setOnCheckedChangeListener((b, checked) -> prefs.edit().putBoolean("touch_controls", checked).apply());
        haptics.setOnCheckedChangeListener((b, checked) -> prefs.edit().putBoolean("haptics", checked).apply());
        host.addView(options, matchWrap());
    }

    private void renderDiagnostics(LinearLayout host) {
        addPageIntro(host, "DEVICE DIAGNOSTICS", "Hardware information is queried locally. A Vulkan feature declaration does not prove that the future renderer will work on this GPU.");
        LinearLayout device = verticalCard();
        device.addView(infoRow("DEVICE", Build.MANUFACTURER + " " + Build.MODEL));
        device.addView(infoRow("CODENAME", Build.DEVICE));
        device.addView(infoRow("ANDROID", Build.VERSION.RELEASE + " / API " + Build.VERSION.SDK_INT));
        device.addView(infoRow("SUPPORTED ABIS", join(Build.SUPPORTED_ABIS)));
        device.addView(infoRow("OPENGL RENDERER", gpuRenderer));
        device.addView(infoRow("VULKAN FEATURE", vulkanVersion));
        device.addView(infoRow("TOTAL RAM", formatRam()));
        device.addView(infoRow("APP VERSION", VERSION));
        host.addView(device, matchWrap());

        addSection(host, "RUNTIME COMPONENTS", "These are explicit integration gates, not inferred hardware capabilities.");
        LinearLayout runtime = verticalCard();
        runtime.addView(statusRow("ARM64 native loader", "NOT INTEGRATED", AMBER));
        runtime.addView(statusRow("NSP / XCI parser + decryption", "NOT INTEGRATED", AMBER));
        runtime.addView(statusRow("Switch service compatibility", "NOT INTEGRATED", AMBER));
        runtime.addView(statusRow("NVN command translation", "NOT INTEGRATED", AMBER));
        runtime.addView(statusRow("Maxwell → SPIR-V shader path", "NOT INTEGRATED", AMBER));
        runtime.addView(statusRow("Mali validation", "NOT TESTED", AMBER));
        host.addView(runtime, matchWrap());

        Button refresh = actionButton("REFRESH DEVICE QUERIES", PANEL_ALT, TEXT);
        refresh.setOnClickListener(v -> {
            gpuRenderer = detectGlRenderer();
            vulkanVersion = detectVulkanVersion();
            renderApp();
            Toast.makeText(this, "Device information refreshed", Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams lp = matchWrap(); lp.setMargins(0, dp(12), 0, 0);
        host.addView(refresh, lp);

        LinearLayout privacy = verticalCard();
        privacy.addView(label("LOCAL DATA / PRIVACY", 9, GOLD));
        privacy.addView(label("No game or key contents are uploaded. The app currently saves only selected document URI references and UI preferences. No networking, camera, microphone, contacts, or location permission is declared.", 11, MUTED));
        LinearLayout.LayoutParams pp = matchWrap(); pp.setMargins(0, dp(10), 0, 0);
        host.addView(privacy, pp);
    }

    private View fileSummary(String title, String value, String status, Runnable click) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        TextView heading = label(title, 8, GOLD);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        TextView file = label(value, 11, TEXT);
        file.setMaxLines(1);
        file.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        left.addView(heading); left.addView(file);
        row.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView badge = chip(status, status.equals("ACCESS OK") ? GREEN : AMBER);
        row.addView(badge);
        row.setPadding(0, dp(5), 0, dp(5));
        row.setOnClickListener(v -> click.run());
        return row;
    }

    private View filePickerBlock(String title, String tag, String value, String description, Runnable click) {
        LinearLayout block = new LinearLayout(this);
        block.setOrientation(LinearLayout.VERTICAL);
        TextView top = label(title + "  /  " + tag, 9, GOLD);
        top.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        block.addView(top);
        TextView file = label(value, 14, TEXT);
        file.setPadding(0, dp(5), 0, dp(4));
        file.setMaxLines(2);
        file.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        block.addView(file);
        block.addView(label(description, 10, MUTED));
        Button choose = actionButton("CHOOSE FILE  ›", RED_DARK, TEXT);
        choose.setOnClickListener(v -> click.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(42));
        lp.setMargins(0, dp(10), 0, 0);
        block.addView(choose, lp);
        return block;
    }

    private View statusRow(String title, String value, int color) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(5), 0, dp(5));
        TextView left = label(title, 10, MUTED);
        TextView right = label(value, 8, color);
        right.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        right.setGravity(Gravity.END);
        row.addView(left, new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(right, new LinearLayout.LayoutParams(-2, -2));
        return row;
    }

    private void addPageIntro(LinearLayout host, String title, String desc) {
        TextView t = label(title, 20, TEXT);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(0, dp(6), 0, dp(5));
        host.addView(t);
        TextView d = label(desc, 11, MUTED);
        d.setLineSpacing(dp(2), 1f);
        d.setPadding(0, 0, 0, dp(14));
        host.addView(d);
    }

    private void addSection(LinearLayout host, String title, String subtitle) {
        TextView t = label(title, 9, GOLD);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setLetterSpacing(0.13f);
        t.setPadding(dp(2), dp(17), 0, dp(4));
        host.addView(t);
        TextView s = label(subtitle, 10, MUTED);
        s.setLineSpacing(dp(1), 1f);
        s.setPadding(dp(2), 0, 0, dp(8));
        host.addView(s);
    }

    private LinearLayout verticalCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        card.setBackground(rounded(PANEL, 16));
        return card;
    }

    private TextView chip(String text, int color) {
        TextView view = label(text, 8, color);
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setLetterSpacing(0.04f);
        view.setPadding(dp(9), dp(7), dp(9), dp(7));
        view.setBackground(rounded(Color.argb(35, Color.red(color), Color.green(color), Color.blue(color)), 18));
        return view;
    }

    private View infoRow(String key, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(6), 0, dp(6));
        TextView left = label(key, 8, MUTED);
        left.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        TextView right = label(value, 10, TEXT);
        right.setGravity(Gravity.END);
        right.setMaxWidth(dp(205));
        right.setMaxLines(3);
        row.addView(left, new LinearLayout.LayoutParams(0, -2, 0.8f));
        row.addView(right, new LinearLayout.LayoutParams(0, -2, 1.2f));
        return row;
    }

    private void addDivider(LinearLayout host) {
        View line = new View(this);
        line.setBackgroundColor(Color.rgb(48, 48, 59));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
        lp.setMargins(0, dp(8), 0, dp(8));
        host.addView(line, lp);
    }

    private TextView label(String text, int size, int color) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setIncludeFontPadding(true);
        return view;
    }

    private Button actionButton(String text, int background, int foreground) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(9);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setTextColor(foreground);
        button.setAllCaps(false);
        button.setMinHeight(dp(42));
        button.setPadding(dp(8), 0, dp(8), 0);
        button.setBackground(rounded(background, 11));
        return button;
    }

    private CheckBox checkBox(String text, boolean checked) {
        CheckBox box = new CheckBox(this);
        box.setText(text);
        box.setTextColor(TEXT);
        box.setTextSize(11);
        box.setButtonTintList(ColorStateList.valueOf(RED));
        box.setChecked(checked);
        return box;
    }

    private Spinner spinner(String[] choices, String selected) {
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, choices) {
            @Override public View getView(int position, View convertView, ViewGroup parent) {
                TextView view = (TextView) super.getView(position, convertView, parent);
                view.setTextColor(TEXT); view.setTextSize(12); view.setPadding(dp(8), dp(4), dp(8), dp(4));
                return view;
            }
            @Override public View getDropDownView(int position, View convertView, ViewGroup parent) {
                TextView view = (TextView) super.getDropDownView(position, convertView, parent);
                view.setTextColor(TEXT); view.setTextSize(12); view.setBackgroundColor(PANEL_ALT);
                view.setPadding(dp(12), dp(12), dp(12), dp(12));
                return view;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setBackground(rounded(PANEL_ALT, 10));
        int index = 0;
        for (int i = 0; i < choices.length; i++) if (choices[i].equals(selected)) index = i;
        spinner.setSelection(index);
        return spinner;
    }

    private AdapterView.OnItemSelectedListener simpleSelection(Runnable action) {
        return new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { action.run(); }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        };
    }

    private void chooseFile(int requestCode) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(intent, requestCode);
        } catch (Exception e) {
            Toast.makeText(this, "No Android document picker is available", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        String displayName = queryDisplayName(uri);
        String lower = displayName.toLowerCase(Locale.ROOT);

        if (requestCode == REQ_GAME) {
            if (!(lower.endsWith(".nsp") || lower.endsWith(".xci"))) {
                showRuntimeNotice("Choose a file with an .nsp or .xci extension. This build does not inspect the file contents.");
                return;
            }
            persistReadPermission(uri, data.getFlags());
            gameUri = uri;
            gameName = displayName;
            prefs.edit().putString("game_uri", uri.toString()).putString("game_name", displayName).apply();
        } else if (requestCode == REQ_KEYS) {
            if (!lower.endsWith(".keys")) {
                showRuntimeNotice("Choose a .keys file (for example prod.keys). This build does not inspect its contents.");
                return;
            }
            persistReadPermission(uri, data.getFlags());
            keysUri = uri;
            keysName = displayName;
            prefs.edit().putString("keys_uri", uri.toString()).putString("keys_name", displayName).apply();
        } else {
            return;
        }

        currentPage = "LIBRARY";
        renderApp();
        boolean readable = hasReadAccess(uri);
        Toast.makeText(this, readable ? "Document reference saved · read access confirmed" : "Reference saved · Android could not confirm read access", Toast.LENGTH_LONG).show();
    }

    private void persistReadPermission(Uri uri, int resultFlags) {
        int takeFlags = resultFlags & Intent.FLAG_GRANT_READ_URI_PERMISSION;
        if (takeFlags == 0) takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION;
        try {
            getContentResolver().takePersistableUriPermission(uri, takeFlags);
        } catch (SecurityException ignored) {
            // Some document providers grant temporary access only.
        }
    }

    private boolean hasReadAccess(Uri uri) {
        if (uri == null) return false;
        try (android.os.ParcelFileDescriptor ignored = getContentResolver().openFileDescriptor(uri, "r")) {
            return ignored != null;
        } catch (Exception e) {
            return false;
        }
    }

    private void releasePersistedPermission(Uri uri) {
        if (uri == null) return;
        try {
            getContentResolver().releasePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) { }
    }

    private String queryDisplayName(Uri uri) {
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) return cursor.getString(index);
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        String last = uri.getLastPathSegment();
        return last == null ? "Selected document" : last;
    }

    private void showRuntimeNotice(String message) {
        new AlertDialog.Builder(this)
                .setTitle("YS IX · RUNTIME STATUS")
                .setMessage(message)
                .setPositiveButton("GOT IT", null)
                .show();
    }

    private String detectGlRenderer() {
        EGL10 egl = null;
        EGLDisplay display = null;
        EGLSurface surface = null;
        EGLContext context = null;
        try {
            egl = (EGL10) EGLContext.getEGL();
            display = egl.eglGetDisplay(EGL10.EGL_DEFAULT_DISPLAY);
            int[] version = new int[2];
            if (display == EGL10.EGL_NO_DISPLAY || !egl.eglInitialize(display, version)) return "Not reported";
            int[] configAttrs = {0x3040, 4, 0x3024, 8, 0x3023, 8, 0x3022, 8, 0x3021, 8, 0x3038};
            EGLConfig[] configs = new EGLConfig[1];
            int[] count = new int[1];
            if (!egl.eglChooseConfig(display, configAttrs, configs, 1, count) || count[0] == 0) return "Not reported";
            int[] surfaceAttrs = {0x3057, 1, 0x3056, 1, 0x3038};
            surface = egl.eglCreatePbufferSurface(display, configs[0], surfaceAttrs);
            int[] contextAttrs = {0x3098, 2, 0x3038};
            context = egl.eglCreateContext(display, configs[0], EGL10.EGL_NO_CONTEXT, contextAttrs);
            if (surface == EGL10.EGL_NO_SURFACE || context == EGL10.EGL_NO_CONTEXT) return "Not reported";
            if (!egl.eglMakeCurrent(display, surface, surface, context)) return "Not reported";
            String renderer = GLES20.glGetString(GLES20.GL_RENDERER);
            return renderer == null ? "Not reported" : renderer;
        } catch (Throwable ignored) {
            return "Not reported";
        } finally {
            try {
                if (egl != null && display != null && display != EGL10.EGL_NO_DISPLAY) {
                    egl.eglMakeCurrent(display, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_CONTEXT);
                    if (context != null && context != EGL10.EGL_NO_CONTEXT) egl.eglDestroyContext(display, context);
                    if (surface != null && surface != EGL10.EGL_NO_SURFACE) egl.eglDestroySurface(display, surface);
                    egl.eglTerminate(display);
                }
            } catch (Throwable ignored) { }
        }
    }

    private String detectVulkanVersion() {
        try {
            PackageManager pm = getPackageManager();
            int version = 0;
            for (FeatureInfo feature : pm.getSystemAvailableFeatures()) {
                if ("android.hardware.vulkan.version".equals(feature.name)) {
                    version = feature.version;
                    break;
                }
            }
            if (version > 0) {
                int major = (version >> 22) & 0x7F;
                int minor = (version >> 12) & 0x3FF;
                return "Reported " + major + "." + minor;
            }
            return pm.hasSystemFeature("android.hardware.vulkan.level") ? "Level feature reported; version unknown" : "Not reported by Android";
        } catch (Exception e) {
            return "Could not query";
        }
    }

    private void applyDefaultsIfNeeded() {
        if (prefs.contains("scale")) return;
        prefs.edit().putString("scale", suggestedScale()).putString("fps", "30 FPS")
                .putBoolean("shader_cache", true).putBoolean("vsync", true).putBoolean("overlay", true)
                .putBoolean("touch_controls", true).putBoolean("haptics", false).apply();
    }

    private String suggestedScale() {
        String gpu = gpuRenderer.toLowerCase(Locale.ROOT);
        if (gpu.contains("g720")) return "1.0x";
        if (gpu.contains("g57")) return "0.5x";
        return "0.75x";
    }

    private String getSuggestedProfile() {
        String gpu = gpuRenderer.toLowerCase(Locale.ROOT);
        if (gpu.contains("g720")) return "Mali G720 · Balanced";
        if (gpu.contains("g57")) return "Mali G57 · Low-load";
        if (gpu.contains("mali")) return "Mali · Compatibility";
        return "Automatic · Compatibility";
    }

    private String formatRam() {
        try {
            ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo info = new ActivityManager.MemoryInfo();
            manager.getMemoryInfo(info);
            return String.format(Locale.US, "%.1f GB", info.totalMem / 1073741824.0);
        } catch (Exception e) {
            return "Not reported";
        }
    }

    private String join(String[] values) {
        if (values == null || values.length == 0) return "Not reported";
        StringBuilder out = new StringBuilder();
        for (String value : values) {
            if (out.length() > 0) out.append(", ");
            out.append(value);
        }
        return out.toString();
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        return drawable;
    }

    private GradientDrawable gradient(int[] colors, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
        drawable.setCornerRadius(dp(radiusDp));
        drawable.setStroke(dp(1), Color.rgb(87, 47, 56));
        return drawable;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
