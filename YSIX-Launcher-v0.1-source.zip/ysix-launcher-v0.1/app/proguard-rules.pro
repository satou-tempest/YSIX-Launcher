# v0.1 uses platform Android APIs only. Add keep rules when native runtime bindings are introduced.
