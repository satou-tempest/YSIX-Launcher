package io.github.ysix.launcher;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.FeatureInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Insets;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.egl.EGLDisplay;
import javax.microedition.khronos.egl.EGLSurface;
import android.opengl.GLES20;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/**
 * YS IX Launcher v0.1
 *
 * This is an independent Android launcher/configuration prototype. It does not
 * include Nintendo Switch emulation, decryption, game extraction, or game execution.
 */
public final class MainActivity extends Activity {
    private static final int REQ_GAME = 101;
    private static final int REQ_KEYS = 102;
    private static final String PREFS = "ysix_launcher_v01";

    private static final int BG = Color.rgb(9, 10, 14);
    private static final int PANEL = Color.rgb(20, 21, 28);
    private static final int PANEL_ALT = Color.rgb(27, 28, 37);
    private static final int TEXT = Color.rgb(242, 239, 238);
    private static final int MUTED = Color.rgb(159, 158, 168);
    private static final int RED = Color.rgb(190, 49, 61);
    private static final int RED_DARK = Color.rgb(105, 25, 36);
    private static final int GOLD = Color.rgb(207, 166, 103);
    private static final int GREEN = Color.rgb(112, 184, 137);

    private SharedPreferences prefs;
    private LinearLayout pageHost;
    private String currentPage = "HOME";
    private String gpuRenderer = "Not reported";
    private String vulkanVersion = "Not reported by Android";
    private String gameName;
    private String keysName;
    private Uri gameUri;
    private Uri keysUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(BG);
        window.setNavigationBarColor(BG);
        window.getDecorView().setSystemUiVisibility(0);

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        gameName = prefs.getString("game_name", "No game selected");
        keysName = prefs.getString("keys_name", "No key file selected");
        String savedGameUri = prefs.getString("game_uri", null);
        String savedKeysUri = prefs.getString("keys_uri", null);
        if (savedGameUri != null) gameUri = Uri.parse(savedGameUri);
        if (savedKeysUri != null) keysUri = Uri.parse(savedKeysUri);

        gpuRenderer = detectGlRenderer();
        vulkanVersion = detectVulkanVersion();
        applyAutomaticDefaultsIfNeeded();
        renderApp();
    }

    private void renderApp() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        // Android 15 enforces edge-to-edge for apps targeting API 35.
        if (Build.VERSION.SDK_INT >= 35) {
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                view.setPadding(0, bars.top, 0, bars.bottom);
                return insets;
            });
        }

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setPadding(dp(16), dp(10), dp(16), dp(14));
        pageHost = new LinearLayout(this);
        pageHost.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(pageHost, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(buildNavigation(), new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
        renderPage();
    }

    private View buildNavigation() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER);
        bar.setPadding(dp(8), dp(8), dp(8), dp(9));
        bar.setBackgroundColor(Color.rgb(14, 15, 21));
        String[] pages = {"HOME", "GRAPHICS", "CONTROLS", "SYSTEM"};
        for (String page : pages) {
            TextView item = new TextView(this);
            item.setText(page);
            item.setTextSize(10);
            item.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
            item.setGravity(Gravity.CENTER);
            item.setTextColor(currentPage.equals(page) ? TEXT : MUTED);
            item.setPadding(dp(5), dp(11), dp(5), dp(11));
            item.setBackground(currentPage.equals(page) ? rounded(RED_DARK, 12) : rounded(Color.TRANSPARENT, 12));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(40), 1f);
            lp.setMargins(dp(3), 0, dp(3), 0);
            bar.addView(item, lp);
            item.setOnClickListener(v -> {
                currentPage = page;
                renderApp();
            });
        }
        return bar;
    }

    private void renderPage() {
        pageHost.removeAllViews();
        addHeader(pageHost);
        switch (currentPage) {
            case "GRAPHICS": renderGraphics(pageHost); break;
            case "CONTROLS": renderControls(pageHost); break;
            case "SYSTEM": renderSystem(pageHost); break;
            default: renderHome(pageHost); break;
        }
        TextView footer = label("UNOFFICIAL COMMUNITY PROJECT  •  LAUNCHER PROTOTYPE", 9, MUTED);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(22), 0, dp(8));
        pageHost.addView(footer);
    }

    private void addHeader(LinearLayout host) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(4), 0, dp(16));
        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        TextView name = label("YS IX", 24, TEXT);
        name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        TextView sub = label("MONSTRUM NOX  /  ANDROID PROJECT", 9, MUTED);
        sub.setLetterSpacing(0.12f);
        brand.addView(name);
        brand.addView(sub);
        row.addView(brand, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView version = label("V0.1  •  DEV BUILD", 10, GOLD);
        version.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        version.setPadding(dp(10), dp(7), dp(10), dp(7));
        version.setBackground(rounded(Color.rgb(44, 35, 27), 20));
        row.addView(version);
        host.addView(row);
    }

    private void renderHome(LinearLayout host) {
        LinearLayout hero = verticalCard();
        hero.setBackground(gradient(new int[]{Color.rgb(54, 19, 29), Color.rgb(24, 18, 27), Color.rgb(17, 18, 25)}, 20));
        hero.setPadding(dp(18), dp(20), dp(18), dp(20));
        TextView eyebrow = label("AN UNOFFICIAL ANDROID PROJECT", 9, GOLD);
        eyebrow.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        eyebrow.setLetterSpacing(0.15f);
        hero.addView(eyebrow);
        TextView title = label("THE CITY OF\nMONSTRUM NOX", 28, TEXT);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setLineSpacing(0, 1.02f);
        title.setPadding(0, dp(9), 0, dp(5));
        hero.addView(title);
        hero.addView(label("A dedicated Android launcher foundation for Ys IX: Monstrum Nox.", 13, Color.rgb(213, 202, 205)));
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        chips.setPadding(0, dp(15), 0, 0);
        chips.addView(chip("MALI TARGETED", GREEN));
        View gap = new View(this);
        chips.addView(gap, new LinearLayout.LayoutParams(dp(7), 1));
        chips.addView(chip("RUNTIME NOT INCLUDED", GOLD));
        hero.addView(chips);
        host.addView(hero, matchWrap());
        addSection(host, "GAME FILES", "Choose your own game dump and, where required by a future runtime, your own key file.");

        LinearLayout gameCard = verticalCard();
        gameCard.addView(fileRow("GAME IMAGE", gameName, "NSP / XCI", () -> chooseFile(REQ_GAME)));
        addDivider(gameCard);
        gameCard.addView(fileRow("KEY FILE", keysName, "KEYS", () -> chooseFile(REQ_KEYS)));
        host.addView(gameCard, matchWrap());

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button prepare = actionButton("PREPARE GAME", RED, TEXT);
        Button launch = actionButton("START GAME", PANEL_ALT, TEXT);
        prepare.setOnClickListener(v -> showRuntimeNotice("Preparation is not implemented in v0.1. This prototype only stores the selected document references; it does not decrypt, extract, patch, or compile game data."));
        launch.setOnClickListener(v -> showRuntimeNotice("The Ys IX game runtime is not integrated yet. This button is reserved for a future runtime build."));
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, dp(48), 1f);
        half.setMargins(0, dp(12), dp(5), 0);
        actions.addView(prepare, half);
        LinearLayout.LayoutParams half2 = new LinearLayout.LayoutParams(0, dp(48), 1f);
        half2.setMargins(dp(5), dp(12), 0, 0);
        actions.addView(launch, half2);
        host.addView(actions);

        LinearLayout runtimeNote = verticalCard();
        runtimeNote.setPadding(dp(13), dp(13), dp(13), dp(13));
        TextView status = label("RUNTIME STATUS  •  NOT INTEGRATED", 10, GOLD);
        status.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        runtimeNote.addView(status);
        runtimeNote.addView(label("v0.1 is the launcher and device-profile foundation. A Ys IX-compatible CPU/system runtime and NVN-to-Vulkan graphics backend are separate development milestones.", 12, MUTED));
        host.addView(runtimeNote, matchWrap());

        addSection(host, "DETECTED DEVICE", "Profile suggestions are based on detected device information and remain editable.");
        LinearLayout device = verticalCard();
        device.addView(infoRow("DEVICE", Build.MANUFACTURER + " " + Build.MODEL));
        device.addView(infoRow("GPU RENDERER", gpuRenderer));
        device.addView(infoRow("RAM", formatRam()));
        device.addView(infoRow("VULKAN", vulkanVersion));
        host.addView(device, matchWrap());
    }

    private View fileRow(String title, String value, String tag, Runnable click) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(5), 0, dp(5));
        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        TextView t = label(title, 9, GOLD);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        TextView v = label(value, 12, TEXT);
        v.setMaxLines(2);
        v.setEllipsize(android.text.TextUtils.TruncateAt.END);
        copy.addView(t);
        copy.addView(v);
        row.addView(copy, new LinearLayout.LayoutParams(0, -2, 1f));
        TextView button = label("SELECT  ›", 10, TEXT);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setPadding(dp(12), dp(10), dp(12), dp(10));
        button.setBackground(rounded(RED_DARK, 10));
        row.addView(button);
        row.setOnClickListener(view -> click.run());
        button.setOnClickListener(view -> click.run());
        return row;
    }

    private void renderGraphics(LinearLayout host) {
        addPageIntro(host, "GRAPHICS CONFIGURATION", "Save preferred values for the future runtime. v0.1 records settings but does not apply them to game rendering.");
        LinearLayout profile = verticalCard();
        profile.addView(label("AUTOMATIC HARDWARE PROFILE", 9, GOLD));
        TextView profileName = label(getSuggestedProfile(), 21, TEXT);
        profileName.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        profileName.setPadding(0, dp(5), 0, dp(3));
        profile.addView(profileName);
        profile.addView(label("Detected renderer: " + gpuRenderer, 11, MUTED));
        host.addView(profile, matchWrap());

        LinearLayout settings = verticalCard();
        settings.addView(label("RENDER SCALE", 10, GOLD));
        Spinner scale = spinner(new String[]{"0.5x", "0.75x", "1.0x", "1.25x"}, prefs.getString("scale", suggestedScale()));
        settings.addView(scale, new LinearLayout.LayoutParams(-1, dp(48)));
        scale.setOnItemSelectedListener(simpleSelection(position -> prefs.edit().putString("scale", scale.getSelectedItem().toString()).apply()));
        settings.addView(label("FPS LIMIT", 10, GOLD));
        Spinner fps = spinner(new String[]{"30 FPS", "60 FPS (experimental target)"}, prefs.getString("fps", "30 FPS"));
        settings.addView(fps, new LinearLayout.LayoutParams(-1, dp(48)));
        fps.setOnItemSelectedListener(simpleSelection(position -> prefs.edit().putString("fps", fps.getSelectedItem().toString()).apply()));
        CheckBox shader = checkBox("Shader cache preference", prefs.getBoolean("shader_cache", true));
        CheckBox vsync = checkBox("VSync preference", prefs.getBoolean("vsync", true));
        CheckBox overlay = checkBox("Performance overlay preference", prefs.getBoolean("overlay", true));
        settings.addView(shader); settings.addView(vsync); settings.addView(overlay);
        shader.setOnCheckedChangeListener((b, checked) -> prefs.edit().putBoolean("shader_cache", checked).apply());
        vsync.setOnCheckedChangeListener((b, checked) -> prefs.edit().putBoolean("vsync", checked).apply());
        overlay.setOnCheckedChangeListener((b, checked) -> prefs.edit().putBoolean("overlay", checked).apply());
        host.addView(settings, matchWrap());

        Button reset = actionButton("RESTORE SUGGESTED PROFILE", PANEL_ALT, TEXT);
        reset.setOnClickListener(v -> {
            prefs.edit().putString("scale", suggestedScale()).putString("fps", "30 FPS")
                    .putBoolean("shader_cache", true).putBoolean("vsync", true).putBoolean("overlay", true).apply();
            currentPage = "GRAPHICS";
            renderApp();
            Toast.makeText(this, "Suggested values restored", Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams resetLp = matchWrap();
        resetLp.setMargins(0, dp(12), 0, 0);
        host.addView(reset, resetLp);
        TextView note = label("Note: 60 FPS, shader caching, VSync and render scale are configuration preferences only. Actual availability depends on the future runtime and game compatibility.", 11, MUTED);
        note.setPadding(dp(3), dp(12), dp(3), 0);
        host.addView(note);
    }

    private void renderControls(LinearLayout host) {
        addPageIntro(host, "CONTROLS", "A placeholder for the future touch-layout editor and controller mapping layer.");
        LinearLayout preview = verticalCard();
        preview.addView(label("TOUCH LAYOUT PREVIEW", 10, GOLD));
        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setPadding(0, dp(18), 0, dp(18));
        TextView dpad = label("◀     ▲\n▼     ▶", 17, TEXT);
        dpad.setGravity(Gravity.CENTER);
        dpad.setBackground(rounded(Color.rgb(43, 43, 54), 50));
        controls.addView(dpad, new LinearLayout.LayoutParams(dp(112), dp(92)));
        View spacer = new View(this);
        controls.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1f));
        TextView buttons = label("Y     X\nB     A", 16, TEXT);
        buttons.setGravity(Gravity.CENTER);
        buttons.setBackground(rounded(RED_DARK, 50));
        controls.addView(buttons, new LinearLayout.LayoutParams(dp(112), dp(92)));
        preview.addView(controls);
        preview.addView(label("Illustrative control layout only — buttons are not connected to a game runtime in v0.1.", 11, MUTED));
        host.addView(preview, matchWrap());

        LinearLayout options = verticalCard();
        CheckBox show = checkBox("Show touch controls by default", prefs.getBoolean("touch_controls", true));
        CheckBox haptics = checkBox("Haptic feedback preference", prefs.getBoolean("haptics", false));
        options.addView(show); options.addView(haptics);
        show.setOnCheckedChangeListener((b, c) -> prefs.edit().putBoolean("touch_controls", c).apply());
        haptics.setOnCheckedChangeListener((b, c) -> prefs.edit().putBoolean("haptics", c).apply());
        host.addView(options, matchWrap());
    }

    private void renderSystem(LinearLayout host) {
        addPageIntro(host, "SYSTEM INFORMATION", "Read-only device information collected locally on this phone.");
        LinearLayout card = verticalCard();
        card.addView(infoRow("MANUFACTURER", Build.MANUFACTURER));
        card.addView(infoRow("MODEL", Build.MODEL));
        card.addView(infoRow("DEVICE CODENAME", Build.DEVICE));
        card.addView(infoRow("ANDROID", Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")"));
        card.addView(infoRow("SUPPORTED ABIS", join(Build.SUPPORTED_ABIS)));
        card.addView(infoRow("OPENGL RENDERER", gpuRenderer));
        card.addView(infoRow("VULKAN FEATURE", vulkanVersion));
        card.addView(infoRow("TOTAL RAM", formatRam()));
        card.addView(infoRow("APP VERSION", "0.1.0"));
        host.addView(card, matchWrap());

        LinearLayout privacy = verticalCard();
        privacy.addView(label("PRIVACY", 10, GOLD));
        privacy.addView(label("This prototype declares no network, camera, microphone, location, contacts, or broad external-storage permission. Files are selected through Android's system document picker and their URIs are stored locally in app preferences.", 12, MUTED));
        host.addView(privacy, matchWrap());

        Button refresh = actionButton("REFRESH DEVICE INFORMATION", PANEL_ALT, TEXT);
        refresh.setOnClickListener(v -> {
            gpuRenderer = detectGlRenderer();
            vulkanVersion = detectVulkanVersion();
            renderApp();
        });
        LinearLayout.LayoutParams lp = matchWrap(); lp.setMargins(0, dp(12), 0, 0);
        host.addView(refresh, lp);
    }

    private void addPageIntro(LinearLayout host, String title, String desc) {
        TextView t = label(title, 20, TEXT);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(0, dp(6), 0, dp(5));
        host.addView(t);
        TextView d = label(desc, 12, MUTED);
        d.setPadding(0, 0, 0, dp(15));
        host.addView(d);
    }

    private void addSection(LinearLayout host, String title, String subtitle) {
        TextView t = label(title, 10, GOLD);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setLetterSpacing(0.12f);
        t.setPadding(dp(2), dp(19), 0, dp(4));
        host.addView(t);
        TextView s = label(subtitle, 11, MUTED);
        s.setPadding(dp(2), 0, 0, dp(9));
        host.addView(s);
    }

    private LinearLayout verticalCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(13), dp(14), dp(13));
        card.setBackground(rounded(PANEL, 17));
        return card;
    }

    private View chip(String text, int color) {
        TextView chip = label(text, 8, color);
        chip.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        chip.setPadding(dp(9), dp(7), dp(9), dp(7));
        chip.setBackground(rounded(Color.argb(35, Color.red(color), Color.green(color), Color.blue(color)), 20));
        return chip;
    }

    private View infoRow(String key, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(7), 0, dp(7));
        TextView left = label(key, 9, MUTED);
        left.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        TextView right = label(value, 11, TEXT);
        right.setGravity(Gravity.END);
        right.setMaxWidth(dp(210));
        right.setMaxLines(3);
        row.addView(left, new LinearLayout.LayoutParams(0, -2, 0.8f));
        row.addView(right, new LinearLayout.LayoutParams(0, -2, 1.2f));
        return row;
    }

    private void addDivider(LinearLayout host) {
        View line = new View(this);
        line.setBackgroundColor(Color.rgb(48, 48, 59));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
        lp.setMargins(0, dp(8), 0, dp(8));
        host.addView(line, lp);
    }

    private TextView label(String text, int size, int color) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        view.setIncludeFontPadding(true);
        return view;
    }

    private Button actionButton(String text, int background, int foreground) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(10);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setTextColor(foreground);
        button.setAllCaps(false);
        button.setPadding(dp(8), 0, dp(8), 0);
        button.setBackground(rounded(background, 12));
        return button;
    }

    private CheckBox checkBox(String text, boolean checked) {
        CheckBox box = new CheckBox(this);
        box.setText(text);
        box.setTextColor(TEXT);
        box.setTextSize(12);
        box.setButtonTintList(android.content.res.ColorStateList.valueOf(RED));
        box.setChecked(checked);
        return box;
    }

    private Spinner spinner(String[] choices, String selected) {
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, choices) {
            @Override public View getView(int position, View convertView, ViewGroup parent) {
                TextView view = (TextView) super.getView(position, convertView, parent);
                view.setTextColor(TEXT); view.setTextSize(13); view.setPadding(dp(8), dp(4), dp(8), dp(4));
                return view;
            }
            @Override public View getDropDownView(int position, View convertView, ViewGroup parent) {
                TextView view = (TextView) super.getDropDownView(position, convertView, parent);
                view.setTextColor(TEXT); view.setTextSize(13); view.setBackgroundColor(PANEL_ALT); view.setPadding(dp(12), dp(12), dp(12), dp(12));
                return view;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setBackground(rounded(PANEL_ALT, 10));
        int idx = 0;
        for (int i = 0; i < choices.length; i++) if (choices[i].equals(selected)) idx = i;
        spinner.setSelection(idx);
        return spinner;
    }

    private android.widget.AdapterView.OnItemSelectedListener simpleSelection(java.util.function.IntConsumer consumer) {
        return new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) { consumer.accept(position); }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { }
        };
    }

    private void chooseFile(int requestCode) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(intent, requestCode);
        } catch (Exception e) {
            Toast.makeText(this, "No document picker available", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        String displayName = queryDisplayName(uri);
        String lower = displayName.toLowerCase(Locale.ROOT);
        if (requestCode == REQ_GAME) {
            if (!(lower.endsWith(".nsp") || lower.endsWith(".xci"))) {
                showRuntimeNotice("Please select a file ending in .nsp or .xci. No file contents have been read.");
                return;
            }
            gameUri = uri;
            gameName = displayName;
            prefs.edit().putString("game_uri", uri.toString()).putString("game_name", displayName).apply();
        } else if (requestCode == REQ_KEYS) {
            if (!lower.endsWith(".keys")) {
                showRuntimeNotice("Please select a .keys file. Its contents will not be read by this v0.1 launcher.");
                return;
            }
            keysUri = uri;
            keysName = displayName;
            prefs.edit().putString("keys_uri", uri.toString()).putString("keys_name", displayName).apply();
        }
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
            // Some document providers do not offer persistable grants. The stored URI may then expire.
        }
        currentPage = "HOME";
        renderApp();
        Toast.makeText(this, "Document reference saved", Toast.LENGTH_SHORT).show();
    }

    private String queryDisplayName(Uri uri) {
        android.database.Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (index >= 0) return cursor.getString(index);
            }
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        String last = uri.getLastPathSegment();
        return last == null ? "Selected document" : last;
    }

    private void showRuntimeNotice(String message) {
        new AlertDialog.Builder(this)
                .setTitle("YS IX v0.1")
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }

    private String detectGlRenderer() {
        EGL10 egl = null;
        EGLDisplay display = null;
        EGLSurface surface = null;
        EGLContext context = null;
        try {
            egl = (EGL10) EGLContext.getEGL();
            display = egl.eglGetDisplay(EGL10.EGL_DEFAULT_DISPLAY);
            int[] version = new int[2];
            if (display == EGL10.EGL_NO_DISPLAY || !egl.eglInitialize(display, version)) return "Not reported";
            int[] configAttrs = {0x3040, 4, 0x3024, 8, 0x3023, 8, 0x3022, 8, 0x3021, 8, 0x3038};
            EGLConfig[] configs = new EGLConfig[1];
            int[] count = new int[1];
            if (!egl.eglChooseConfig(display, configAttrs, configs, 1, count) || count[0] == 0) return "Not reported";
            int[] surfaceAttrs = {0x3057, 1, 0x3056, 1, 0x3038};
            surface = egl.eglCreatePbufferSurface(display, configs[0], surfaceAttrs);
            int[] contextAttrs = {0x3098, 2, 0x3038};
            context = egl.eglCreateContext(display, configs[0], EGL10.EGL_NO_CONTEXT, contextAttrs);
            if (surface == EGL10.EGL_NO_SURFACE || context == EGL10.EGL_NO_CONTEXT) return "Not reported";
            if (!egl.eglMakeCurrent(display, surface, surface, context)) return "Not reported";
            String renderer = GLES20.glGetString(GLES20.GL_RENDERER);
            return renderer == null ? "Not reported" : renderer;
        } catch (Throwable ignored) {
            return "Not reported";
        } finally {
            try {
                if (egl != null && display != null && display != EGL10.EGL_NO_DISPLAY) {
                    egl.eglMakeCurrent(display, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_CONTEXT);
                    if (context != null && context != EGL10.EGL_NO_CONTEXT) egl.eglDestroyContext(display, context);
                    if (surface != null && surface != EGL10.EGL_NO_SURFACE) egl.eglDestroySurface(display, surface);
                    egl.eglTerminate(display);
                }
            } catch (Throwable ignored) { }
        }
    }

    private String detectVulkanVersion() {
        try {
            PackageManager pm = getPackageManager();
            boolean level = pm.hasSystemFeature("android.hardware.vulkan.level");
            int version = 0;
            for (FeatureInfo feature : pm.getSystemAvailableFeatures()) {
                if ("android.hardware.vulkan.version".equals(feature.name)) {
                    version = feature.version;
                    break;
                }
            }
            if (version > 0) {
                int major = (version >> 22) & 0x7F;
                int minor = (version >> 12) & 0x3FF;
                return "Available (reported " + major + "." + minor + ")";
            }
            return level ? "Level feature available; version not reported" : "Not reported by Android";
        } catch (Exception e) {
            return "Could not query";
        }
    }

    private void applyAutomaticDefaultsIfNeeded() {
        if (prefs.contains("scale")) return;
        prefs.edit().putString("scale", suggestedScale()).putString("fps", "30 FPS")
                .putBoolean("shader_cache", true).putBoolean("vsync", true).putBoolean("overlay", true).apply();
    }

    private String suggestedScale() {
        String gpu = gpuRenderer.toLowerCase(Locale.ROOT);
        if (gpu.contains("g720")) return "1.0x";
        if (gpu.contains("g57")) return "0.5x";
        return "0.75x";
    }

    private String getSuggestedProfile() {
        String gpu = gpuRenderer.toLowerCase(Locale.ROOT);
        if (gpu.contains("g720")) return "Mali G720 · Balanced / High";
        if (gpu.contains("g57")) return "Mali G57 · Performance";
        if (gpu.contains("mali")) return "Mali · Compatibility";
        return "Automatic · Compatibility";
    }

    private String formatRam() {
        try {
            ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo info = new ActivityManager.MemoryInfo();
            manager.getMemoryInfo(info);
            return String.format(Locale.US, "%.1f GB total", info.totalMem / 1073741824.0);
        } catch (Exception e) {
            return "Not reported";
        }
    }

    private String join(String[] values) {
        if (values == null || values.length == 0) return "Not reported";
        StringBuilder out = new StringBuilder();
        for (String value : values) {
            if (out.length() > 0) out.append(", ");
            out.append(value);
        }
        return out.toString();
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        return drawable;
    }

    private GradientDrawable gradient(int[] colors, int radiusDp) {
        GradientDrawable drawable = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
        drawable.setCornerRadius(dp(radiusDp));
        drawable.setStroke(dp(1), Color.rgb(78, 43, 51));
        return drawable;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
