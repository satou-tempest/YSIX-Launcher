# Roadmap

## v0.1 — Launcher foundation (this release)

- [x] Dark gothic launcher shell.
- [x] Game image and key-file document pickers.
- [x] Device / renderer / RAM / Vulkan feature display.
- [x] Persisted configuration preferences.
- [x] Separate G720 and G57 suggested starting scales.
- [x] Clear runtime-not-integrated messaging.

## v0.2 — Runtime research and integration design

- [ ] Review the P5R source repository, exact license, submodules and dependency licenses.
- [ ] Establish whether the runtime has reusable non-game-specific components.
- [ ] Audit CPU execution model separately from shader preparation.
- [ ] Document the Nintendo Switch graphics/system interfaces needed by Ys IX.
- [ ] Select a supported Vulkan capability-detection path.
- [ ] Add automated tests for settings and device-profile selection.

## v0.3 — Import pipeline prototype

- [ ] Define a user-owned game-data workflow and supported title/version checks.
- [ ] Implement safe file metadata validation before any extraction work.
- [ ] Design resumable preparation, progress reporting, and recoverable errors.
- [ ] Avoid distributing game data, firmware, keys, or proprietary assets.

## Later — Runtime milestones

- [ ] Demonstrate a legal, compatible guest CPU/system runtime boot path.
- [ ] Implement or adapt graphics translation only after source/license audit.
- [ ] Build shader preparation and persistent cache for Ys IX-specific shaders.
- [ ] Add audio, input, save handling, and runtime lifecycle.
- [ ] Test correctness first on Redmi Turbo 4 (Mali-G720 MC7), then Samsung Galaxy A22 5G (Mali-G57 MC2).
- [ ] Measure frame pacing, thermal behaviour, memory use, and correctness before setting performance claims.
