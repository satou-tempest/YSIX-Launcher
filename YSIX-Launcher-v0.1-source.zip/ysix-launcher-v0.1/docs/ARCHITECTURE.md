# Architecture notes — v0.1

## Current application layer

`MainActivity` is a platform-Android UI prototype. It uses only Android framework APIs and Java 17. There are no third-party runtime dependencies.

### Components present

1. **Launcher UI** — home, graphics, controls, and system pages.
2. **Document selection** — Android Storage Access Framework via `ACTION_OPEN_DOCUMENT`; document URI grants are persisted where the provider supports them.
3. **Preferences** — `SharedPreferences` stores display labels, document URI references, and user settings.
4. **Device diagnostics** — an EGL/OpenGL ES 2 context is created briefly to query `GL_RENDERER`; Android package features are queried for Vulkan hardware support/version; `ActivityManager.MemoryInfo` reports total RAM.
5. **Profile suggestions** — renderer names containing `G720` or `G57` select initial render-scale suggestions.

## Not implemented

- Nintendo Switch CPU emulation or static/dynamic recompilation.
- Horizon OS / service compatibility.
- NCA/NSP/XCI parsing, decryption, filesystem mounting, ExeFS/RomFS extraction.
- NVN command processing or NVN-to-Vulkan translation.
- SPIR-V shader translation or pipeline caching.
- GPU resource synchronization, guest memory mapping, audio, input translation, or save mounting.
- Ys IX-specific patches, hooks, or executable support.

The current Vulkan query is an Android feature query, not a Vulkan device enumeration. The OpenGL renderer string is useful as a hardware hint but is not a complete Vulkan capability report.

## Suggested future module boundaries

When a legitimate, compatible runtime implementation is selected, keep it isolated from the UI:

- `core-device` — device and Vulkan capability detection.
- `core-import` — game metadata and data preparation, using legally obtained user data.
- `core-runtime` — guest CPU/system execution and lifecycle.
- `graphics-nvn-vulkan` — guest graphics API compatibility and Vulkan backend.
- `graphics-shaders` — offline shader conversion and persistent pipeline cache.
- `frontend-android` — launcher, input overlays, settings and lifecycle integration.

Do not put game-specific logic into the launcher activity. Use a versioned runtime interface so the UI remains independent of whichever runtime backend is eventually validated.
