# YS IX Launcher — v0.1

An independent Android launcher/configuration prototype for a future Ys IX: Monstrum Nox runtime.

**Important:** v0.1 is a launcher foundation, not an emulator or recompilation runtime. It does not execute Nintendo Switch code, decrypt game data, extract RomFS/ExeFS, translate NVN commands, compile shaders, or launch Ys IX. The Prepare Game and Start Game actions explain this limitation rather than pretending those operations work.

## Included in v0.1

- Dark gothic / crimson Android interface.
- Home, Graphics, Controls, and System pages.
- Android Storage Access Framework document pickers for `.nsp` / `.xci` and `.keys` files.
- Local persistence of document URI references and display names; no game/key contents are read.
- OpenGL renderer detection via a temporary EGL context.
- Android-reported Vulkan hardware feature query.
- Device model, Android version, supported ABI, and total RAM display.
- Editable render-scale and FPS preferences, plus shader-cache, VSync, performance-overlay, and touch-control preferences.
- Suggested initial presets for detected Mali-G720 and Mali-G57 renderers.
- No broad storage, network, camera, microphone, location, or contacts permissions.

## Hardware targets

The initial project targets the two devices specified by the project owner:

| Device | SoC | GPU | RAM |
|---|---|---|---:|
| Redmi Turbo 4 | MediaTek Dimensity 8400-Ultra | Mali-G720 MC7 | 12 GB |
| Samsung Galaxy A22 5G | MediaTek Dimensity 700 | Mali-G57 MC2 | 8 GB |

The app detects the OpenGL renderer at runtime and suggests a starting preference. The suggested `1.0x` (G720) and `0.5x` (G57) scales are initial test values only. They are not validated Ys IX performance results and are not applied to actual game rendering in this prototype.

## Build

Requirements:

- Android Studio with Android Gradle Plugin 8.7.3 support.
- JDK 17.
- Android SDK Platform 35.
- Gradle 8.9 or newer compatible with AGP 8.7.3.

Open this folder in Android Studio, allow Gradle sync, then select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

Or, with Gradle installed:

```bash
gradle :app:assembleDebug
```

Debug APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

This environment did not have Gradle or an Android SDK installed, so the project has not been compiled or device-tested here.

## Project structure

```text
YSIXLauncher/
├── app/
│   ├── build.gradle
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/io/github/ysix/launcher/MainActivity.java
│       └── res/values/styles.xml
├── docs/
│   ├── ARCHITECTURE.md
│   └── ROADMAP.md
├── build.gradle
├── gradle.properties
└── settings.gradle
```

## Important engineering boundary

This project was written independently as a clean launcher prototype. It does not contain copied P5R implementation code. The P5R repository's source, build system, license, native runtime interfaces, and dependency licenses must be reviewed before adapting any of its components. The existence of a shader pre-processing step in the P5R APK does not establish that its complete CPU runtime is ahead-of-time recompiled.

No Nintendo Switch game dump, firmware, encryption keys, proprietary shader cache, or save data is included.
