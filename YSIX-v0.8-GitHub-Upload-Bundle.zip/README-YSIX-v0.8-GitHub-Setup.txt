YS IX v0.8 — GitHub upload and build instructions
=================================================

Files in this bundle:
- YSIX-Launcher-v0.8-source.zip
- .github/workflows/ysix-v0.8-shader-pipeline.yml

Upload both files to the SAME GitHub repository used for the previous YS IX Actions build.

1. Upload YSIX-Launcher-v0.8-source.zip to the repository root.
2. Upload the workflow file to this exact repository path:
   .github/workflows/ysix-v0.8-shader-pipeline.yml
   Create the .github/workflows folders if they do not already exist.
3. Open the repository's Actions tab.
4. Select "Build YS IX v0.8 Shader Preparation".
5. Press "Run workflow" and wait for the run to finish.
6. If it succeeds, open its Artifacts section and download:
   ysix-v0.8-shader-pipeline-debug-apk

Important:
- This is source + a GitHub Actions workflow, NOT a prebuilt APK.
- I validated the host-side C++ bridge syntax, the shader-cache merge path with a mock translator,
  the existing loader regression test, the runtime patch fixture, YAML parsing and shell syntax.
- The Android NativeAOT translator build, Android NDK runtime build, Gradle APK build and
  on-device Ys IX boot have NOT yet been verified. GitHub Actions must complete those steps.
- The Galaxy A22 5G is the primary test device for this version. The Redmi Turbo 4 is not required.
- The first native boot is expected to capture shader misses. Return to the launcher and use
  PREPARE CAPTURED SHADERS, then try native boot again. More scenes may expose additional misses.
- The v0.8 APK is a fresh debug build. Because GitHub-hosted runners generate a new debug signing
  key, Android may refuse to install it over the earlier v0.7 debug APK. Uninstall v0.7 first if
  Android reports a signature conflict. That resets app preferences and selected file references;
  keep your NSP/XCI and keys accessible so you can select them again.
- Do not upload the NSP/XCI, prod.keys, title.keys, decrypted game files, raw shader captures,
  game saves or DLC packages to GitHub.

The game is not yet confirmed playable. v0.8 adds the missing shader-capture/preparation loop and
a provisional touch layout; the previously observed video/movie stall and other game-specific
runtime blockers remain separate work.
