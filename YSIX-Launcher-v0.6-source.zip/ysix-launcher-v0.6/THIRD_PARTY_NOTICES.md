## P5R Android / SwitchGamesRecomp generic importer components

YSIX v0.6 compiles the generic Nintendo Switch content importer and crypto self-tests from:

- Repository: https://github.com/Brandon04Gonzalez/p5r-android
- Pinned source commit: `645c717afbc0610f9da38b0cc1d6834820ffa76a`
- Reused files: `android/wonder/importer/nximport.cpp`, `nximport.h`, `nxcrypto.cpp`, `nxcrypto.h`, and `nxgame.h`
- License: MIT. The upstream `LICENSE` file and required copyright notices are reproduced below.

MIT License

Copyright (c) 2026 BelmanteGu
Copyright (c) 2026 Brandon (the Persona 5 Royal Android port: games/p5r, runtime/src/nce and the changes for it)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

Only the generic importer/crypto files are used by YS IX. The upstream runtime loader has been studied as architecture
reference, but its full NCE code and P5R-specific game patches are not copied or represented as Ys IX compatibility.
P5R-specific title IDs, build IDs, shaders and game data are not used.
