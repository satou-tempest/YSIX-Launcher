# YS IX: Monstrum Nox — Android native bring-up v0.6.0

An unofficial, game-specific Android native-port development project for **Ys IX: Monstrum Nox**. This is not a general-purpose Switch emulator.

> **Status:** v0.6 is a temporary relocation and symbol-resolution test, not a playable release. It opens the owner's local dump, validates the `main` and `sdk` NSOs, parses dynamic symbols and relocations, maps both modules simultaneously as RW/non-executable memory, applies only relocations resolved within the current two-module scope, verifies those writes, and discards the mappings. It does not enter game code.

## v0.6 changes

### Native loader
- Parses the dynamic string and symbol tables, including symbol binding, type, section and value.
- Builds a defined-symbol export index across `main` and `sdk`.
- Simultaneously maps both modules at their fixed guest bases using `MAP_FIXED_NOREPLACE` and RW-only permissions.
- Applies `R_AARCH64_RELATIVE`, `R_AARCH64_ABS64`, `R_AARCH64_GLOB_DAT` and `R_AARCH64_JUMP_SLOT` only when the target symbol is known from the modules or from ELF's relative-relocation rule.
- Resolves undefined weak references to zero per ELF semantics.
- Leaves unresolved strong imports and unsupported relocation types untouched and lists the unresolved symbol names with reference counts.
- Reads back each temporary relocation write, verifies it, then unmaps both modules.
- Keeps the existing Vulkan and NSP/XCI integrity tests.

### Save and DLC tools retained
- Import/export ZIP archives to a private save workspace. This workspace is **not** yet connected to live in-game save services.
- Keep a local queue of NSP/XCI update or DLC package references. This is **not** installation, activation or content mounting.

## Device targets

| Device | SoC | GPU | RAM |
|---|---|---|---:|
| Redmi Turbo 4 | MediaTek Dimensity 8400-Ultra | Mali-G720 MC7 | 12 GB |
| Samsung Galaxy A22 5G | MediaTek Dimensity 700 | Mali-G57 MC2 | 8 GB |

Both devices have reported v0.4 Gate A + Vulkan initialization PASS and v0.5 Gate B1 PASS. v0.6 must be tested separately on both devices; simultaneous mappings or relocation resolution can still fail differently per device.

## Native linker regression test

A host-side synthetic relocation test runs automatically in GitHub Actions before the Android build. On Linux x86-64 it can also be run locally with `./tests/run_native_loader_test.sh`. It exercises local/module symbol resolution, relative relocations, weak-zero behavior, unresolved strong imports, unsupported relocation reporting, read-back verification, and mapping cleanup using synthetic module images. It is not a real Ys IX binary test.

## Build with GitHub Actions

Upload these two files to your repository:
- `YSIX-Launcher-v0.6-source.zip` at the repository root.
- `.github/workflows/ysix-v0.6-native.yml` at that exact path.

Then open **Actions → Build YS IX v0.6 Temporary Relocation Test → Run workflow**. The workflow fetches only the generic NSP/XCI importer and crypto files from the pinned MIT-licensed upstream source, installs the Android build toolchain, builds the ARM64 debug APK and uploads `ysix-v0.6-temporary-relocation-debug-apk`.

Build requirements: JDK 17, Android Platform 35, Build Tools 35.0.0, NDK `28.2.13676358`, CMake `3.22.1`, Gradle `8.9`, Android Gradle Plugin `8.7.3`.

## Run it

1. Install the v0.6 debug APK from the Actions artifact.
2. In **Library**, select your own complete Ys IX `.nsp` or `.xci`, `prod.keys`, and optional `title.keys` if the dump requires it.
3. Tap **Run Loader + GPU Test**.
4. Save the complete report, especially `[SAFE RELOCATION / SYMBOL-RESOLUTION TEST]`.
5. Run the same test on the other phone and compare the reports.
6. The **Save & DLC Manager** remains available: ZIP import/export goes to its private workspace; DLC package actions only stage local references.

Do not upload your game image, keys, decrypted modules, save data, or DLC packages to GitHub or issue reports.

## Gate semantics

- **Gate A:** package open/decryption and `main`/`sdk` NSO hashes.
- **Gate B1:** both modules simultaneously mapped at fixed guest addresses as RW/non-executable memory.
- **Gate B2a:** supported relocations resolved within the current two-module scope are applied to temporary mappings and read-back verified. This can pass while link status remains partial.
- **Gate B2b:** full Horizon/HLE import resolver, executable permissions, TLS/thread state, constructors, rtld and controlled NCE entry. Not attempted.
- **Gate C:** NVN translation, Android Vulkan swapchain/presentation and first game frame. Not implemented.

A B2a PASS does not mean the game is linked or bootable. Unresolved strong import names and unsupported relocation types are diagnostic evidence for the next runtime phase.

## Third-party source

The project fetches only the generic content importer/crypto source (`nximport.cpp/.h`, `nxcrypto.cpp/.h`, `nxgame.h`) from the MIT-licensed `Brandon04Gonzalez/p5r-android` repository, pinned to commit `645c717afbc0610f9da38b0cc1d6834820ffa76a`. P5R-specific game patches are not treated as Ys IX compatibility. See `THIRD_PARTY_NOTICES.md`.
