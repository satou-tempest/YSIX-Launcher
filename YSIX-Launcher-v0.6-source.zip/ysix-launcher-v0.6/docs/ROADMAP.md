# Development roadmap

## v0.1 — Launcher foundation
Completed: Java-only UI, document pickers and saved preferences.

## v0.2 — Visual identity
Completed: gothic adaptive launcher icon patch.

## v0.3 — Launcher frontend
Completed: navigation, library selection, graphics/control preferences and device diagnostics.

## v0.4 — Native bring-up probe
Device-tested on Galaxy A22 5G (Mali-G57 MC2) and Redmi Turbo 4 (Mali-G720 MC7): local Ys IX image open/decryption, ExeFS `main`/`sdk` NSO hash checks, Vulkan instance/device/graphics queue initialization all reported PASS on both devices.

## v0.5 — Native loader staging + content tools
Device-tested on both target phones: MOD0/dynamic/symbol/relocation metadata inspection and temporary `MAP_FIXED_NOREPLACE` staging maps for `main` and `sdk` passed Gate B1. ZIP save archive import/export and a DLC package reference queue were added. Live in-game save-data and DLC mounting remain unimplemented.

## v0.6 — Temporary relocation and symbol-resolution test
Adds simultaneous RW/non-executable mappings for both modules, a defined-symbol export index, application of supported relocations when resolvable inside the `main`/`sdk` scope, and read-back verification. Unresolved strong imports and unsupported relocation types are reported; unresolved addresses are never faked. Mappings are discarded. It does not enable executable pages or enter game code. Awaiting Android NDK build and device reports.

## v0.7 — Horizon import resolver and NCE bootstrap
Next: use v0.6 unresolved symbol output to implement the required runtime/Horizon HLE registry, then add executable mapping, NCE entry/return traps, guest TLS/thread bootstrap and controlled failure handling. Do not invoke constructors or `nnMain` until all required imports and bootstrap invariants are verified.

## v0.8+ — Switch services and graphics
Implement services requested by Ys IX based on logs, then NVN resource/command behavior and Maxwell shader translation. Verify Mali-specific texture format fallbacks, memory usage, synchronization and presentation. Integrate live save services and verified DLC/update content mounting.

## Gameplay acceptance
First frame, interactive menu, input/audio, stable playable scene, save/load and a clean 10-minute run are separate gates. Do not claim playability until the stable-scene gate passes on at least one named device.
