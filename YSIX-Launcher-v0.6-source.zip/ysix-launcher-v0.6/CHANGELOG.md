# Changelog

## 0.6.0 — Temporary relocation test
- Added dynamic symbol parsing and two-module export indexing.
- Added simultaneous fixed-address RW/non-executable staging for main and SDK.
- Added safe temporary application of supported relative and symbol relocations when resolvable.
- Added read-back verification and unresolved strong-import/unsupported-relocation reporting.
- Kept all mapping changes disposable; no game code execution or constructor calls.
- Retained save ZIP workspace import/export and DLC package reference queue with their existing limitations.

## 0.5.0 — Native loader staging and content tools
- Added bounded MOD0/dynamic metadata inventory and temporary fixed-address staging.
- Added save ZIP archive workspace and DLC package reference queue.
