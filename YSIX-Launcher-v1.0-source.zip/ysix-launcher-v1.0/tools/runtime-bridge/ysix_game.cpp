// Ys IX: Monstrum Nox game identity and v1.0 startup compatibility hooks.
// No game assets, shaders or keys are included in this project.
#include <atomic>
#include <cstdint>
#include <cstdlib>

#include <nx/game.h>
#include <nx/runtime.h>

namespace nx {
namespace {

// The v0.8 Samsung trace reached Android Stagefright while opening a movie stream, then blocked
// indefinitely in NuCachedSource2::readAt -> SniffMPEG4. The two addresses below are function
// entries derived from the supported Ys IX base-game build's stack trace:
//   subsdk0+0x124528 movie::Extractor::SetDataSource(...)
//   subsdk0+0x102494 movie::NnExtractor::SetDataSource(...)
// The bypass is deliberately opt-in (NX_SKIP_MOVIE=1). It returns an error before Stagefright
// waits for the unsupported stream. This is a temporary startup diagnostic: movie playback is
// disabled, and a game flow that requires a movie may still stop or skip content.
constexpr uint64_t kYsIxSubsdk0Base = 0x4020000000ull;
constexpr uint64_t kMovieExtractorSetDataSource = kYsIxSubsdk0Base + 0x124528ull;
constexpr uint64_t kNnExtractorSetDataSource = kYsIxSubsdk0Base + 0x102494ull;

std::atomic<uint32_t> g_skipped_movie_sources{0};

void reject_movie_source(CPU& c) {
    const uint32_t n = g_skipped_movie_sources.fetch_add(1, std::memory_order_relaxed) + 1;
    if (n <= 8) {
        log("ysix/movie: bypassed blocked ClientStreamReader source %u (NX_SKIP_MOVIE=1); returning -ENOSYS",
            n);
    } else if (n == 9) {
        log("ysix/movie: further bypassed movie-source calls are suppressed");
    }
    // status_t-style non-zero result; callers should take their normal movie-open failure path.
    c.x[0] = static_cast<uint64_t>(static_cast<int64_t>(-38));  // -ENOSYS
}

}  // namespace

namespace game {

const Info kInfo = {
    "ysix",
    "Ys IX: Monstrum Nox",
    0x0100E390124D8000ull,
    "io.github.ysix.launcher",
    "private/ysix",
    0,
    "E4C423C70D6CCA76F44094710FDE38D4AF1B4F23000000000000000000000000"
};

void after_init() {
    const char* skip = std::getenv("NX_SKIP_MOVIE");
    if (!skip || skip[0] != '1') {
        log("ysix/movie: compatibility bypass disabled; native movie source remains enabled");
        return;
    }

    // Prefer the outer game wrapper so it can return a failed-source status to its caller. If its
    // entry instruction is not hookable, fall back to the inner NnExtractor wrapper.
    uint64_t original = hook_function(kMovieExtractorSetDataSource, reject_movie_source);
    if (original) {
        log("ysix/movie: startup video bypass installed at subsdk0+0x124528");
        return;
    }

    log("ysix/movie: outer SetDataSource hook unavailable; trying NnExtractor fallback");
    original = hook_function(kNnExtractorSetDataSource, reject_movie_source);
    if (original) {
        log("ysix/movie: startup video bypass installed at subsdk0+0x102494");
    } else {
        log("ysix/movie: could not install either known hook; movie stream may still block startup");
    }
}

void renderer_start() {}
void first_frame() {}

}  // namespace game
}  // namespace nx
