# YS IX: Monstrum Nox — Android native runtime experiment v1.0

**Status:** experimental. The Galaxy A22 5G has reached the real Ys IX title menu in v0.9. New Game loading remains extremely slow, and sound is still absent. v1.0 adds a configurable FPS counter and collects better evidence about the audio renderer lookup that returned `impl 0`. It does **not** claim to restore sound or deliver a playable build.

## v1.0 changes

- **FPS counter switch:** Graphics → **Show in-game FPS counter**. When enabled, the runtime's Vulkan present overlay displays a two-digit, approximately one-second present-rate count near the upper-left of the game image. The setting takes effect on the next game launch.
- **Audio discovery diagnostics:** the A22 log showed `renderer opened (result 0), impl 0`. The runtime previously used an SDK-specific vtable offset that did not find a matching object in Ys IX. v1.0 logs the returned handle, expected reference vtable and safe candidate pointers/vtables to guide the next SDK-specific implementation. It does not guess a new offset.
- **AAudio failure reporting:** builder, stream-open and stream-start failures are now logged if the game reaches Android audio device initialization.
- Retains the v0.9 movie-source bypass, touch input tracing, four-module load and shader capture.

## Test device and milestones

Use the **Samsung Galaxy A22 5G** first. Do not use the Redmi Turbo 4 for this iteration; its owner is using it, and its separate Mali-G720 rendering glitches need a later pass.

The project considers boot successful only when it reaches the actual main menu with New Game / Load Game and responsive input. Reaching a logo, loading screen or a running process does not count. v0.9 reached the menu; first gameplay is not confirmed.

## GitHub build

1. Upload `YSIX-Launcher-v1.0-source.zip` to the repository root.
2. Upload `.github/workflows/ysix-v1.0-startup-compatibility.yml` to that exact path under `.github/workflows/`.
3. Open **Actions → Build YS IX v1.0 Audio and FPS Diagnostics → Run workflow**.
4. Download the artifact `ysix-v1.0-audio-fps-debug-apk`.

The workflow checks the source/patch fixtures, fetches the pinned MIT-licensed P5R generic runtime and Ryujinx-based shader translator, builds the ARM64 runtime and APK. A passing workflow proves build/package success only; it does not prove audio works or that gameplay is playable.

The debug application ID suffix remains `.debug.v07` intentionally, so it can update the currently installed experimental app without changing its app-private data location.

## Expected v1.0 test

On the A22, enable or disable the FPS counter in Graphics, launch the game, and verify the overlay. Then let the title menu load and inspect `nx.log` for `audio: renderer lookup ...` and its candidate pointer/vtable lines. Upload the new log. Audio is only considered fixed when the renderer is found, the audio render thread starts, non-silent PCM reaches AAudio, and the menu music is audible.

New Game performance is not targeted by this release; shader misses, asset streaming and remaining service waits still need separate profiling.
