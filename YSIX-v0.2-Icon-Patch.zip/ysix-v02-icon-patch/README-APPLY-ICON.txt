YS IX Launcher v0.2 — app icon patch

WHAT'S INCLUDED
- Android adaptive icon (Android 8.0+)
- Legacy PNG launcher icons for mdpi through xxxhdpi
- Themed monochrome adaptive icon layer
- Dark charcoal / crimson background and original silver raven-mask emblem

HOW TO APPLY
1. Open your existing YS IX Launcher Android project.
2. Copy the entire app/src/main/res/ folder from this patch into your project's
   app/src/main/res/ folder, merging folders and replacing same-name files.
3. In app/src/main/AndroidManifest.xml, make sure the <application> tag has:

   android:icon="@mipmap/ic_launcher"
   android:roundIcon="@mipmap/ic_launcher_round"

4. In app/build.gradle, change versionCode to 2 and versionName to "0.2.0".
5. Commit the changes to GitHub and run your existing Android build workflow.
6. Install the newly built APK. If Android keeps showing the old icon, uninstall
   the previous debug build first, then install the new APK.

This is a visual asset patch only. It does not add Switch emulation or game runtime
features. The emblem is original fan-made artwork and is not official Ys artwork.
